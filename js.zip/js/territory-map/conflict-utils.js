/**
 * 冲突处理工具方法集合
 * 从 advanced-conflict-processing.js 中提取的独立工具方法
 */

/**
 * 将Leaflet环形坐标转换为标准格式
 * @param {Array} rings - 环形坐标数组
 * @returns {Array} 标准格式的坐标数组
 */
function convertToLeafletRings(rings) {
    if (!Array.isArray(rings)) return [];
    
    return rings.map(ring => {
        if (!Array.isArray(ring)) return [];
        return ring.map(coord => {
            if (Array.isArray(coord) && coord.length >= 2) {
                return [coord[0], coord[1]];
            }
            return coord;
        });
    });
}

/**
 * 验证多边形是否有效
 * @param {Array} boundary - 边界坐标数组
 * @returns {boolean} 是否有效
 */
function isValidPolygon(boundary) {
    if (!Array.isArray(boundary) || boundary.length < 3) {
        return false;
    }
    
    // 检查是否有足够的坐标点
    const validCoords = boundary.filter(coord => 
        Array.isArray(coord) && coord.length >= 2 && 
        typeof coord[0] === 'number' && typeof coord[1] === 'number'
    );
    
    return validCoords.length >= 3;
}

/**
 * 验证Turf.js几何对象的有效性
 * @param {Object} geometry - Turf.js几何对象
 * @param {string} label - 几何对象的标识符
 * @returns {boolean} 是否有效
 */
function validateTurfGeometry(geometry, label = '几何对象') {
    try {
        if (!geometry || !geometry.geometry) {
            console.warn(`⚠️ ${label}: 缺少几何数据`);
            return false;
        }

        const geom = geometry.geometry;
        if (!geom.type || !geom.coordinates) {
            console.warn(`⚠️ ${label}: 几何类型或坐标缺失`);
            return false;
        }

        if (!Array.isArray(geom.coordinates) || geom.coordinates.length === 0) {
            console.warn(`⚠️ ${label}: 坐标数组无效`);
            return false;
        }

        // 对于多边形，检查外环是否有效
        if (geom.type === 'Polygon') {
            const outerRing = geom.coordinates[0];
            if (!Array.isArray(outerRing) || outerRing.length < 4) {
                console.warn(`⚠️ ${label}: 多边形外环坐标不足4个点`);
                return false;
            }

            // 检查是否闭合
            const first = outerRing[0];
            const last = outerRing[outerRing.length - 1];
            if (first[0] !== last[0] || first[1] !== last[1]) {
                console.warn(`⚠️ ${label}: 多边形未闭合`);
                return false;
            }
        }

        // 尝试计算面积来验证几何有效性
        try {
            const area = turf.area(geometry);
            if (isNaN(area) || area < 0) {
                console.warn(`⚠️ ${label}: 面积计算异常 (${area})`);
                return false;
            }
        } catch (areaError) {
            console.warn(`⚠️ ${label}: 面积计算失败: ${areaError.message}`);
            return false;
        }

        return true;

    } catch (error) {
        console.warn(`⚠️ ${label}: 验证时发生错误: ${error.message}`);
        return false;
    }
}

/**
 * 创建有效的Turf.js多边形
 * @param {Array} boundary - 边界坐标数组
 * @returns {Object|null} Turf.js多边形对象或null
 */
function createValidTurfPolygon(boundary) {
    try {
        if (!boundary || !Array.isArray(boundary)) {
            console.warn('⚠️ 边界数据无效或不是数组:', typeof boundary);
            return null;
        }

        if (boundary.length < 3) {
            console.warn(`⚠️ 边界坐标不足，至少需要3个点，当前只有 ${boundary.length} 个点:`, boundary);
            return null;
        }

        // 确保多边形是闭合的
        let coordinates = [...boundary];
        const firstPoint = coordinates[0];
        const lastPoint = coordinates[coordinates.length - 1];

        // 检查是否已经闭合
        if (firstPoint[0] !== lastPoint[0] || firstPoint[1] !== lastPoint[1]) {
            coordinates.push([firstPoint[0], firstPoint[1]]);
        }

        // 确保至少有4个点（包括闭合点）
        if (coordinates.length < 4) {
            console.warn('⚠️ 闭合后坐标点仍不足4个');
            return null;
        }

        // 创建Turf.js多边形
        const polygon = turf.polygon([coordinates]);

        // 验证多边形是否有效
        if (!polygon || !polygon.geometry || !polygon.geometry.coordinates) {
            console.warn('⚠️ 创建的多边形无效');
            return null;
        }

        return polygon;

    } catch (error) {
        console.warn('⚠️ 创建多边形时发生错误:', error.message);
        return null;
    }
}

/**
 * 将Turf.js多边形转换为MC坐标数组
 * @param {Object} turfPolygon - Turf.js多边形对象
 * @returns {Array} MC坐标数组
 */
function convertTurfPolygonToMCCoords(turfPolygon) {
    try {
        if (!turfPolygon || !turfPolygon.geometry || !turfPolygon.geometry.coordinates) {
            return null;
        }

        const coords = turfPolygon.geometry.coordinates;

        if (turfPolygon.geometry.type === 'Polygon') {
            // 单个多边形，取外环
            return coords[0].map(coord => [coord[0], coord[1]]);
        } else if (turfPolygon.geometry.type === 'MultiPolygon') {
            // 多个多边形，取第一个多边形的外环
            return coords[0][0].map(coord => [coord[0], coord[1]]);
        }

        return null;
    } catch (error) {
        console.error('❌ 转换Turf多边形到MC坐标失败:', error);
        return null;
    }
}

/**
 * 将GeoJSON坐标转换为Leaflet坐标
 * @param {Object} geoJSON - GeoJSON对象
 * @returns {Array} Leaflet坐标数组
 */
function convertGeoJSONToLeafletCoords(geoJSON) {
    if (!geoJSON || !geoJSON.geometry || !geoJSON.geometry.coordinates) {
        return null;
    }

    const coords = geoJSON.geometry.coordinates;
    const type = geoJSON.geometry.type;

    try {
        if (type === 'Polygon') {
            // 单个多边形：coords[0] 是外环
            return coords[0].map(coord => mcToMapCoords(coord[0], coord[1]));
        } else if (type === 'MultiPolygon') {
            // 多个多边形：coords[i][0] 是第i个多边形的外环
            return coords.map(polygon =>
                polygon[0].map(coord => mcToMapCoords(coord[0], coord[1]))
            );
        } else {
            console.warn(`⚠️ 不支持的几何类型: ${type}`);
            return null;
        }
    } catch (error) {
        console.error('❌ 坐标转换失败:', error);
        return null;
    }
}

/**
 * 计算两点之间的欧几里得距离
 * @param {Object} point1 - 点1 {x, z}
 * @param {Object} point2 - 点2 {x, z}
 * @returns {number} 距离（方块）
 */
function calculateDistance(point1, point2) {
    const dx = point1.x - point2.x;
    const dz = point1.z - point2.z;
    return Math.sqrt(dx * dx + dz * dz);
}

/**
 * 智能检测坐标格式
 * @param {Array} coord - 坐标数组 [x, y]
 * @returns {boolean} true表示是地图坐标，false表示是MC坐标
 */
function isMapCoordinate(coord) {
    if (!Array.isArray(coord) || coord.length < 2) {
        return false;
    }

    const [x, y] = coord;

    // 简单的启发式判断：
    // 如果坐标都是正数且在地图范围内，很可能是地图坐标
    if (x >= 0 && y >= 0 && x <= 16000 && y <= 19000) {
        return true;
    }

    // 如果坐标有负数且在MC范围内，很可能是MC坐标
    if (x >= -11000 && x <= 9000 && y >= -9000 && y <= 8000) {
        return false;
    }

    // 默认假设是MC坐标
    return false;
}

/**
 * 计算箭头旋转角度
 * @param {Array} from - 起点坐标 [lat, lng]
 * @param {Array} to - 终点坐标 [lat, lng]
 * @returns {number} 旋转角度（度）
 */
function getArrowRotation(from, to) {
    const dx = to[1] - from[1];  // lng差值
    const dy = to[0] - from[0];  // lat差值
    const angle = Math.atan2(dx, dy) * 180 / Math.PI;
    return angle;
}

// 导出函数
if (typeof window !== 'undefined') {
    // 浏览器环境
    window.ConflictUtils = {
        convertToLeafletRings,
        isValidPolygon,
        validateTurfGeometry,
        createValidTurfPolygon,
        convertTurfPolygonToMCCoords,
        convertGeoJSONToLeafletCoords,
        calculateDistance,
        isMapCoordinate,
        getArrowRotation
    };
}

if (typeof module !== 'undefined' && module.exports) {
    // Node.js环境
    module.exports = {
        convertToLeafletRings,
        isValidPolygon,
        validateTurfGeometry,
        createValidTurfPolygon,
        convertTurfPolygonToMCCoords,
        convertGeoJSONToLeafletCoords,
        calculateDistance,
        isMapCoordinate,
        getArrowRotation
    };
}
