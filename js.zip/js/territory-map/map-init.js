/**
 * 地图初始化与交互模块
 * 负责地图的初始化、事件监听和基本交互功能
 */

/**
 * 地图初始化
 */
function initializeMap() {
    // 初始化地图
    map = L.map('map', {
        crs: MAP_CONFIG.crs,
        center: MAP_CONFIG.center,
        zoom: MAP_CONFIG.zoom,
        minZoom: MAP_CONFIG.minZoom,
        maxZoom: MAP_CONFIG.maxZoom
    });

    // 添加地图图片图层
    const imageLayer = L.imageOverlay('tiles/map_low.png', MAP_CONFIG.imageBounds, {
        attribution: 'Minecraft 服务器地图'
    });

    imageLayer.addTo(map);

    // 调整地图视图以适应图片
    map.fitBounds(MAP_CONFIG.imageBounds);
    map.setView(MAP_CONFIG.center, MAP_CONFIG.zoom);

    // 设置地图事件监听器
    setupMapEventListeners();

    // 强制刷新地图显示
    setTimeout(() => {
        map.invalidateSize();
    }, 100);
}

/**
 * 设置地图事件监听器
 */
function setupMapEventListeners() {
    // 鼠标移动事件 - 显示坐标
    map.on('mousemove', function(e) {
        const mapCoords = e.latlng;
        const mcCoords = mapToMcCoords(mapCoords.lat, mapCoords.lng);

        // 更新地图内坐标显示
        const mapOverlayMapEl = document.getElementById('map-coords-overlay-map');
        const mapOverlayMcEl = document.getElementById('map-coords-overlay-mc');
        if (mapOverlayMapEl) {
            mapOverlayMapEl.textContent = `${mapCoords.lat.toFixed(1)}, ${mapCoords.lng.toFixed(1)}`;
        }
        if (mapOverlayMcEl) {
            mapOverlayMcEl.textContent = `${mcCoords.x}, ${mcCoords.z}`;
        }
    });

    // 鼠标离开地图事件 - 重置坐标显示
    map.on('mouseout', function() {
        // 重置地图内坐标显示
        const mapOverlayMapEl = document.getElementById('map-coords-overlay-map');
        const mapOverlayMcEl = document.getElementById('map-coords-overlay-mc');
        if (mapOverlayMapEl) {
            mapOverlayMapEl.textContent = '--, --';
        }
        if (mapOverlayMcEl) {
            mapOverlayMcEl.textContent = '--, --';
        }
    });

    // 缩放事件
    map.on('zoomend', function() {
        const zoomLevelEl = document.getElementById('zoom-level');
        if (zoomLevelEl) {
            zoomLevelEl.textContent = map.getZoom().toFixed(1);
        }
    });

    // 初始化缩放显示
    const zoomLevelEl = document.getElementById('zoom-level');
    if (zoomLevelEl) {
        zoomLevelEl.textContent = map.getZoom().toFixed(1);
    }
}

/**
 * 重置地图视图
 */
function resetMap() {
    map.fitBounds(MAP_CONFIG.imageBounds);
    updateStatus('info', '地图视图已重置');
}

/**
 * 聚焦到特定领地
 * @param {string} type - 类型 ('marker' 或 'area')
 * @param {string} key - 领地键值
 */
function focusOnTerritory(type, key) {
    if (!territoryData) return;

    if (type === 'marker' && territoryData.markers[key]) {
        const marker = territoryData.markers[key];
        const mapCoords = mcToMapCoords(marker.x, marker.z);
        map.setView(mapCoords, Math.max(map.getZoom(), 2));

        // 如果已显示，打开弹窗
        const markerLayer = markerLayers.find(m => m.options.title === marker.label);
        if (markerLayer) {
            markerLayer.openPopup();
        }
    } else if (type === 'area' && territoryData.areas[key]) {
        const area = territoryData.areas[key];
        if (area.x && area.z && area.x.length > 0) {
            const centerX = area.x.reduce((a, b) => a + b, 0) / area.x.length;
            const centerZ = area.z.reduce((a, b) => a + b, 0) / area.z.length;
            const mapCoords = mcToMapCoords(centerX, centerZ);
            map.setView(mapCoords, Math.max(map.getZoom(), 2));
        }
    }
}

/**
 * 设置地图视图到指定坐标
 * @param {number} mcX - Minecraft X坐标
 * @param {number} mcZ - Minecraft Z坐标
 * @param {number} zoom - 缩放级别（可选）
 */
function setMapViewToMcCoords(mcX, mcZ, zoom = null) {
    const mapCoords = mcToMapCoords(mcX, mcZ);
    const targetZoom = zoom !== null ? zoom : Math.max(map.getZoom(), 1);
    map.setView(mapCoords, targetZoom);
}

/**
 * 获取当前地图视图的MC坐标范围
 * @returns {Object} {minX, maxX, minZ, maxZ} - MC坐标边界
 */
function getCurrentMapBounds() {
    const bounds = map.getBounds();
    const sw = mapToMcCoords(bounds.getSouth(), bounds.getWest());
    const ne = mapToMcCoords(bounds.getNorth(), bounds.getEast());

    return {
        minX: Math.min(sw.x, ne.x),
        maxX: Math.max(sw.x, ne.x),
        minZ: Math.min(sw.z, ne.z),
        maxZ: Math.max(sw.z, ne.z)
    };
}

/**
 * 适应地图视图到指定的MC坐标边界
 * @param {Object} bounds - {minX, maxX, minZ, maxZ} MC坐标边界
 * @param {Object} options - 选项 {padding: number}
 */
function fitMapToBounds(bounds, options = {}) {
    const sw = mcToMapCoords(bounds.minX, bounds.maxZ);
    const ne = mcToMapCoords(bounds.maxX, bounds.minZ);

    const leafletBounds = L.latLngBounds([sw, ne]);

    const fitOptions = {
        padding: [options.padding || 20, options.padding || 20]
    };

    map.fitBounds(leafletBounds, fitOptions);
}

/**
 * 添加临时标记到地图
 * @param {number} mcX - Minecraft X坐标
 * @param {number} mcZ - Minecraft Z坐标
 * @param {string} title - 标记标题
 * @param {string} content - 弹窗内容
 * @param {Object} options - 标记选项
 * @returns {Object} Leaflet标记对象
 */
function addTemporaryMarker(mcX, mcZ, title, content, options = {}) {
    const mapCoords = mcToMapCoords(mcX, mcZ);

    const marker = L.marker(mapCoords, {
        title: title,
        ...options
    }).addTo(map);

    if (content) {
        marker.bindPopup(content);
    }

    return marker;
}

/**
 * 清除所有临时标记
 */
function clearTemporaryMarkers() {
    if (window.temporaryMarkers) {
        window.temporaryMarkers.forEach(marker => {
            map.removeLayer(marker);
        });
        window.temporaryMarkers = [];
    }
}

/**
 * 初始化临时标记数组
 */
function initializeTemporaryMarkers() {
    if (!window.temporaryMarkers) {
        window.temporaryMarkers = [];
    }
}

/**
 * 获取地图当前状态信息
 * @returns {Object} 地图状态信息
 */
function getMapStatus() {
    return {
        center: map.getCenter(),
        zoom: map.getZoom(),
        bounds: map.getBounds(),
        mcBounds: getCurrentMapBounds(),
        size: map.getSize()
    };
}

/**
 * 强制刷新地图显示
 */
function refreshMapDisplay() {
    map.invalidateSize();
    console.log('🔄 地图显示已刷新');
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeMap,
        setupMapEventListeners,
        resetMap,
        focusOnTerritory,
        setMapViewToMcCoords,
        getCurrentMapBounds,
        fitMapToBounds,
        addTemporaryMarker,
        clearTemporaryMarkers,
        initializeTemporaryMarkers,
        getMapStatus,
        refreshMapDisplay
    };
}
