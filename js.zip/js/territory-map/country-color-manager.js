/**
 * 国家颜色管理器
 * 从 advanced-conflict-processing.js 中提取的颜色管理功能
 */

/**
 * 国家颜色管理器
 */
const CountryColorManager = {
    // 预定义的国家颜色调色板
    colorPalette: [
        '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57',
        '#ff9ff3', '#54a0ff', '#5f27cd', '#00d2d3', '#ff9f43',
        '#10ac84', '#ee5a24', '#0abde3', '#3867d6', '#8c7ae6',
        '#fd79a8', '#fdcb6e', '#6c5ce7', '#a29bfe', '#74b9ff',
        '#00b894', '#e17055', '#81ecec', '#fab1a0', '#e84393'
    ],

    // 存储国家颜色映射
    countryColors: new Map(),

    // 默认颜色
    defaultColor: '#4CAF50', // 绿色

    /**
     * 初始化所有国家的颜色（从 countryAreas 数据中预加载）
     * @returns {Promise<void>}
     */
    async initializeCountryColors() {
        try {
            console.log('🎨 开始初始化国家颜色...');

            // 获取 countryAreas 数据
            let countryAreasData = null;

            // 1. 检查全局变量
            if (typeof window !== 'undefined') {
                countryAreasData = window.countryAreas ||
                                 window.territoryData?.countryAreas ||
                                 window.processedData?.countryAreas;
            }

            // 2. 如果全局变量没有，尝试从 countryClaimsManager 获取
            if (!countryAreasData && typeof window !== 'undefined' && window.countryClaimsManager) {
                countryAreasData = window.countryClaimsManager.countryAreaData;
            }

            // 3. 如果还是没有，尝试直接从 IndexedDB 获取
            if (!countryAreasData && typeof getStoredCountryAreas === 'function') {
                try {
                    countryAreasData = await getStoredCountryAreas();
                } catch (error) {
                    console.warn('⚠️ 从 IndexedDB 获取 countryAreas 失败:', error);
                }
            }

            if (!countryAreasData) {
                console.log('⚠️ 无法找到 countryAreas 数据，将使用预定义调色板');
                return;
            }

            // 为每个国家预加载颜色
            let colorsFromAreas = 0;
            let colorsFromPalette = 0;

            for (const [countryName, countryData] of Object.entries(countryAreasData)) {
                if (this.countryColors.has(countryName)) {
                    continue; // 已经有颜色了，跳过
                }

                // 查找该国家的第一个有效颜色
                let foundColor = null;
                for (const [areaId, area] of Object.entries(countryData)) {
                    if (area && area.color) {
                        foundColor = area.color;
                        console.log(`✅ 从区域 ${areaId} 获取国家 "${countryName}" 的颜色: ${foundColor}`);
                        colorsFromAreas++;
                        break;
                    }
                }

                // 如果没有找到颜色，使用调色板
                if (!foundColor) {
                    const colorIndex = this.countryColors.size % this.colorPalette.length;
                    foundColor = this.colorPalette[colorIndex];
                    console.log(`🎨 为国家 "${countryName}" 使用调色板颜色: ${foundColor}`);
                    colorsFromPalette++;
                }

                this.countryColors.set(countryName, foundColor);
            }

            console.log(`✅ 国家颜色初始化完成: ${colorsFromAreas} 个来自区域数据，${colorsFromPalette} 个来自调色板`);

        } catch (error) {
            console.error('❌ 初始化国家颜色失败:', error);
        }
    },

    /**
     * 获取国家颜色
     * @param {string} countryName - 国家名称
     * @returns {string} 颜色值
     */
    getCountryColor(countryName) {
        if (!countryName) return this.defaultColor;

        // 如果已经分配过颜色，直接返回
        if (this.countryColors.has(countryName)) {
            return this.countryColors.get(countryName);
        }

        // 如果没有预加载，使用调色板作为后备方案
        const colorIndex = this.countryColors.size % this.colorPalette.length;
        const assignedColor = this.colorPalette[colorIndex];
        this.countryColors.set(countryName, assignedColor);

        console.log(`🎨 为国家 "${countryName}" 分配调色板颜色: ${assignedColor}`);
        return assignedColor;
    },

    /**
     * 设置国家颜色
     * @param {string} countryName - 国家名称
     * @param {string} color - 颜色值
     */
    setCountryColor(countryName, color) {
        this.countryColors.set(countryName, color);
        console.log(`🎨 设置国家 "${countryName}" 颜色为: ${color}`);
    },

    /**
     * 获取所有国家颜色映射
     * @returns {Map} 国家颜色映射
     */
    getAllCountryColors() {
        return new Map(this.countryColors);
    },

    /**
     * 清除所有颜色分配
     */
    clearAllColors() {
        this.countryColors.clear();
        console.log('🎨 已清除所有国家颜色分配');
    },

    /**
     * 获取颜色统计信息
     * @returns {Object} 颜色统计
     */
    getColorStats() {
        const stats = {
            totalCountries: this.countryColors.size,
            usedColors: new Set(this.countryColors.values()).size,
            availableColors: this.colorPalette.length,
            colorMap: Object.fromEntries(this.countryColors)
        };

        return stats;
    },

    /**
     * 导出颜色配置
     * @returns {Object} 颜色配置对象
     */
    exportColorConfig() {
        return {
            palette: this.colorPalette,
            assignments: Object.fromEntries(this.countryColors),
            defaultColor: this.defaultColor,
            exportedAt: new Date().toISOString()
        };
    },

    /**
     * 导入颜色配置
     * @param {Object} config - 颜色配置对象
     */
    importColorConfig(config) {
        try {
            if (config.palette && Array.isArray(config.palette)) {
                this.colorPalette = config.palette;
            }

            if (config.assignments && typeof config.assignments === 'object') {
                this.countryColors.clear();
                for (const [country, color] of Object.entries(config.assignments)) {
                    this.countryColors.set(country, color);
                }
            }

            if (config.defaultColor) {
                this.defaultColor = config.defaultColor;
            }

            console.log('✅ 颜色配置导入成功');
        } catch (error) {
            console.error('❌ 导入颜色配置失败:', error);
        }
    },

    /**
     * 生成随机颜色
     * @returns {string} 随机颜色值
     */
    generateRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    },

    /**
     * 为新国家自动分配颜色
     * @param {string} countryName - 国家名称
     * @returns {string} 分配的颜色
     */
    autoAssignColor(countryName) {
        if (this.countryColors.has(countryName)) {
            return this.countryColors.get(countryName);
        }

        // 优先使用调色板中未使用的颜色
        const usedColors = new Set(this.countryColors.values());
        const availableColors = this.colorPalette.filter(color => !usedColors.has(color));

        let assignedColor;
        if (availableColors.length > 0) {
            // 使用未使用的调色板颜色
            assignedColor = availableColors[0];
        } else {
            // 调色板用完了，生成随机颜色
            assignedColor = this.generateRandomColor();
        }

        this.setCountryColor(countryName, assignedColor);
        return assignedColor;
    },

    /**
     * 验证颜色值是否有效
     * @param {string} color - 颜色值
     * @returns {boolean} 是否有效
     */
    isValidColor(color) {
        if (typeof color !== 'string') return false;
        
        // 检查十六进制颜色格式
        const hexPattern = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
        if (hexPattern.test(color)) return true;

        // 检查CSS颜色名称（简单检查）
        const cssColors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray'];
        if (cssColors.includes(color.toLowerCase())) return true;

        return false;
    }
};

// 导出到全局作用域
if (typeof window !== 'undefined') {
    window.CountryColorManager = CountryColorManager;
    console.log('✅ 国家颜色管理器已加载到全局作用域');
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = CountryColorManager;
}
