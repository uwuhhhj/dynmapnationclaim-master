/**
 * Minecraft 领地地图系统主入口文件
 * 负责系统初始化、全局变量管理和模块协调
 */

// 全局变量声明
let map = null;
let territoryData = null;
let territoryLayers = [];
let markerLayers = [];
let displayedAreasCount = 0;
let displayedMarkersCount = 0;
let countryClaimsManager = null;

// 全局变量存储优化过程中的数据
let optimizationState = {
    // 原有属性
    conflicts: [],
    gridCells: new Map(), // Map<conflictId, gridCells[]>
    cellAssignments: new Map(), // Map<conflictId, Map<cellId, countryName>>
    cuttingResults: new Map(), // Map<conflictId, cuttingResults>

    // 新增的7步骤流程属性
    claimBlocks: new Map(), // Map<countryName, claimBlocks[]> - 步骤1: 构建的宣称块
    conflictAreas: new Map(), // Map<conflictId, conflictAreaInfo> - 步骤2: 检测到的冲突区域
    cleanedClaimBlocks: new Map(), // Map<countryName, cleanedBlocks[]> - 步骤3: 删除冲突后的宣称块
    mergedClaimBlocks: new Map(), // Map<countryName, mergedBlocks[]> - 步骤6: 合并归属区域后的宣称块
    finalBoundaries: new Map() // Map<countryName, finalClaims[]> - 步骤7: 最终的宣称边界
};

/**
 * 页面加载完成后初始化
 */
async function initializeTerritoryMap() {
    updateStatus('info', '地图系统正在初始化...');
    console.log('Minecraft 领地地图系统初始化完成');
    console.log('地图覆盖范围:', MC_BOUNDS);
    console.log('世界大小:', WORLD_WIDTH, 'x', WORLD_HEIGHT);

    // 初始化地图
    initializeMap();

    // 初始化显示计数
    updateDisplayCounts();

    // 初始化临时标记数组
    initializeTemporaryMarkers();

    // 初始化国家宣称管理器 (使用独立渲染器)
    countryClaimsManager = new CountryClaimsManager(
        map,
        { mcToMapCoords, mapToMcCoords },
        updateStatus,
        {
            // 自定义配置选项
            interaction: {
                enablePopup: true,
                enableTooltip: true,
                autoFitView: true,
                fitViewPadding: 0.1
            }
        }
    );

    // 自动加载领地数据
    await autoLoadTerritoryData();

    // 尝试加载已存储的国家数据
    try {
        const storedCountryData = await getStoredCountrySpawn();
        if (storedCountryData) {
            await loadCountryDataInternal();
            console.log('✅ 已加载存储的国家数据，使用新的独立渲染器');
        }
    } catch (error) {
        console.warn('⚠️ 加载国家数据时出错:', error);
    }

    // 检查是否有存储的国家宣称数据（但不自动显示）
    try {
        const storedCountryClaims = await getStoredCountryClaims();
        if (storedCountryClaims && Object.keys(storedCountryClaims).length > 0) {
            const countryCount = Object.keys(storedCountryClaims).length;
            const totalRegions = Object.values(storedCountryClaims).reduce((sum, claims) => sum + claims.length, 0);
            console.log(`🗺️ 发现存储的国家宣称数据: ${countryCount} 个国家，${totalRegions} 个区域（未自动显示）`);

            // 只是将数据加载到内存中，不渲染到地图上
            for (const [countryName, claimsData] of Object.entries(storedCountryClaims)) {
                if (claimsData && claimsData.length > 0) {
                    // 转换存储格式为运行时格式
                    const claims = claimsData.map(claimData => ({
                        id: claimData.id,
                        boundary: claimData.rings[0], // 主环
                        area: claimData.area,
                        metadata: claimData.metadata
                    }));

                    // 构建宣称结果对象并存储到内存中（但不渲染）
                    const claimsResult = {
                        success: true,
                        claims: claims,
                        metadata: {
                            countryName: countryName,
                            totalClaims: claims.length,
                            loadedFromStorage: true,
                            loadedAt: new Date().toISOString()
                        }
                    };

                    // 只存储到内存中，不渲染到地图上
                    if (countryClaimsManager) {
                        countryClaimsManager.generatedClaims.set(countryName, claimsResult);
                    }
                }
            }

            updateStatus('info', `已检测到 ${countryCount} 个国家的宣称数据，可通过开关控制显示`);
        }
    } catch (error) {
        console.warn('⚠️ 检查国家宣称数据时出错:', error);
    }

    // 初始化配置显示（包括加载存储的配置）
    await initializeConfigDisplay();

    // 更新显示控制开关状态，确保国家宣称开关正确反映实际显示状态
    if (typeof updateToggleStates === 'function') {
        setTimeout(updateToggleStates, 100);
    }
}

/**
 * 自动加载领地数据
 */
async function autoLoadTerritoryData() {
    updateStatus('info', '正在自动加载领地数据...');

    try {
        // 检查是否存在 loadTerritoryData 函数
        if (typeof loadTerritoryData === 'function') {
            await loadTerritoryData();
            console.log('✅ 领地数据自动加载完成');
        } else {
            console.warn('⚠️ loadTerritoryData 函数未找到，尝试直接加载数据');

            // 直接尝试从存储获取数据
            const markers = await getStoredMarkers();
            const areas = await getStoredAreas();

            if (!markers && !areas) {
                updateStatus('info', '本地无数据，正在从服务器获取...');
                await fetchAndStoreAllData();
            }

            // 重新获取数据
            const finalMarkers = await getStoredMarkers();
            const finalAreas = await getStoredAreas();

            if (finalMarkers || finalAreas) {
                territoryData = {
                    markers: finalMarkers || {},
                    areas: finalAreas || {}
                };

                const markerCount = Object.keys(territoryData.markers).length;
                const areaCount = Object.keys(territoryData.areas).length;

                updateStatus('success', `自动加载完成：${markerCount} 个标记点和 ${areaCount} 个区域`);

                // 更新UI
                if (typeof updateTerritoryList === 'function') {
                    updateTerritoryList();
                }
                if (typeof updateStatistics === 'function') {
                    updateStatistics();
                }
            } else {
                updateStatus('warning', '未能获取到领地数据，请检查网络连接');
            }
        }
    } catch (error) {
        console.error('❌ 自动加载领地数据失败:', error);
        updateStatus('error', `自动加载失败: ${error.message}`);
    }
}

/**
 * 获取系统状态信息
 * @returns {Object} 系统状态对象
 */
function getSystemStatus() {
    return {
        map: {
            initialized: !!map,
            center: map ? map.getCenter() : null,
            zoom: map ? map.getZoom() : null
        },
        territoryData: {
            loaded: !!territoryData,
            markers: territoryData ? Object.keys(territoryData.markers).length : 0,
            areas: territoryData ? Object.keys(territoryData.areas).length : 0
        },
        display: {
            areasCount: displayedAreasCount,
            markersCount: displayedMarkersCount,
            totalLayers: territoryLayers.length + markerLayers.length
        },
        countryClaimsManager: {
            initialized: !!countryClaimsManager,
            hasData: countryClaimsManager ?
                (countryClaimsManager.countrySpawnData && countryClaimsManager.countryAreaData) : false,
            generatedClaims: countryClaimsManager ? countryClaimsManager.generatedClaims.size : 0
        },
        optimization: {
            conflicts: optimizationState.conflicts.length,
            claimBlocks: optimizationState.claimBlocks.size,
            gridCells: optimizationState.gridCells.size,
            finalBoundaries: optimizationState.finalBoundaries.size
        }
    };
}

/**
 * 重置系统状态
 */
function resetSystemState() {
    // 清除地图显示
    if (map) {
        clearTerritories();
        clearCountryBoundaries();
        clearTemporaryMarkers();
    }

    // 重置数据
    territoryData = null;
    displayedAreasCount = 0;
    displayedMarkersCount = 0;

    // 重置优化状态
    optimizationState.conflicts = [];
    optimizationState.gridCells.clear();
    optimizationState.cellAssignments.clear();
    optimizationState.cuttingResults.clear();
    optimizationState.claimBlocks.clear();
    optimizationState.conflictAreas.clear();
    optimizationState.cleanedClaimBlocks.clear();
    optimizationState.mergedClaimBlocks.clear();
    optimizationState.finalBoundaries.clear();

    // 更新UI
    updateDisplayCounts();
    updateStatistics();
    updateStatus('info', '系统状态已重置');

    console.log('🔄 系统状态已重置');
}

/**
 * 导出系统数据
 * @param {Object} options - 导出选项
 * @returns {Object} 导出的数据
 */
function exportSystemData(options = {}) {
    const exportData = {
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        systemStatus: getSystemStatus()
    };

    if (options.includeTerritoryData && territoryData) {
        exportData.territoryData = territoryData;
    }

    if (options.includeOptimizationState) {
        exportData.optimizationState = {
            conflicts: optimizationState.conflicts,
            claimBlocks: Array.from(optimizationState.claimBlocks.entries()),
            conflictAreas: Array.from(optimizationState.conflictAreas.entries()),
            finalBoundaries: Array.from(optimizationState.finalBoundaries.entries())
        };
    }

    if (options.includeCountryClaims && countryClaimsManager) {
        exportData.countryClaims = Array.from(countryClaimsManager.generatedClaims.entries());
    }

    return exportData;
}

/**
 * 导入系统数据
 * @param {Object} importData - 要导入的数据
 * @returns {boolean} 导入是否成功
 */
function importSystemData(importData) {
    try {
        if (!importData || typeof importData !== 'object') {
            throw new Error('无效的导入数据格式');
        }

        console.log('📥 开始导入系统数据...');

        // 导入领地数据
        if (importData.territoryData) {
            territoryData = importData.territoryData;
            updateTerritoryList();
            updateStatistics();
            console.log('✅ 领地数据导入成功');
        }

        // 导入优化状态
        if (importData.optimizationState) {
            const optState = importData.optimizationState;
            optimizationState.conflicts = optState.conflicts || [];

            if (optState.claimBlocks) {
                optimizationState.claimBlocks = new Map(optState.claimBlocks);
            }
            if (optState.conflictAreas) {
                optimizationState.conflictAreas = new Map(optState.conflictAreas);
            }
            if (optState.finalBoundaries) {
                optimizationState.finalBoundaries = new Map(optState.finalBoundaries);
            }

            console.log('✅ 优化状态导入成功');
        }

        // 导入国家宣称数据
        if (importData.countryClaims && countryClaimsManager) {
            countryClaimsManager.generatedClaims = new Map(importData.countryClaims);
            console.log('✅ 国家宣称数据导入成功');
        }

        updateStatus('success', '系统数据导入完成');
        return true;

    } catch (error) {
        console.error('❌ 导入系统数据失败:', error);
        updateStatus('error', `导入失败: ${error.message}`);
        return false;
    }
}

/**
 * 检查系统依赖
 * @returns {Object} 依赖检查结果
 */
function checkSystemDependencies() {
    const dependencies = {
        leaflet: typeof L !== 'undefined',
        turf: typeof turf !== 'undefined',
        indexedDB: 'indexedDB' in window,
        localStorage: 'localStorage' in window,
        countryClaimsManager: typeof CountryClaimsManager !== 'undefined',
        boundaryOptimizer: typeof BoundaryOverlapOptimizer !== 'undefined'
    };

    const missing = Object.entries(dependencies)
        .filter(([name, available]) => !available)
        .map(([name]) => name);

    return {
        allAvailable: missing.length === 0,
        missing: missing,
        dependencies: dependencies
    };
}

/**
 * 系统健康检查
 * @returns {Object} 健康检查结果
 */
function performHealthCheck() {
    const health = {
        timestamp: new Date().toISOString(),
        status: 'healthy',
        issues: []
    };

    // 检查依赖
    const depCheck = checkSystemDependencies();
    if (!depCheck.allAvailable) {
        health.status = 'warning';
        health.issues.push(`缺少依赖: ${depCheck.missing.join(', ')}`);
    }

    // 检查地图状态
    if (!map) {
        health.status = 'error';
        health.issues.push('地图未初始化');
    }

    // 检查数据完整性
    if (territoryData) {
        const stats = getTerritoryDataStats();
        if (stats.total === 0) {
            health.issues.push('领地数据为空');
        }
    }

    // 检查内存使用
    if (performance && performance.memory) {
        const memUsage = performance.memory.usedJSHeapSize / 1024 / 1024; // MB
        if (memUsage > 100) { // 超过100MB
            health.issues.push(`内存使用较高: ${memUsage.toFixed(2)}MB`);
        }
    }

    return health;
}

// 在页面加载时自动初始化
if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', async function() {
        // 检查依赖
        const depCheck = checkSystemDependencies();
        if (!depCheck.allAvailable) {
            console.warn('⚠️ 系统依赖检查失败:', depCheck.missing);
        }

        // 初始化系统（异步）
        await initializeTerritoryMap();

        // 执行健康检查
        const health = performHealthCheck();
        if (health.status !== 'healthy') {
            console.warn('⚠️ 系统健康检查发现问题:', health.issues);
        }
    });
}

/**
 * 自动加载存储的国家宣称数据
 */
async function autoLoadStoredCountryClaims(storedCountryClaims) {
    if (!countryClaimsManager) {
        console.warn('⚠️ 国家宣称管理器未初始化，跳过自动加载宣称数据');
        return;
    }

    try {
        updateStatus('info', '正在自动加载国家宣称数据...');

        const countryNames = Object.keys(storedCountryClaims);
        const totalRegions = Object.values(storedCountryClaims).reduce((sum, claims) => sum + claims.length, 0);

        console.log(`🗺️ 开始自动加载 ${countryNames.length} 个国家的宣称数据 (共 ${totalRegions} 个区域)`);

        // 将存储的数据转换为内存中的格式
        for (const [countryName, claimsData] of Object.entries(storedCountryClaims)) {
            if (claimsData && claimsData.length > 0) {
                // 转换存储格式为运行时格式
                const claims = claimsData.map(claimData => ({
                    id: claimData.id,
                    boundary: claimData.rings[0], // 主环
                    area: claimData.area,
                    metadata: claimData.metadata
                }));

                // 构建宣称结果对象
                const claimsResult = {
                    success: true,
                    claims: claims,
                    metadata: {
                        countryName: countryName,
                        totalClaims: claims.length,
                        loadedFromStorage: true,
                        loadedAt: new Date().toISOString()
                    }
                };

                // 存储到内存中
                countryClaimsManager.generatedClaims.set(countryName, claimsResult);

                // 渲染到地图上
                const renderResult = countryClaimsManager.renderGeneratedClaims(countryName, claims, {
                    autoFitView: false // 避免自动缩放
                });

                if (renderResult.success) {
                    console.log(`✅ 国家 "${countryName}" 的宣称数据已自动加载并显示 (${claims.length} 个区域)`);
                } else {
                    console.warn(`⚠️ 国家 "${countryName}" 的宣称数据加载成功但渲染失败:`, renderResult.error);
                }
            }
        }

        updateStatus('success', `已自动加载 ${countryNames.length} 个国家的宣称数据 (共 ${totalRegions} 个区域)`);
        updateStatistics();

        // 更新显示控制开关状态
        if (typeof updateToggleStates === 'function') {
            setTimeout(updateToggleStates, 100);
        }

        console.log('✅ 国家宣称数据自动加载完成');

    } catch (error) {
        console.error('❌ 自动加载国家宣称数据失败:', error);
        updateStatus('warning', `自动加载宣称数据失败: ${error.message}`);
    }
}

// 导出主要函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeTerritoryMap,
        getSystemStatus,
        resetSystemState,
        exportSystemData,
        importSystemData,
        checkSystemDependencies,
        performHealthCheck,
        autoLoadStoredCountryClaims
    };
}
