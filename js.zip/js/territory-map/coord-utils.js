/**
 * 坐标转换工具模块
 * 负责Minecraft坐标与地图坐标之间的转换
 */

/**
 * Minecraft坐标转换为地图坐标
 * @param {number} mcX - Minecraft X坐标
 * @param {number} mcZ - Minecraft Z坐标
 * @returns {Array} [mapY, mapX] - Leaflet地图坐标
 */
function mcToMapCoords(mcX, mcZ) {
    // 将MC坐标转换为相对于地图左上角的坐标
    const relativeX = mcX - MC_BOUNDS.minX;
    const relativeZ = mcZ - MC_BOUNDS.minZ;

    // 转换为Leaflet坐标系（注意Y轴翻转）
    const mapY = WORLD_HEIGHT - relativeZ;
    const mapX = relativeX;

    return [mapY, mapX];
}

/**
 * 地图坐标转换为Minecraft坐标
 * @param {number} mapY - Leaflet地图Y坐标
 * @param {number} mapX - Leaflet地图X坐标
 * @returns {Object} {x, z} - Minecraft坐标对象
 */
function mapToMcCoords(mapY, mapX) {
    // 转换回相对坐标
    const relativeZ = WORLD_HEIGHT - mapY;
    const relativeX = mapX;

    // 转换为MC世界坐标
    const mcX = relativeX + MC_BOUNDS.minX;
    const mcZ = relativeZ + MC_BOUNDS.minZ;

    return { x: Math.round(mcX), z: Math.round(mcZ) };
}

/**
 * 批量转换MC坐标到地图坐标
 * @param {Array} mcCoords - MC坐标数组 [[x1, z1], [x2, z2], ...]
 * @returns {Array} 地图坐标数组 [[mapY1, mapX1], [mapY2, mapX2], ...]
 */
function batchMcToMapCoords(mcCoords) {
    if (!Array.isArray(mcCoords)) {
        console.warn('⚠️ batchMcToMapCoords: 输入不是数组');
        return [];
    }

    return mcCoords.map(coord => {
        if (Array.isArray(coord) && coord.length >= 2) {
            return mcToMapCoords(coord[0], coord[1]);
        } else {
            console.warn('⚠️ batchMcToMapCoords: 无效的坐标格式', coord);
            return null;
        }
    }).filter(coord => coord !== null);
}

/**
 * 批量转换地图坐标到MC坐标
 * @param {Array} mapCoords - 地图坐标数组 [[mapY1, mapX1], [mapY2, mapX2], ...]
 * @returns {Array} MC坐标数组 [[x1, z1], [x2, z2], ...]
 */
function batchMapToMcCoords(mapCoords) {
    if (!Array.isArray(mapCoords)) {
        console.warn('⚠️ batchMapToMcCoords: 输入不是数组');
        return [];
    }

    return mapCoords.map(coord => {
        if (Array.isArray(coord) && coord.length >= 2) {
            const mcCoords = mapToMcCoords(coord[0], coord[1]);
            return [mcCoords.x, mcCoords.z];
        } else {
            console.warn('⚠️ batchMapToMcCoords: 无效的坐标格式', coord);
            return null;
        }
    }).filter(coord => coord !== null);
}

/**
 * 验证MC坐标是否在世界范围内
 * @param {number} mcX - Minecraft X坐标
 * @param {number} mcZ - Minecraft Z坐标
 * @returns {boolean} 是否在范围内
 */
function isValidMcCoords(mcX, mcZ) {
    return mcX >= MC_BOUNDS.minX && mcX <= MC_BOUNDS.maxX &&
           mcZ >= MC_BOUNDS.minZ && mcZ <= MC_BOUNDS.maxZ;
}

/**
 * 验证地图坐标是否在有效范围内
 * @param {number} mapY - Leaflet地图Y坐标
 * @param {number} mapX - Leaflet地图X坐标
 * @returns {boolean} 是否在范围内
 */
function isValidMapCoords(mapY, mapX) {
    return mapY >= 0 && mapY <= WORLD_HEIGHT &&
           mapX >= 0 && mapX <= WORLD_WIDTH;
}

/**
 * 计算两个MC坐标点之间的距离
 * @param {number} x1 - 第一个点的X坐标
 * @param {number} z1 - 第一个点的Z坐标
 * @param {number} x2 - 第二个点的X坐标
 * @param {number} z2 - 第二个点的Z坐标
 * @returns {number} 距离（方块单位）
 */
function calculateMcDistance(x1, z1, x2, z2) {
    const dx = x2 - x1;
    const dz = z2 - z1;
    return Math.sqrt(dx * dx + dz * dz);
}

/**
 * 计算MC坐标多边形的中心点
 * @param {Array} mcCoords - MC坐标数组 [[x1, z1], [x2, z2], ...]
 * @returns {Object} {x, z} - 中心点坐标
 */
function calculateMcPolygonCenter(mcCoords) {
    if (!Array.isArray(mcCoords) || mcCoords.length === 0) {
        return { x: 0, z: 0 };
    }

    const sumX = mcCoords.reduce((sum, coord) => sum + coord[0], 0);
    const sumZ = mcCoords.reduce((sum, coord) => sum + coord[1], 0);

    return {
        x: Math.round(sumX / mcCoords.length),
        z: Math.round(sumZ / mcCoords.length)
    };
}

/**
 * 获取MC坐标多边形的边界框
 * @param {Array} mcCoords - MC坐标数组 [[x1, z1], [x2, z2], ...]
 * @returns {Object} {minX, maxX, minZ, maxZ} - 边界框
 */
function getMcPolygonBounds(mcCoords) {
    if (!Array.isArray(mcCoords) || mcCoords.length === 0) {
        return { minX: 0, maxX: 0, minZ: 0, maxZ: 0 };
    }

    const xCoords = mcCoords.map(coord => coord[0]);
    const zCoords = mcCoords.map(coord => coord[1]);

    return {
        minX: Math.min(...xCoords),
        maxX: Math.max(...xCoords),
        minZ: Math.min(...zCoords),
        maxZ: Math.max(...zCoords)
    };
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        mcToMapCoords,
        mapToMcCoords,
        batchMcToMapCoords,
        batchMapToMcCoords,
        isValidMcCoords,
        isValidMapCoords,
        calculateMcDistance,
        calculateMcPolygonCenter,
        getMcPolygonBounds
    };
}
