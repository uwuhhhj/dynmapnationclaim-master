/**
 * 模块加载器
 * 负责按正确顺序加载所有拆分后的模块
 */

(function() {
    'use strict';

    // 模块加载配置
    const MODULE_CONFIG = {
        basePath: 'js/territory-map/',
        modules: [
            // 1. 基础配置和工具模块（无依赖）
            'config.js',
            'coord-utils.js',

            // 2. UI和地图基础模块
            'ui-updates.js',
            'map-init.js',

            // 3. 数据处理模块
            'territory-data.js',

            // 4. 高级功能模块
            'country-claims.js',
            'step-execution.js',
            'advanced-conflict-processing.js',

            // 5. 主入口模块（最后加载）
            'main.js'
        ],
        loadTimeout: 10000, // 10秒超时
        retryCount: 3
    };

    // 模块加载状态
    let loadedModules = new Set();
    let failedModules = new Set();
    let loadingPromises = new Map();

    /**
     * 动态加载JavaScript文件
     * @param {string} src - 脚本路径
     * @param {number} timeout - 超时时间（毫秒）
     * @returns {Promise} 加载Promise
     */
    function loadScript(src, timeout = MODULE_CONFIG.loadTimeout) {
        // 如果已经在加载中，返回现有的Promise
        if (loadingPromises.has(src)) {
            return loadingPromises.get(src);
        }

        const promise = new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = src;

            // 设置超时
            const timeoutId = setTimeout(() => {
                script.remove();
                reject(new Error(`加载超时: ${src}`));
            }, timeout);

            script.onload = () => {
                clearTimeout(timeoutId);
                loadedModules.add(src);
                console.log(`✅ 模块加载成功: ${src}`);
                resolve();
            };

            script.onerror = () => {
                clearTimeout(timeoutId);
                script.remove();
                failedModules.add(src);
                reject(new Error(`加载失败: ${src}`));
            };

            document.head.appendChild(script);
        });

        loadingPromises.set(src, promise);
        return promise;
    }

    /**
     * 带重试的模块加载
     * @param {string} modulePath - 模块路径
     * @param {number} retries - 重试次数
     * @returns {Promise} 加载Promise
     */
    async function loadModuleWithRetry(modulePath, retries = MODULE_CONFIG.retryCount) {
        const fullPath = MODULE_CONFIG.basePath + modulePath;

        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                await loadScript(fullPath);
                return;
            } catch (error) {
                console.warn(`⚠️ 模块加载失败 (尝试 ${attempt}/${retries}): ${modulePath}`, error.message);

                if (attempt === retries) {
                    throw error;
                }

                // 等待一段时间后重试
                await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
            }
        }
    }

    /**
     * 按顺序加载所有模块
     * @returns {Promise} 加载完成Promise
     */
    async function loadAllModules() {
        console.log('🚀 开始加载领地地图模块...');
        console.log(`📋 计划加载 ${MODULE_CONFIG.modules.length} 个模块`);

        const startTime = Date.now();
        const loadResults = [];

        for (const modulePath of MODULE_CONFIG.modules) {
            try {
                console.log(`📦 正在加载: ${modulePath}`);
                await loadModuleWithRetry(modulePath);
                loadResults.push({ module: modulePath, status: 'success' });
            } catch (error) {
                console.error(`❌ 模块加载失败: ${modulePath}`, error);
                loadResults.push({ module: modulePath, status: 'failed', error: error.message });
            }
        }

        const endTime = Date.now();
        const loadTime = endTime - startTime;

        // 生成加载报告
        const successCount = loadResults.filter(r => r.status === 'success').length;
        const failedCount = loadResults.filter(r => r.status === 'failed').length;

        console.log('📊 模块加载报告:');
        console.log(`   总模块数: ${MODULE_CONFIG.modules.length}`);
        console.log(`   成功加载: ${successCount}`);
        console.log(`   加载失败: ${failedCount}`);
        console.log(`   加载耗时: ${loadTime}ms`);

        if (failedCount > 0) {
            console.warn('⚠️ 以下模块加载失败:');
            loadResults.filter(r => r.status === 'failed').forEach(result => {
                console.warn(`   - ${result.module}: ${result.error}`);
            });
        }

        // 检查关键模块是否加载成功
        const criticalModules = ['config.js', 'coord-utils.js', 'main.js'];
        const failedCritical = criticalModules.filter(module =>
            failedModules.has(MODULE_CONFIG.basePath + module)
        );

        if (failedCritical.length > 0) {
            throw new Error(`关键模块加载失败: ${failedCritical.join(', ')}`);
        }

        return {
            success: failedCount === 0,
            successCount,
            failedCount,
            loadTime,
            results: loadResults
        };
    }

    /**
     * 检查模块依赖
     * @returns {Object} 依赖检查结果
     */
    function checkModuleDependencies() {
        const dependencies = {
            // 检查全局变量是否存在
            MC_BOUNDS: typeof MC_BOUNDS !== 'undefined',
            mcToMapCoords: typeof mcToMapCoords === 'function',
            updateStatus: typeof updateStatus === 'function',
            initializeTerritoryMap: typeof initializeTerritoryMap === 'function'
        };

        const missing = Object.entries(dependencies)
            .filter(([name, available]) => !available)
            .map(([name]) => name);

        return {
            allAvailable: missing.length === 0,
            missing: missing,
            dependencies: dependencies
        };
    }

    /**
     * 初始化模块系统
     */
    async function initializeModuleSystem() {
        try {
            // 检查浏览器兼容性
            if (!document.head || !document.createElement) {
                throw new Error('浏览器不支持动态脚本加载');
            }

            // 加载所有模块
            const loadResult = await loadAllModules();

            if (loadResult.success) {
                console.log('✅ 所有模块加载成功');

                // 检查模块依赖
                setTimeout(() => {
                    const depCheck = checkModuleDependencies();
                    if (depCheck.allAvailable) {
                        console.log('✅ 模块依赖检查通过');
                    } else {
                        console.warn('⚠️ 模块依赖检查失败:', depCheck.missing);
                    }
                }, 100);

            } else {
                console.warn('⚠️ 部分模块加载失败，系统可能无法正常工作');
            }

            return loadResult;

        } catch (error) {
            console.error('❌ 模块系统初始化失败:', error);
            throw error;
        }
    }

    /**
     * 获取模块加载状态
     * @returns {Object} 加载状态信息
     */
    function getModuleLoadStatus() {
        return {
            loaded: Array.from(loadedModules),
            failed: Array.from(failedModules),
            total: MODULE_CONFIG.modules.length,
            loadedCount: loadedModules.size,
            failedCount: failedModules.size
        };
    }

    /**
     * 重新加载失败的模块
     * @returns {Promise} 重新加载结果
     */
    async function reloadFailedModules() {
        if (failedModules.size === 0) {
            console.log('✅ 没有需要重新加载的模块');
            return { success: true, reloadedCount: 0 };
        }

        console.log(`🔄 重新加载 ${failedModules.size} 个失败的模块...`);

        const failedList = Array.from(failedModules);
        failedModules.clear(); // 清空失败列表

        let reloadedCount = 0;

        for (const modulePath of failedList) {
            try {
                await loadScript(modulePath);
                reloadedCount++;
            } catch (error) {
                console.error(`❌ 重新加载失败: ${modulePath}`, error);
            }
        }

        console.log(`🔄 重新加载完成: ${reloadedCount}/${failedList.length} 个模块成功`);

        return {
            success: reloadedCount === failedList.length,
            reloadedCount: reloadedCount,
            totalAttempted: failedList.length
        };
    }

    // 暴露API到全局
    window.TerritoryMapModuleLoader = {
        loadAllModules,
        initializeModuleSystem,
        getModuleLoadStatus,
        reloadFailedModules,
        checkModuleDependencies
    };

    // 自动初始化（如果DOM已就绪）
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeModuleSystem);
    } else {
        // DOM已就绪，立即初始化
        initializeModuleSystem().catch(error => {
            console.error('❌ 自动初始化失败:', error);
        });
    }

})();
