/**
 * 冲突处理配置管理器
 * 统一管理样式、选项和UI配置
 */

/**
 * 冲突处理样式配置
 */
const ConflictStyles = {
    // 冲突区域样式
    conflictArea: {
        twoCountry: {
            color: '#ff4444',
            fillColor: '#ff4444',
            fillOpacity: 0.4,
            weight: 3,
            opacity: 0.8,
            dashArray: '8, 4'
        },
        multiCountry: {
            color: '#ff8800',
            fillColor: '#ff8800',
            fillOpacity: 0.5,
            weight: 3,
            opacity: 0.8,
            dashArray: '12, 6'
        }
    },

    // 栅格单元样式
    gridCell: {
        default: {
            color: '#00ff00',
            fillColor: '#00ff00',
            fillOpacity: 0.2,
            weight: 1,
            opacity: 0.6
        },
        assigned: {
            fillOpacity: 0.6,
            weight: 2,
            opacity: 0.9
        },
        withDistance: {
            // 动态计算透明度：0.7 到 0.2
            minOpacity: 0.2,
            maxOpacity: 0.7
        }
    },

    // 清理后的宣称块样式
    cleanedClaim: {
        color: '#2196F3',
        fillColor: '#2196F3',
        fillOpacity: 0.3,
        weight: 2,
        opacity: 0.8
    },

    // 连线样式
    connection: {
        weight: 3,
        opacity: 0.8,
        dashArray: '10, 5'
    },

    // 调试边界框样式
    debugBounds: {
        color: '#ff0000',
        fillColor: '#ff0000',
        fillOpacity: 0.1,
        weight: 2,
        opacity: 0.8,
        dashArray: '5, 5'
    }
};

/**
 * 冲突处理选项配置
 */
const ConflictOptions = {
    // 默认栅格大小（区块）
    defaultGridSizes: {
        conflict: 4,    // 步骤4冲突栅格
        claims: 4       // 步骤8宣称栅格
    },

    // 默认删除百分比
    defaultRemovalPercentage: 10,

    // 面积阈值
    areaThresholds: {
        minConflictArea: 1000,      // 最小冲突区域面积（平方米）
        minClaimArea: 1000,         // 最小宣称区域面积（平方米）
        minGridArea: 100            // 最小栅格面积（平方米）
    },

    // 距离阈值
    distanceThresholds: {
        equalDistanceRange: 5,      // 相等距离误差范围（方块）
        minOverlapRatio: 0.3        // 最小重叠比例
    },

    // 可视化选项
    visualization: {
        maxPopupGrids: 3,           // 弹窗中显示的最大栅格数
        autoFitBounds: true,        // 自动调整视图
        showDebugInfo: false        // 显示调试信息
    }
};

/**
 * 配置管理器
 */
const ConflictConfigManager = {
    // 获取冲突栅格大小
    getConflictGridSize() {
        if (typeof getConflictGridSize === 'function') {
            return getConflictGridSize();
        }
        return ConflictOptions.defaultGridSizes.conflict;
    },

    // 获取宣称栅格大小
    getClaimsGridSize() {
        if (typeof getClaimsGridSize === 'function') {
            return getClaimsGridSize();
        }
        return ConflictOptions.defaultGridSizes.claims;
    },

    // 获取删除百分比
    getRemovalPercentage() {
        if (typeof getRemovalPercentage === 'function') {
            return getRemovalPercentage();
        }
        return ConflictOptions.defaultRemovalPercentage;
    },

    // 获取冲突区域样式
    getConflictStyle(isMultiCountry = false) {
        return isMultiCountry ? 
            ConflictStyles.conflictArea.multiCountry : 
            ConflictStyles.conflictArea.twoCountry;
    },

    // 获取栅格样式
    getGridStyle(type = 'default', options = {}) {
        const baseStyle = ConflictStyles.gridCell[type] || ConflictStyles.gridCell.default;
        return { ...baseStyle, ...options };
    },

    // 获取连线样式
    getConnectionStyle(color) {
        return {
            ...ConflictStyles.connection,
            color: color
        };
    },

    // 获取面积阈值
    getAreaThreshold(type) {
        return ConflictOptions.areaThresholds[type] || 1000;
    },

    // 获取距离阈值
    getDistanceThreshold(type) {
        return ConflictOptions.distanceThresholds[type] || 5;
    },

    // 检查是否显示调试信息
    shouldShowDebugInfo() {
        return ConflictOptions.visualization.showDebugInfo;
    },

    // 获取弹窗配置
    getPopupConfig() {
        return {
            maxGrids: ConflictOptions.visualization.maxPopupGrids,
            autoFitBounds: ConflictOptions.visualization.autoFitBounds
        };
    }
};

/**
 * UI 元素初始化器（简化版本）
 */
const ConflictUIManager = {
    // 必要的UI元素
    requiredElements: [
        'status-display',
        'conflict-grid-size',
        'claims-grid-size', 
        'removal-percentage'
    ],

    // 初始化必要的UI元素
    initializeEssentialUI() {
        console.log('🎛️ 初始化冲突处理UI元素...');
        
        let initialized = 0;
        
        this.requiredElements.forEach(elementId => {
            const element = document.getElementById(elementId);
            if (element) {
                this.setupElement(elementId, element);
                initialized++;
            } else {
                console.warn(`⚠️ UI元素未找到: ${elementId}`);
            }
        });

        console.log(`✅ UI初始化完成: ${initialized}/${this.requiredElements.length} 个元素`);
        return initialized === this.requiredElements.length;
    },

    // 设置单个元素
    setupElement(elementId, element) {
        switch (elementId) {
            case 'conflict-grid-size':
                if (!element.value) {
                    element.value = ConflictOptions.defaultGridSizes.conflict;
                }
                break;
            case 'claims-grid-size':
                if (!element.value) {
                    element.value = ConflictOptions.defaultGridSizes.claims;
                }
                break;
            case 'removal-percentage':
                if (!element.value) {
                    element.value = ConflictOptions.defaultRemovalPercentage;
                }
                break;
        }
    },

    // 集中注册事件监听器
    registerEventListeners() {
        console.log('📡 注册冲突处理事件监听器...');
        
        // 这里可以添加必要的事件监听器
        // 例如：配置变更、按钮点击等
        
        // 示例：监听配置变更
        const conflictGridInput = document.getElementById('conflict-grid-size');
        if (conflictGridInput) {
            conflictGridInput.addEventListener('change', (e) => {
                console.log(`🔧 冲突栅格大小变更为: ${e.target.value}`);
            });
        }

        const claimsGridInput = document.getElementById('claims-grid-size');
        if (claimsGridInput) {
            claimsGridInput.addEventListener('change', (e) => {
                console.log(`🔧 宣称栅格大小变更为: ${e.target.value}`);
            });
        }

        const removalInput = document.getElementById('removal-percentage');
        if (removalInput) {
            removalInput.addEventListener('change', (e) => {
                console.log(`🔧 删除百分比变更为: ${e.target.value}%`);
            });
        }
    },

    // 更新状态显示
    updateStatus(type, message) {
        const statusElement = document.getElementById('status-display');
        if (statusElement) {
            const timestamp = new Date().toLocaleTimeString();
            const icon = this.getStatusIcon(type);
            statusElement.innerHTML = `${icon} [${timestamp}] ${message}`;
            statusElement.className = `status-${type}`;
        }
        
        // 同时输出到控制台
        console.log(`📊 状态更新 [${type}]: ${message}`);
    },

    // 获取状态图标
    getStatusIcon(type) {
        const icons = {
            info: 'ℹ️',
            success: '✅',
            warning: '⚠️',
            error: '❌'
        };
        return icons[type] || 'ℹ️';
    }
};

// 导出到全局作用域
if (typeof window !== 'undefined') {
    window.ConflictStyles = ConflictStyles;
    window.ConflictOptions = ConflictOptions;
    window.ConflictConfigManager = ConflictConfigManager;
    window.ConflictUIManager = ConflictUIManager;
    
    // 提供简化的更新状态函数
    window.updateStatus = ConflictUIManager.updateStatus.bind(ConflictUIManager);
    
    console.log('✅ 冲突处理配置管理器已加载');
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ConflictStyles,
        ConflictOptions,
        ConflictConfigManager,
        ConflictUIManager
    };
}
