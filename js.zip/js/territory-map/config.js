/**
 * 地图配置与设置模块
 * 包含所有配置常量和配置更新函数
 */

// Minecraft 世界坐标范围
const MC_BOUNDS = {
    minX: -10459,
    maxX: 8540,
    minZ: -8384,
    maxZ: 7616
};

// 计算世界大小
const WORLD_WIDTH = MC_BOUNDS.maxX - MC_BOUNDS.minX;  // 18999
const WORLD_HEIGHT = MC_BOUNDS.maxZ - MC_BOUNDS.minZ; // 15999

// 地图配置
const MAP_CONFIG = {
    // 使用简单坐标系统
    crs: L.CRS.Simple,
    // 地图图片边界（Leaflet坐标系）
    imageBounds: [[0, 0], [WORLD_HEIGHT, WORLD_WIDTH]],
    // 默认视图
    center: [WORLD_HEIGHT/2, WORLD_WIDTH/2],
    zoom: -3,
    minZoom: -4,
    maxZoom: 3
};

/**
 * 更新聚类配置
 */
async function updateClusteringConfig() {
    if (!countryClaimsManager) return;

    // 安全地获取配置元素
    const maxBreakDistanceEl = document.getElementById('max-break-distance');
    const bufferDistanceEl = document.getElementById('buffer-distance');

    // 如果元素不存在，使用默认值
    const maxBreakDistanceChunks = maxBreakDistanceEl ? parseInt(maxBreakDistanceEl.value) : 100;
    const bufferDistanceChunks = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
    // 使用固定的默认值，不再从UI获取
    const enableMerging = true;
    const useConvexHull = true;

    // 转换为方块单位（1区块 = 16方块）
    const maxBreakDistanceBlocks = maxBreakDistanceChunks * 16;
    const bufferDistanceBlocks = bufferDistanceChunks * 16;

    // 安全地更新显示值
    const maxBreakDistanceValueEl = document.getElementById('max-break-distance-value');
    const bufferDistanceValueEl = document.getElementById('buffer-distance-value');

    if (maxBreakDistanceValueEl) {
        maxBreakDistanceValueEl.textContent = `${maxBreakDistanceChunks}区块 (${maxBreakDistanceBlocks}方块)`;
    }
    if (bufferDistanceValueEl) {
        bufferDistanceValueEl.textContent = `${bufferDistanceChunks}区块 (${bufferDistanceBlocks}方块)`;
    }

    // 更新步骤2按钮的文本
    updateStep2ButtonText(bufferDistanceChunks);

    // 更新生成器配置（使用方块单位）
    if (countryClaimsManager && countryClaimsManager.claimsGenerator) {
        countryClaimsManager.claimsGenerator.config.clustering.maxBreakDistance = maxBreakDistanceBlocks;
        countryClaimsManager.claimsGenerator.config.geometry.bufferDistance = bufferDistanceBlocks;
        countryClaimsManager.claimsGenerator.config.geometry.enableMerging = enableMerging;
        countryClaimsManager.claimsGenerator.config.geometry.useConvexHull = useConvexHull;

        console.log('🔧 聚类配置已更新:', {
            maxBreakDistance: `${maxBreakDistanceChunks}区块 (${maxBreakDistanceBlocks}方块)`,
            bufferDistance: `${bufferDistanceChunks}区块 (${bufferDistanceBlocks}方块)`,
            enableMerging,
            useConvexHull
        });
    }

    // 保存配置到存储
    await saveCurrentConfig();
}

/**
 * 保存当前配置到存储
 */
async function saveCurrentConfig() {
    try {
        const config = getCurrentConfig();
        if (typeof setStoredClaimsConfig === 'function') {
            await setStoredClaimsConfig(config);
            console.log('💾 配置已保存到存储');
        }
    } catch (error) {
        console.warn('⚠️ 保存配置失败:', error);
    }
}

/**
 * 获取当前配置
 */
function getCurrentConfig() {
    const maxBreakDistanceEl = document.getElementById('max-break-distance');
    const bufferDistanceEl = document.getElementById('buffer-distance');
    const conflictGridSizeEl = document.getElementById('conflict-grid-size');
    const claimsGridSizeEl = document.getElementById('claims-grid-size');
    const removalPercentageEl = document.getElementById('removal-percentage');

    return {
        maxBreakDistance: maxBreakDistanceEl ? parseInt(maxBreakDistanceEl.value) : 100,
        bufferDistance: bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5,
        conflictGridSize: conflictGridSizeEl ? parseInt(conflictGridSizeEl.value) : 4,
        claimsGridSize: claimsGridSizeEl ? parseInt(claimsGridSizeEl.value) : 4,
        removalPercentage: removalPercentageEl ? parseInt(removalPercentageEl.value) : 10,
        // 使用固定的默认值
        enableMerging: true,
        useConvexHull: true,
        showConflictAreas: true,
        autoFitView: true,
        savedAt: new Date().toISOString()
    };
}

/**
 * 加载存储的配置
 */
async function loadStoredConfig() {
    try {
        if (typeof getStoredClaimsConfig === 'function') {
            const config = await getStoredClaimsConfig();
            if (config) {
                applyConfig(config);
                console.log('✅ 已加载存储的配置:', config);
                return true;
            }
        }
        return false;
    } catch (error) {
        console.warn('⚠️ 加载配置失败:', error);
        return false;
    }
}

/**
 * 应用配置到界面
 */
function applyConfig(config) {
    const maxBreakDistanceEl = document.getElementById('max-break-distance');
    const bufferDistanceEl = document.getElementById('buffer-distance');
    const conflictGridSizeEl = document.getElementById('conflict-grid-size');
    const claimsGridSizeEl = document.getElementById('claims-grid-size');
    const removalPercentageEl = document.getElementById('removal-percentage');

    if (maxBreakDistanceEl && config.maxBreakDistance !== undefined) {
        maxBreakDistanceEl.value = config.maxBreakDistance;
    }
    if (bufferDistanceEl && config.bufferDistance !== undefined) {
        bufferDistanceEl.value = config.bufferDistance;
    }
    if (conflictGridSizeEl && config.conflictGridSize !== undefined) {
        conflictGridSizeEl.value = config.conflictGridSize;
    }
    if (claimsGridSizeEl && config.claimsGridSize !== undefined) {
        claimsGridSizeEl.value = config.claimsGridSize;
    }
    if (removalPercentageEl && config.removalPercentage !== undefined) {
        removalPercentageEl.value = config.removalPercentage;
    }
    // 已移除的配置选项，现在使用固定默认值

    // 更新显示值
    updateClusteringConfig();
    updateBufferConfig();
    updateConflictGridConfig();
    updateClaimsGridConfig();
    updateRemovalConfig();
    updateDisplayConfig();

    // 确保步骤2按钮文本正确
    if (config.bufferDistance !== undefined) {
        updateStep2ButtonText(config.bufferDistance);
    }
}

/**
 * 初始化配置显示值
 */
async function initializeConfigDisplay() {
    try {
        // 先尝试加载存储的配置
        const loaded = await loadStoredConfig();

        if (!loaded) {
            // 如果没有存储的配置，使用默认值
            updateClusteringConfig();
            updateBufferConfig();
            updateConflictGridConfig();
            updateClaimsGridConfig();
            updateRemovalConfig();
            updateDisplayConfig();

            // 确保步骤2按钮文本使用默认值
            const bufferDistanceEl = document.getElementById('buffer-distance');
            const defaultBufferDistance = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
            updateStep2ButtonText(defaultBufferDistance);
        }
    } catch (error) {
        console.warn('⚠️ 配置初始化时发生错误:', error.message);
        // 出错时使用默认配置
        updateClusteringConfig();
        updateBufferConfig();
        updateConflictGridConfig();
        updateClaimsGridConfig();
        updateRemovalConfig();
        updateDisplayConfig();
    }
}

/**
 * 缓冲配置更新函数 (新的简化版本)
 */
async function updateBufferConfig() {
    const bufferDistanceEl = document.getElementById('buffer-distance');

    if (bufferDistanceEl) {
        const value = parseInt(bufferDistanceEl.value);
        const valueDisplayEl = document.getElementById('buffer-distance-value');
        if (valueDisplayEl) {
            valueDisplayEl.textContent = `${value}区块 (${value * 16}方块)`;
        }

        // 更新步骤2按钮的文本
        updateStep2ButtonText(value);

        console.log(`🔧 缓冲距离配置已更新: ${value}区块 (${value * 16}方块)`);

        // 保存配置到存储
        await saveCurrentConfig();
    } else {
        console.log('🔧 缓冲距离配置元素未找到，使用默认值');
    }
}

/**
 * 更新删除百分比配置显示
 */
async function updateRemovalConfig() {
    const removalSlider = document.getElementById('removal-percentage');

    if (removalSlider) {
        const percentage = parseInt(removalSlider.value);
        const valueDisplayEl = document.getElementById('removal-percentage-value');
        if (valueDisplayEl) {
            valueDisplayEl.textContent = `删除最远的 ${percentage}% 栅格`;
        }

        console.log(`🔧 步骤10删除百分比已更新: ${percentage}%`);

        // 保存配置到存储
        await saveCurrentConfig();
    } else {
        console.log('🔧 删除百分比配置元素未找到，使用默认值');
    }
}

/**
 * 获取删除百分比配置
 */
function getRemovalPercentage() {
    const removalSlider = document.getElementById('removal-percentage');
    return removalSlider ? parseInt(removalSlider.value) : 10; // 默认10%
}

/**
 * 更新步骤4冲突栅格大小配置显示
 */
async function updateConflictGridConfig() {
    const gridSizeSlider = document.getElementById('conflict-grid-size');

    if (gridSizeSlider) {
        const gridSize = parseInt(gridSizeSlider.value);
        const blockSize = gridSize * 16; // 每个区块16x16方块
        const valueDisplayEl = document.getElementById('conflict-grid-size-value');
        if (valueDisplayEl) {
            valueDisplayEl.textContent = `${gridSize}区块 (${blockSize}方块)`;
        }

        console.log(`🔧 步骤4冲突栅格大小配置已更新: ${gridSize}区块 (${blockSize}方块)`);

        // 保存配置到存储
        await saveCurrentConfig();
    } else {
        console.log('🔧 步骤4冲突栅格大小配置元素未找到，使用默认值');
    }
}

/**
 * 更新步骤8宣称栅格大小配置显示
 */
async function updateClaimsGridConfig() {
    const gridSizeSlider = document.getElementById('claims-grid-size');

    if (gridSizeSlider) {
        const gridSize = parseInt(gridSizeSlider.value);
        const blockSize = gridSize * 16; // 每个区块16x16方块
        const valueDisplayEl = document.getElementById('claims-grid-size-value');
        if (valueDisplayEl) {
            valueDisplayEl.textContent = `${gridSize}区块 (${blockSize}方块)`;
        }

        console.log(`🔧 步骤8宣称栅格大小配置已更新: ${gridSize}区块 (${blockSize}方块)`);

        // 保存配置到存储
        await saveCurrentConfig();
    } else {
        console.log('🔧 步骤8宣称栅格大小配置元素未找到，使用默认值');
    }
}

/**
 * 更新删除百分比配置显示
 */
async function updateRemovalConfig() {
    const removalSlider = document.getElementById('removal-percentage');

    if (removalSlider) {
        const percentage = parseInt(removalSlider.value);
        const valueDisplayEl = document.getElementById('removal-percentage-value');
        if (valueDisplayEl) {
            valueDisplayEl.textContent = `删除最远的 ${percentage}% 栅格`;
        }

        console.log(`🔧 步骤10删除百分比已更新: ${percentage}%`);

        // 保存配置到存储
        await saveCurrentConfig();
    } else {
        console.log('🔧 删除百分比配置元素未找到，使用默认值');
    }
}

/**
 * 获取步骤4冲突栅格大小配置
 */
function getConflictGridSize() {
    const gridSizeSlider = document.getElementById('conflict-grid-size');
    return gridSizeSlider ? parseInt(gridSizeSlider.value) : 4; // 默认4区块
}

/**
 * 获取步骤8宣称栅格大小配置
 */
function getClaimsGridSize() {
    const gridSizeSlider = document.getElementById('claims-grid-size');
    return gridSizeSlider ? parseInt(gridSizeSlider.value) : 4; // 默认4区块
}

/**
 * 获取删除百分比配置
 */
function getRemovalPercentage() {
    const removalSlider = document.getElementById('removal-percentage');
    return removalSlider ? parseInt(removalSlider.value) : 10; // 默认10%
}

/**
 * 更新步骤2按钮的文本
 */
function updateStep2ButtonText(bufferDistanceChunks) {
    const step2TextEl = document.querySelector('#step2-btn span span:first-child');
    if (step2TextEl) {
        const bufferDistanceBlocks = bufferDistanceChunks * 16;
        step2TextEl.textContent = `2️⃣ 每个领地区域扩张${bufferDistanceBlocks}方块`;
        console.log(`🔄 步骤2按钮文本已更新: ${bufferDistanceBlocks}方块`);
    } else {
        console.warn('⚠️ 未找到步骤2按钮文本元素，无法更新文本');
    }
}

/**
 * 显示配置更新函数
 */
async function updateDisplayConfig() {
    // 使用固定的默认值，不再从UI获取
    const config = {
        showConflictAreas: true,
        autoFitView: true
    };

    console.log('🔧 显示配置已更新:', config);

    // 保存配置到存储
    await saveCurrentConfig();
}

/**
 * 更新优化配置显示
 */
function updateOptimizationConfig() {
    try {
        const gridSizeSlider = document.getElementById('optimization-grid-size');
        const gridSizeValue = document.getElementById('optimization-grid-size-value');

        if (gridSizeSlider && gridSizeValue) {
            const gridSize = parseInt(gridSizeSlider.value);
            const blockSize = gridSize * 16; // 每个区块16x16方块
            gridSizeValue.textContent = `${gridSize}区块 (${blockSize}方块)`;
        } else {
            console.log('🔧 优化配置元素未找到，跳过更新');
        }
    } catch (error) {
        console.warn('⚠️ 更新优化配置时发生错误:', error.message);
    }
}

/**
 * 获取当前优化配置
 */
function getOptimizationConfig() {
    const gridSizeSlider = document.getElementById('optimization-grid-size');
    const showConflictAreas = document.getElementById('show-conflict-areas');
    const autoRefresh = document.getElementById('auto-refresh-after-optimization');

    return {
        // 基础配置
        gridSize: gridSizeSlider ? parseInt(gridSizeSlider.value) : 4,
        showConflictAreas: showConflictAreas ? showConflictAreas.checked : true,
        autoRefresh: autoRefresh ? autoRefresh.checked : true,
        samplingDensity: 1,

        // 新增的Turf.js相关配置
        highPrecision: true, // 启用高精度几何处理
        minDistanceThreshold: 50, // 最小距离阈值（方块）
        minAreaThreshold: 1000, // 最小面积阈值（平方米）

        // 调试和验证选项
        debug: true,
        validateGeometry: true,
        cleanCoordinates: true
    };
}

// 导出配置和函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        MC_BOUNDS,
        WORLD_WIDTH,
        WORLD_HEIGHT,
        MAP_CONFIG,
        updateClusteringConfig,
        initializeConfigDisplay,
        updateBufferConfig,
        updateConflictGridConfig,
        updateClaimsGridConfig,
        updateRemovalConfig,
        getConflictGridSize,
        getClaimsGridSize,
        getRemovalPercentage,
        updateDisplayConfig,
        updateOptimizationConfig,
        getOptimizationConfig
    };
}
