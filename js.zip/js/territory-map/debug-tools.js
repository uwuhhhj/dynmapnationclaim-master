/**
 * 调试与开发工具模块
 * 提供各种调试、验证和开发辅助功能
 */

/**
 * 调试：检查国家领地数据质量
 */
async function debugCountryTerritoryData() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        updateStatus('info', '正在检查国家领地数据质量...');

        const allTerritories = await countryClaimsManager.loadAllCountryTerritories();

        console.log('🔍 国家领地数据质量报告:');
        console.log(`总国家数: ${allTerritories.size}`);

        for (const [countryName, polygons] of allTerritories) {
            console.log(`\n🏛️ 国家: ${countryName}`);
            console.log(`  多边形数量: ${polygons.length}`);

            polygons.forEach((polygon, index) => {
                const coords = polygon.geometry.coordinates[0];
                console.log(`  多边形 ${index}: ${coords.length} 个坐标点`);

                // 检查坐标范围
                const xCoords = coords.map(c => c[0]);
                const zCoords = coords.map(c => c[1]);
                const xRange = [Math.min(...xCoords), Math.max(...xCoords)];
                const zRange = [Math.min(...zCoords), Math.max(...zCoords)];

                console.log(`    X 范围: [${xRange[0].toFixed(2)}, ${xRange[1].toFixed(2)}]`);
                console.log(`    Z 范围: [${zRange[0].toFixed(2)}, ${zRange[1].toFixed(2)}]`);

                // 计算面积
                try {
                    const area = turf.area(polygon);
                    console.log(`    面积: ${area.toFixed(2)} 平方米`);
                } catch (error) {
                    console.log(`    面积计算失败: ${error.message}`);
                }
            });
        }

        updateStatus('success', `数据质量检查完成，详情请查看控制台`);

    } catch (error) {
        console.error('❌ 数据质量检查失败:', error);
        updateStatus('error', `检查失败: ${error.message}`);
    }
}

/**
 * 调试：检查生成的宣称数据状态
 */
function debugGeneratedClaimsStatus() {
    if (countryClaimsManager) {
        return countryClaimsManager.getGeneratedClaimsStatus();
    } else {
        console.error('❌ 国家宣称管理器未初始化');
        return null;
    }
}

/**
 * 检查数据状态（调试用）
 */
async function checkDataStatus() {
    console.log('🔍 检查数据状态...');

    try {
        const markers = await getStoredMarkers();
        const areas = await getStoredAreas();
        const countrySpawn = await getStoredCountrySpawn();
        const countryAreas = await getStoredCountryAreas();
        const countryClaims = await getStoredCountryClaims();

        const status = {
            markers: markers ? Object.keys(markers).length : 0,
            areas: areas ? Object.keys(areas).length : 0,
            countrySpawn: countrySpawn ? Object.keys(countrySpawn).length : 0,
            countryAreas: countryAreas ? Object.keys(countryAreas).length : 0,
            countryClaims: countryClaims ? Object.keys(countryClaims).length : 0,
            countryClaimsManagerInitialized: !!countryClaimsManager,
            countryClaimsManagerHasData: countryClaimsManager ?
                (countryClaimsManager.countrySpawnData && countryClaimsManager.countryAreaData) : false
        };

        console.log('📊 数据状态:', status);

        let message = `数据状态检查:\n`;
        message += `• 原始标记: ${status.markers} 个\n`;
        message += `• 原始区域: ${status.areas} 个\n`;
        message += `• 国家出生点: ${status.countrySpawn} 个国家\n`;
        message += `• 国家区域: ${status.countryAreas} 个国家\n`;
        message += `• 已生成宣称: ${status.countryClaims} 个国家\n`;
        message += `• 管理器状态: ${status.countryClaimsManagerInitialized ? '已初始化' : '未初始化'}\n`;

        if (status.countrySpawn === 0 && status.countryAreas === 0) {
            message += `\n⚠️ 建议：先点击"🔄 加载领地数据"获取数据`;
        } else if (status.countryClaims === 0) {
            message += `\n✅ 可以点击"⚙️ 生成宣称数据"生成宣称范围`;
        } else {
            message += `\n✅ 数据完整，可以显示宣称范围`;
        }

        updateStatus('info', message);
        alert(message);

    } catch (error) {
        console.error('❌ 检查数据状态失败:', error);
        updateStatus('error', `检查失败: ${error.message}`);
    }
}

/**
 * 检查7步骤流程的执行状态
 */
function checkAdvancedProcessStatus() {
    console.log('🔍 检查高级冲突处理流程状态...');

    const status = {
        mainProcess: {
            step1: countryClaimsManager?.stepData?.step1_originalTerritories?.size > 0,
            step2: countryClaimsManager?.stepData?.step2_bufferedTerritories?.size > 0,
            step3: countryClaimsManager?.stepData?.step3_mergedTerritories?.size > 0,
            step4: countryClaimsManager?.stepData?.step4_simplifiedTerritories?.size > 0,
            step5: countryClaimsManager?.generatedClaims?.size > 0
        },
        advancedProcess: {
            step1: optimizationState.claimBlocks.size > 0,
            step2: optimizationState.conflicts.length > 0,
            step3: optimizationState.cleanedClaimBlocks.size > 0,
            step4: optimizationState.gridCells.size > 0,
            step5: optimizationState.cellAssignments.size > 0,
            step6: optimizationState.mergedAreas?.size > 0,
            step7: optimizationState.finalBoundaries?.size > 0
        }
    };

    console.log('📊 流程状态报告:');
    console.log('主流程 (步骤1-5):', status.mainProcess);
    console.log('高级冲突处理 (步骤1-7):', status.advancedProcess);

    // 生成状态消息
    const mainCompleted = Object.values(status.mainProcess).filter(Boolean).length;
    const advancedCompleted = Object.values(status.advancedProcess).filter(Boolean).length;

    let message = `主流程: ${mainCompleted}/5 完成`;
    if (mainCompleted === 5) {
        message += ' ✅';
    } else {
        message += ` (需要完成步骤${Object.keys(status.mainProcess).find((key, i) => !Object.values(status.mainProcess)[i])?.replace('step', '')})`;
    }

    message += ` | 高级流程: ${advancedCompleted}/7 完成`;

    updateStatus('info', message);

    return status;
}

/**
 * 调试函数：检查当前宣称数据状态
 */
async function debugCurrentClaimsData() {
    if (!countryClaimsManager) {
        console.log('❌ 国家宣称管理器未初始化');
        return;
    }

    console.log('🔍 当前宣称数据状态检查:');
    console.log('='.repeat(60));

    // 1. 检查内存中的生成数据
    console.log('📊 内存中的生成数据:');
    console.log(`   generatedClaims 大小: ${countryClaimsManager.generatedClaims.size}`);

    for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
        console.log(`\n🏛️ 国家: ${countryName}`);
        console.log(`  成功状态: ${claimsResult?.success}`);

        if (claimsResult && claimsResult.success && claimsResult.claims) {
            console.log(`  宣称区域数量: ${claimsResult.claims.length}`);

            claimsResult.claims.forEach((claim, i) => {
                console.log(`  区域 ${i+1}:`);
                console.log(`    ID: ${claim.id}`);
                console.log(`    边界类型: ${claim.metadata?.boundaryType || 'unknown'}`);
                console.log(`    顶点数量: ${claim.boundary?.length || 0}`);
                console.log(`    面积: ${claim.metadata?.area || 'unknown'}`);
                if (claim.metadata?.optimizedAt) {
                    console.log(`    优化时间: ${claim.metadata.optimizedAt}`);
                }
            });
        } else {
            console.log(`  ⚠️ 没有有效的宣称数据`);
        }
    }

    // 2. 检查IndexedDB状态
    console.log('\n💾 IndexedDB 状态检查:');

    try {
        const allKeys = await IndexedDBStorage.getAllKeys();
        console.log(`   IndexedDB 总键数: ${allKeys.length}`);
        console.log(`   所有键: [${allKeys.join(', ')}]`);

        // 特别检查国家宣称数据
        const countryClaimsData = await IndexedDBStorage.getItem('countryClaims');
        console.log(`   countryClaims 键: ${countryClaimsData === null ? '❌ 不存在' : '✅ 存在'}`);

        if (countryClaimsData !== null) {
            try {
                const parsed = JSON.parse(countryClaimsData);
                const storedCountries = Object.keys(parsed);
                console.log(`   存储的国家数量: ${storedCountries.length}`);
                console.log(`   存储的国家: [${storedCountries.join(', ')}]`);

                for (const [countryName, claims] of Object.entries(parsed)) {
                    console.log(`     ${countryName}: ${claims.length} 个宣称区域`);
                }
            } catch (e) {
                console.log(`   ❌ 解析错误: ${e.message}`);
            }
        }
    } catch (error) {
        console.error('❌ 检查IndexedDB状态失败:', error);
    }

    // 3. 检查优化状态
    if (typeof optimizationState !== 'undefined') {
        console.log('\n🔧 优化状态:');
        console.log(`   冲突数量: ${optimizationState.conflicts.length}`);
        console.log(`   栅格单元: ${optimizationState.gridCells.size} 个冲突区域`);
        console.log(`   单元分配: ${optimizationState.cellAssignments.size} 个冲突区域`);
        console.log(`   宣称块: ${optimizationState.claimBlocks.size} 个国家`);
        console.log(`   最终边界: ${optimizationState.finalBoundaries.size} 个国家`);
    }

    console.log('='.repeat(60));
    updateStatus('info', '调试信息已输出到控制台，请查看详细状态');
}

/**
 * 调试函数：检查生成的宣称数据结构
 */
function debugGeneratedClaimsStructure() {
    console.log('🔍 检查生成的宣称数据结构...');

    if (!countryClaimsManager || countryClaimsManager.generatedClaims.size === 0) {
        console.log('❌ 没有生成的宣称数据');
        return;
    }

    for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
        console.log(`🏛️ 国家: ${countryName}`);
        console.log(`   成功: ${claimsResult.success}`);

        if (claimsResult.claims) {
            console.log(`   宣称数量: ${claimsResult.claims.length}`);

            claimsResult.claims.forEach((claim, index) => {
                console.log(`   宣称 ${index}:`);
                console.log(`     ID: ${claim.id}`);
                console.log(`     边界类型: ${Array.isArray(claim.boundary) ? 'Array' : typeof claim.boundary}`);

                if (Array.isArray(claim.boundary)) {
                    console.log(`     边界长度: ${claim.boundary.length}`);
                    if (claim.boundary.length > 0) {
                        console.log(`     第一个元素类型: ${Array.isArray(claim.boundary[0]) ? 'Array (多环)' : typeof claim.boundary[0]}`);
                        if (Array.isArray(claim.boundary[0])) {
                            console.log(`     外环坐标数: ${claim.boundary[0].length}`);
                        }
                    }
                }

                console.log(`     面积: ${claim.area || claim.metadata?.area || 'unknown'}`);
            });
        }
    }
}

/**
 * 验证优化是否生效
 */
function verifyOptimization() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    console.log('🔍 开始验证优化效果...');

    // 检测当前的冲突
    const conflictResult = countryClaimsManager.detectBoundaryConflicts();

    if (conflictResult.success) {
        const conflictCount = conflictResult.conflicts.length;

        if (conflictCount === 0) {
            console.log('✅ 验证成功：没有检测到边界冲突');
            updateStatus('success', '✅ 优化验证成功：所有边界冲突已解决');
        } else {
            console.log(`⚠️ 验证发现问题：仍有 ${conflictCount} 个边界冲突`);
            updateStatus('warning', `⚠️ 优化验证：仍有 ${conflictCount} 个未解决的冲突`);

            // 显示剩余冲突的详细信息
            conflictResult.conflicts.forEach((conflict, i) => {
                console.log(`冲突 ${i+1}: ${conflict.countries.join(' vs ')}, 面积: ${Math.round(conflict.area)}`);
            });
        }

        // 统计优化后的边界类型
        let optimizedCount = 0;
        let totalClaims = 0;

        for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
            if (claimsResult && claimsResult.success && claimsResult.claims) {
                totalClaims += claimsResult.claims.length;
                claimsResult.claims.forEach(claim => {
                    if (claim.metadata?.boundaryType === 'optimized') {
                        optimizedCount++;
                    }
                });
            }
        }

        console.log(`📊 边界统计: ${optimizedCount}/${totalClaims} 个区域已优化`);

    } else {
        console.error('❌ 验证失败:', conflictResult.error);
        updateStatus('error', `验证失败: ${conflictResult.error}`);
    }
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        debugCountryTerritoryData,
        debugGeneratedClaimsStatus,
        checkDataStatus,
        checkAdvancedProcessStatus,
        debugCurrentClaimsData,
        debugGeneratedClaimsStructure,
        verifyOptimization
    };
}
