/**
 * 高级冲突处理模块
 * 包含7步骤宣称切割流程和冲突区域可视化功能
 */

/**
 * 步骤1: 构建宣称块
 * 对每个国家的出生点进行聚类，合并实际领地边界，应用缓冲扩张
 */
function step1_buildClaimBlocks() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    console.log('1️⃣ 开始构建宣称块...');
    updateStatus('info', '步骤1: 正在构建宣称块...');

    try {
        // 检查是否已有生成的宣称数据
        if (countryClaimsManager.generatedClaims.size === 0) {
            updateStatus('warning', '请先完成步骤1-5: 生成国家宣称范围数据');
            console.log('⚠️ 需要先执行主流程的步骤1-5来生成宣称数据');
            console.log('   1. 获取原始领地数据');
            console.log('   2. 每个领地区域扩张80方块');
            console.log('   3. 合并同一国家的缓冲区');
            console.log('   4. 简化多边形边界');
            console.log('   5. 生成最终宣称范围');
            return;
        }

        // 重置优化状态
        optimizationState.conflicts = [];
        optimizationState.gridCells.clear();
        optimizationState.cellAssignments.clear();
        optimizationState.cuttingResults.clear();
        optimizationState.claimBlocks = new Map();
        optimizationState.conflictAreas = new Map();
        optimizationState.cleanedClaimBlocks = new Map();
        optimizationState.mergedClaimBlocks = new Map();
        optimizationState.finalBoundaries = new Map();

        let totalBlocks = 0;

        // 为每个国家构建宣称块
        for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
            if (!claimsResult.success || !claimsResult.claims) {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称数据`);
                continue;
            }

            console.log(`🏛️ 为国家 "${countryName}" 构建宣称块...`);

            // 每个宣称区域就是一个宣称块
            const claimBlocks = claimsResult.claims.map((claim, index) => {
                // 正确处理多环边界结构，并转换为MC坐标
                let boundary = [];

                if (claim.boundary && Array.isArray(claim.boundary)) {
                    let mapCoords = [];

                    if (claim.boundary.length > 0 && Array.isArray(claim.boundary[0])) {
                        // 多环结构，取第一个环（外环）
                        mapCoords = claim.boundary[0];
                    } else {
                        // 单环结构（向后兼容）
                        mapCoords = claim.boundary;
                    }

                    // 将地图坐标转换为MC坐标
                    if (mapCoords.length >= 3) {
                        boundary = mapCoords.map(mapCoord => {
                            if (Array.isArray(mapCoord) && mapCoord.length >= 2) {
                                const mcCoords = mapToMcCoords(mapCoord[0], mapCoord[1]);
                                return [mcCoords.x, mcCoords.z];
                            } else {
                                console.warn(`⚠️ 无效的地图坐标:`, mapCoord);
                                return null;
                            }
                        }).filter(coord => coord !== null);
                    }
                } else {
                    console.warn(`⚠️ 国家 "${countryName}" 宣称块 ${index} 边界数据无效:`, claim.boundary);
                }

                return {
                    id: `${countryName}_block_${index}`,
                    countryName: countryName,
                    boundary: boundary, // 现在是MC坐标数组 [[x1, z1], [x2, z2], ...]
                    originalClaimId: claim.id,
                    area: claim.metadata?.area || claim.area || 0,
                    spawnPoints: claim.spawnPoints || [],
                    metadata: {
                        ...claim.metadata,
                        blockType: 'original-claim',
                        constructedAt: new Date().toISOString()
                    }
                };
            }).filter(block => block.boundary.length >= 3); // 过滤掉坐标不足的块

            if (claimBlocks.length > 0) {
                optimizationState.claimBlocks.set(countryName, claimBlocks);
                totalBlocks += claimBlocks.length;
                console.log(`   构建了 ${claimBlocks.length} 个宣称块`);

                // 调试信息：显示每个块的边界点数
                claimBlocks.forEach((block, i) => {
                    console.log(`     块 ${i}: ${block.boundary.length} 个坐标点`);
                });
            } else {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称块（所有块的坐标都不足3个点）`);
            }
        }

        console.log(`✅ 宣称块构建完成！总计 ${totalBlocks} 个宣称块`);
        updateStatus('success', `步骤1完成: 构建了 ${totalBlocks} 个宣称块`);

        // 可视化宣称块（重用现有显示功能）
        countryClaimsManager.clearDisplayedLayers();
        setTimeout(() => {
            countryClaimsManager.showCurrentGeneratedClaims();
        }, 300);

    } catch (error) {
        console.error('❌ 构建宣称块失败:', error);
        updateStatus('error', `步骤1失败: ${error.message}`);
    }
}

// 使用 ConflictUtils.validateTurfGeometry 替代

// 使用 ConflictUtils.createValidTurfPolygon 替代

/**
 * 步骤2: 检测冲突区域（重新设计：找出所有重叠区域）
 * 找出所有的重叠区域，无论是2国重叠还是多国重叠，这些区域都成为冲突区域
 */
function step2_detectConflictAreas() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.claimBlocks.size === 0) {
        console.log('⚠️ 宣称块未构建，尝试自动执行步骤1...');
        updateStatus('info', '自动执行步骤1: 构建宣称块...');

        // 检查是否有生成的宣称数据
        if (countryClaimsManager.generatedClaims.size === 0) {
            updateStatus('error', '请先完成主流程步骤1-5生成宣称数据，然后再使用高级冲突处理');
            console.log('❌ 无法自动执行步骤1：缺少宣称数据');
            console.log('   请先执行主流程的步骤1-5来生成国家宣称范围数据');
            return;
        }

        // 自动执行步骤1
        step1_buildClaimBlocks();

        // 检查步骤1是否成功
        if (optimizationState.claimBlocks.size === 0) {
            updateStatus('error', '步骤1执行失败，无法继续检测冲突');
            return;
        }

        console.log('✅ 步骤1自动执行完成，继续检测冲突...');
    }

    console.log('2️⃣ 开始检测冲突区域（找出所有重叠区域）...');
    updateStatus('info', '步骤2: 正在检测所有重叠区域...');

    try {
        // 检查Turf.js是否可用
        if (typeof turf === 'undefined') {
            throw new Error('Turf.js库未加载，无法进行精确几何检测');
        }

        // 清空之前的冲突数据
        optimizationState.conflictAreas.clear();
        optimizationState.conflicts = [];

        const countries = Array.from(optimizationState.claimBlocks.keys());
        console.log(`🔍 检测 ${countries.length} 个国家之间的所有重叠区域...`);

        // 构建所有国家的宣称多边形集合
        const allPolygons = [];
        for (const [countryName, claimBlocks] of optimizationState.claimBlocks) {
            for (const block of claimBlocks) {
                const polygon = createValidTurfPolygon(block.boundary);
                if (polygon) {
                    allPolygons.push({
                        polygon: polygon,
                        countryName: countryName,
                        blockId: block.id
                    });
                }
            }
        }

        console.log(`📐 构建了 ${allPolygons.length} 个宣称多边形`);

        // 使用新的算法检测所有重叠区域
        const conflictRegions = findAllOverlapRegions(allPolygons);

        // 为每个冲突区域分配ID并存储
        let totalConflicts = 0;
        for (const region of conflictRegions) {
            const conflictId = `conflict_${totalConflicts}`;

            const conflictInfo = {
                id: conflictId,
                countries: region.countries,
                blocks: region.blocks,
                intersectionGeometry: region.geometry,
                area: region.area,
                bounds: region.bounds,
                detectedAt: new Date().toISOString(),
                isMultiCountry: region.countries.length > 2
            };

            optimizationState.conflictAreas.set(conflictId, conflictInfo);
            optimizationState.conflicts.push(conflictInfo);
            totalConflicts++;

            const typeLabel = region.countries.length > 2 ? '多国重叠' : '两国重叠';
            console.log(`   🎯 ${typeLabel}: ${conflictId}, 涉及国家: ${region.countries.join(', ')}, 面积: ${Math.round(region.area)} 平方米`);
        }

        console.log(`✅ 冲突检测完成！发现 ${totalConflicts} 个重叠区域`);
        updateStatus('success', `步骤2完成: 检测到 ${totalConflicts} 个冲突区域`);

        // 可视化冲突区域
        if (totalConflicts > 0) {
            visualizeConflictAreas();
        }

    } catch (error) {
        console.error('❌ 冲突检测失败:', error);
        updateStatus('error', `步骤2失败: ${error.message}`);
    }
}

/**
 * 找出所有重叠区域（新算法）
 * @param {Array} allPolygons - 所有国家的宣称多边形数组
 * @returns {Array} 冲突区域数组
 */
function findAllOverlapRegions(allPolygons) {
    console.log('🔍 开始查找所有重叠区域...');

    const conflictRegions = [];
    const processedPairs = new Set();

    // 第一步：找出所有两两相交的多边形对
    const intersectionPairs = [];

    for (let i = 0; i < allPolygons.length; i++) {
        for (let j = i + 1; j < allPolygons.length; j++) {
            const poly1 = allPolygons[i];
            const poly2 = allPolygons[j];

            // 跳过同一国家的多边形
            if (poly1.countryName === poly2.countryName) {
                continue;
            }

            try {
                const intersection = turf.intersect(poly1.polygon, poly2.polygon);

                if (intersection && intersection.geometry) {
                    const intersectionArea = turf.area(intersection);

                    if (intersectionArea > 1000) { // 只考虑面积大于1000平方米的重叠
                        intersectionPairs.push({
                            poly1: poly1,
                            poly2: poly2,
                            intersection: intersection,
                            area: intersectionArea,
                            countries: [poly1.countryName, poly2.countryName].sort()
                        });

                        console.log(`   发现重叠: ${poly1.countryName} vs ${poly2.countryName}, 面积: ${Math.round(intersectionArea)} 平方米`);
                    }
                }
            } catch (error) {
                console.warn(`⚠️ 检测重叠时出错: ${poly1.blockId} vs ${poly2.blockId}:`, error.message);
            }
        }
    }

    console.log(`📊 发现 ${intersectionPairs.length} 个两两重叠区域`);

    // 第二步：合并重叠的相交区域，形成最终的冲突区域
    const mergedRegions = mergeIntersectionRegions(intersectionPairs);

    console.log(`✅ 重叠区域查找完成: 发现 ${mergedRegions.length} 个最终冲突区域`);
    return mergedRegions;
}

/**
 * 合并相交区域，处理多国重叠情况
 * @param {Array} intersectionPairs - 两两相交的区域数组
 * @returns {Array} 合并后的冲突区域数组
 */
function mergeIntersectionRegions(intersectionPairs) {
    console.log('🔄 开始合并相交区域...');

    if (intersectionPairs.length === 0) {
        return [];
    }

    const mergedRegions = [];
    const processed = new Set();

    for (let i = 0; i < intersectionPairs.length; i++) {
        if (processed.has(i)) {
            continue;
        }

        const currentPair = intersectionPairs[i];
        let mergedGeometry = currentPair.intersection;
        let mergedCountries = new Set(currentPair.countries);
        let mergedBlocks = new Set([currentPair.poly1.blockId, currentPair.poly2.blockId]);
        let mergedArea = currentPair.area;

        processed.add(i);

        // 查找与当前区域重叠的其他区域
        let foundOverlap = true;
        while (foundOverlap) {
            foundOverlap = false;

            for (let j = 0; j < intersectionPairs.length; j++) {
                if (processed.has(j)) {
                    continue;
                }

                const otherPair = intersectionPairs[j];

                // 检查是否有共同的国家或几何重叠
                const hasCommonCountry = otherPair.countries.some(country => mergedCountries.has(country));

                if (hasCommonCountry) {
                    try {
                        // 检查几何重叠
                        const geometryOverlap = turf.intersect(mergedGeometry, otherPair.intersection);

                        if (geometryOverlap && geometryOverlap.geometry) {
                            const overlapArea = turf.area(geometryOverlap);

                            // 如果重叠面积超过较小区域的30%，则合并
                            const minArea = Math.min(mergedArea, otherPair.area);
                            if (overlapArea > minArea * 0.3) {
                                // 合并区域
                                try {
                                    const union = turf.union(mergedGeometry, otherPair.intersection);
                                    if (union && union.geometry) {
                                        mergedGeometry = union;
                                        mergedArea = turf.area(union);
                                    }
                                } catch (unionError) {
                                    console.warn('⚠️ 几何合并失败，保持原有区域:', unionError.message);
                                }

                                // 合并国家和块信息
                                otherPair.countries.forEach(country => mergedCountries.add(country));
                                mergedBlocks.add(otherPair.poly1.blockId);
                                mergedBlocks.add(otherPair.poly2.blockId);

                                processed.add(j);
                                foundOverlap = true;

                                console.log(`   合并区域: 现在涉及 ${mergedCountries.size} 个国家`);
                            }
                        }
                    } catch (error) {
                        console.warn('⚠️ 检查几何重叠时出错:', error.message);
                    }
                }
            }
        }

        // 创建最终的冲突区域
        const conflictRegion = {
            countries: Array.from(mergedCountries).sort(),
            blocks: Array.from(mergedBlocks),
            geometry: mergedGeometry,
            area: mergedArea,
            bounds: turf.bbox(mergedGeometry)
        };

        mergedRegions.push(conflictRegion);

        const typeLabel = mergedCountries.size > 2 ? '多国重叠' : '两国重叠';
        console.log(`   生成${typeLabel}: ${Array.from(mergedCountries).join(', ')}, 面积: ${Math.round(mergedArea)} 平方米`);
    }

    console.log(`✅ 区域合并完成: ${intersectionPairs.length} 个原始重叠 → ${mergedRegions.length} 个最终冲突区域`);
    return mergedRegions;
}

/**
 * 使用空间分析检测真正的重叠区域（已弃用，保留用于兼容性）
 * @param {Array} allPolygons - 所有国家的宣称多边形数组
 * @returns {Array} 冲突区域数组
 */
function detectSpatialOverlaps(allPolygons) {
    console.log('🔍 开始空间重叠分析...');

    const conflictRegions = [];
    const processedAreas = new Set(); // 用于避免重复处理同一区域

    // 为每个多边形检测与其他多边形的重叠
    for (let i = 0; i < allPolygons.length; i++) {
        const currentPoly = allPolygons[i];

        // 查找与当前多边形重叠的所有其他多边形
        const overlappingPolygons = [];
        const involvedCountries = new Set([currentPoly.countryName]);
        const involvedBlocks = new Set([currentPoly.blockId]);

        for (let j = 0; j < allPolygons.length; j++) {
            if (i === j) continue;

            const otherPoly = allPolygons[j];

            try {
                // 检测两个多边形是否相交
                const intersection = turf.intersect(currentPoly.polygon, otherPoly.polygon);

                if (intersection && intersection.geometry) {
                    const intersectionArea = turf.area(intersection);

                    if (intersectionArea > 1000) { // 只考虑面积大于1000平方米的重叠
                        overlappingPolygons.push({
                            polygon: otherPoly,
                            intersection: intersection,
                            area: intersectionArea
                        });
                        involvedCountries.add(otherPoly.countryName);
                        involvedBlocks.add(otherPoly.blockId);
                    }
                }
            } catch (error) {
                console.warn(`⚠️ 检测重叠时出错: ${currentPoly.blockId} vs ${otherPoly.blockId}:`, error.message);
            }
        }

        // 如果发现重叠，计算总的重叠区域
        if (overlappingPolygons.length > 0) {
            try {
                // 创建区域标识符，用于避免重复处理
                const regionId = Array.from(involvedCountries).sort().join('_') + '_' +
                               Array.from(involvedBlocks).sort().join('_');

                if (processedAreas.has(regionId)) {
                    continue; // 跳过已处理的区域
                }
                processedAreas.add(regionId);

                // 计算所有重叠多边形的联合区域
                let unionGeometry = currentPoly.polygon;
                const allInvolvedPolygons = [currentPoly, ...overlappingPolygons.map(op => op.polygon)];

                for (const overlapping of overlappingPolygons) {
                    try {
                        const union = turf.union(unionGeometry, overlapping.polygon.polygon);
                        if (union && union.geometry) {
                            unionGeometry = union;
                        }
                    } catch (unionError) {
                        console.warn('⚠️ 联合操作失败:', unionError.message);
                    }
                }

                // 计算真正的重叠区域（所有多边形的交集）
                let overlapGeometry = calculateMultiPolygonIntersection(allInvolvedPolygons);

                if (overlapGeometry && overlapGeometry.geometry) {
                    const overlapArea = turf.area(overlapGeometry);

                    if (overlapArea > 1000) {
                        const conflictRegion = {
                            countries: Array.from(involvedCountries).sort(),
                            blocks: Array.from(involvedBlocks),
                            geometry: overlapGeometry,
                            area: overlapArea,
                            bounds: turf.bbox(overlapGeometry),
                            overlappingPolygons: allInvolvedPolygons.length
                        };

                        conflictRegions.push(conflictRegion);

                        const typeLabel = involvedCountries.size > 2 ? '多国重叠' : '两国冲突';
                        console.log(`   🎯 发现${typeLabel}: ${Array.from(involvedCountries).join(', ')}, 面积: ${Math.round(overlapArea)} 平方米`);
                    }
                }

            } catch (error) {
                console.warn(`⚠️ 处理重叠区域时出错:`, error.message);
            }
        }
    }

    console.log(`✅ 空间重叠分析完成: 发现 ${conflictRegions.length} 个冲突区域`);
    return conflictRegions;
}

/**
 * 计算多个多边形的交集
 * @param {Array} polygons - 多边形数组
 * @returns {Object|null} 交集几何对象
 */
function calculateMultiPolygonIntersection(polygons) {
    if (polygons.length < 2) {
        return null;
    }

    try {
        // 从第一个多边形开始
        let intersection = polygons[0].polygon || polygons[0];

        // 逐个与其他多边形求交集
        for (let i = 1; i < polygons.length; i++) {
            const nextPolygon = polygons[i].polygon || polygons[i];
            const newIntersection = turf.intersect(intersection, nextPolygon);

            if (!newIntersection || !newIntersection.geometry) {
                return null; // 如果任何两个多边形不相交，则整体交集为空
            }

            intersection = newIntersection;
        }

        return intersection;

    } catch (error) {
        console.warn('⚠️ 计算多边形交集时出错:', error.message);
        return null;
    }
}

/**
 * 合并重叠的冲突区域，检测多国重叠（已弃用，保留用于兼容性）
 * @param {Array} pairwiseConflicts - 两两国家之间的冲突数组
 * @returns {Array} 合并后的冲突数组
 */
function mergeOverlappingConflicts(pairwiseConflicts) {
    console.log(`🔄 开始合并 ${pairwiseConflicts.length} 个两国冲突区域...`);

    if (pairwiseConflicts.length === 0) {
        return [];
    }

    const mergedConflicts = [];
    const processed = new Set();

    for (let i = 0; i < pairwiseConflicts.length; i++) {
        if (processed.has(i)) {
            continue;
        }

        const currentConflict = pairwiseConflicts[i];
        const mergedCountries = new Set(currentConflict.countries);
        const mergedBlocks = new Set(currentConflict.blocks);
        let mergedGeometry = currentConflict.intersectionGeometry;
        let mergedArea = currentConflict.area;

        processed.add(i);

        // 查找与当前冲突重叠的其他冲突
        for (let j = i + 1; j < pairwiseConflicts.length; j++) {
            if (processed.has(j)) {
                continue;
            }

            const otherConflict = pairwiseConflicts[j];

            try {
                // 检查两个冲突区域是否重叠
                const intersection = turf.intersect(mergedGeometry, otherConflict.intersectionGeometry);

                if (intersection && intersection.geometry) {
                    const intersectionArea = turf.area(intersection);

                    // 如果重叠面积超过较小冲突区域的50%，则认为是同一个冲突区域
                    const minArea = Math.min(mergedArea, otherConflict.area);
                    if (intersectionArea > minArea * 0.5) {
                        console.log(`   🔗 合并冲突: ${Array.from(mergedCountries).join(',')} + ${otherConflict.countries.join(',')}`);

                        // 合并国家列表
                        otherConflict.countries.forEach(country => mergedCountries.add(country));
                        otherConflict.blocks.forEach(block => mergedBlocks.add(block));

                        // 合并几何形状
                        try {
                            const union = turf.union(mergedGeometry, otherConflict.intersectionGeometry);
                            if (union && union.geometry) {
                                mergedGeometry = union;
                                mergedArea = turf.area(union);
                            }
                        } catch (unionError) {
                            console.warn(`⚠️ 合并几何形状失败，保持原有形状:`, unionError.message);
                        }

                        processed.add(j);
                    }
                }
            } catch (error) {
                console.warn(`⚠️ 检查冲突重叠时出错:`, error.message);
            }
        }

        // 创建合并后的冲突
        const mergedConflict = {
            countries: Array.from(mergedCountries).sort(),
            blocks: Array.from(mergedBlocks),
            intersectionGeometry: mergedGeometry,
            area: mergedArea,
            bounds: turf.bbox(mergedGeometry)
        };

        mergedConflicts.push(mergedConflict);

        if (mergedCountries.size > 2) {
            console.log(`   🎯 检测到多国重叠: ${Array.from(mergedCountries).join(', ')}, 面积: ${Math.round(mergedArea)} 平方米`);
        }
    }

    console.log(`✅ 冲突合并完成: ${pairwiseConflicts.length} 个原始冲突 → ${mergedConflicts.length} 个合并冲突`);
    return mergedConflicts;
}

/**
 * 可视化冲突区域
 */
function visualizeConflictAreas() {
    console.log('🎨 开始可视化冲突区域...');

    // 清除之前的冲突区域图层
    if (window.conflictAreaLayers) {
        window.conflictAreaLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除冲突区域图层时出错:', e);
            }
        });
    }
    window.conflictAreaLayers = [];

    let visualizedCount = 0;

    for (const [conflictId, conflictInfo] of optimizationState.conflictAreas) {
        try {
            const geometry = conflictInfo.intersectionGeometry;

            if (!geometry || !geometry.geometry) {
                console.warn(`⚠️ 冲突 ${conflictId} 缺少几何数据`);
                continue;
            }

            // 转换为Leaflet坐标
            const leafletCoords = window.ConflictUtils.convertGeoJSONToLeafletCoords(geometry);

            if (!leafletCoords || leafletCoords.length === 0) {
                console.warn(`⚠️ 冲突 ${conflictId} 坐标转换失败`);
                continue;
            }

            // 创建冲突区域图层，根据冲突类型使用不同颜色
            let layer = null;
            const isMultiCountry = conflictInfo.isMultiCountry || conflictInfo.countries.length > 2;
            const color = isMultiCountry ? '#ff8800' : '#ff4444'; // 多国冲突用橙色，两国冲突用红色
            const fillOpacity = isMultiCountry ? 0.5 : 0.4;

            if (geometry.geometry.type === 'Polygon') {
                layer = L.polygon(leafletCoords, {
                    color: color,
                    fillColor: color,
                    fillOpacity: fillOpacity,
                    weight: 3,
                    opacity: 0.8,
                    dashArray: isMultiCountry ? '12, 6' : '8, 4'
                });
            } else if (geometry.geometry.type === 'MultiPolygon') {
                const layerGroup = L.layerGroup();
                leafletCoords.forEach((polygonCoords) => {
                    const polygon = L.polygon(polygonCoords, {
                        color: color,
                        fillColor: color,
                        fillOpacity: fillOpacity,
                        weight: 3,
                        opacity: 0.8,
                        dashArray: isMultiCountry ? '12, 6' : '8, 4'
                    });
                    layerGroup.addLayer(polygon);
                });
                layer = layerGroup;
            }

            if (layer) {
                // 添加弹出信息
                const isMultiCountry = conflictInfo.isMultiCountry || conflictInfo.countries.length > 2;
                const conflictType = isMultiCountry ? '多国重叠' : '边界冲突';
                const iconColor = isMultiCountry ? '#ff8800' : '#d32f2f';
                const bgColor = isMultiCountry ? '#fff3e0' : '#ffebee';

                const popupContent = `
                    <div style="font-size: 12px;">
                        <h4 style="margin: 0 0 8px 0; color: ${iconColor};">${isMultiCountry ? '🔥' : '⚔️'} ${conflictType}</h4>
                        <div><strong>冲突ID:</strong> ${conflictId}</div>
                        <div><strong>涉及国家:</strong> ${conflictInfo.countries.join(', ')}</div>
                        <div><strong>冲突面积:</strong> ${Math.round(conflictInfo.area).toLocaleString()} 平方米</div>
                        <div><strong>检测时间:</strong> ${new Date(conflictInfo.detectedAt).toLocaleString()}</div>
                        ${isMultiCountry ? '<div><strong>类型:</strong> 多国重叠区域</div>' : ''}
                        <div style="margin-top: 8px; padding: 4px; background-color: ${bgColor}; border-radius: 3px;">
                            <em style="color: ${iconColor}; font-size: 11px;">使用改进算法检测</em>
                        </div>
                    </div>
                `;

                if (layer.bindPopup) {
                    layer.bindPopup(popupContent);
                } else if (layer.eachLayer) {
                    layer.eachLayer(subLayer => {
                        if (subLayer.bindPopup) {
                            subLayer.bindPopup(popupContent);
                        }
                    });
                }

                layer.addTo(map);
                window.conflictAreaLayers.push(layer);
                visualizedCount++;
            }

        } catch (error) {
            console.error(`❌ 可视化冲突 ${conflictId} 失败:`, error);
        }
    }

    console.log(`✅ 冲突区域可视化完成: ${visualizedCount}/${optimizationState.conflictAreas.size} 个区域已显示`);

    if (visualizedCount > 0) {
        updateStatus('success', `已可视化 ${visualizedCount} 个冲突区域`);
    }
}

// 使用 ConflictUtils.convertGeoJSONToLeafletCoords 替代

/**
 * 步骤3: 删除冲突区域（修复版本：每个国家只删除涉及该国的冲突区域）
 * 对每个国家的宣称块执行几何差集操作，只去除涉及该国家的冲突区域
 * 不涉及该国家的冲突区域保持不变，避免过度删除
 * 冲突区域将在后续步骤中进行栅格化和重新分配
 */
function step3_removeConflictAreas() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.conflicts.length === 0) {
        updateStatus('error', '请先执行步骤2: 检测冲突区域');
        return;
    }

    console.log('3️⃣ 开始删除冲突区域（修复版本：每个国家只删除涉及该国的冲突区域）...');
    updateStatus('info', '步骤3: 正在从宣称块中删除相关冲突区域...');

    try {
        optimizationState.cleanedClaimBlocks = new Map();
        let totalRemovedArea = 0;
        let totalProcessedBlocks = 0;
        let totalResultBlocks = 0;

        // 为每个国家处理宣称块
        for (const [countryName, claimBlocks] of optimizationState.claimBlocks) {
            console.log(`🏛️ 处理国家 "${countryName}" 的宣称块...`);

            const cleanedBlocks = [];

            for (const block of claimBlocks) {
                totalProcessedBlocks++;
                console.log(`   处理宣称块: ${block.id}`);

                // 创建原始宣称块的多边形
                const originalPolygon = window.ConflictUtils.createValidTurfPolygon(block.boundary);
                if (!originalPolygon) {
                    console.warn(`⚠️ 跳过无效的宣称块: ${block.id}`);
                    continue;
                }

                let resultPolygon = originalPolygon;
                let removedArea = 0;

                // 筛选出涉及当前国家的冲突区域
                const relevantConflicts = optimizationState.conflicts.filter(conflict =>
                    conflict.countries.includes(countryName)
                );

                console.log(`     对涉及该国家的 ${relevantConflicts.length} 个冲突区域执行差集操作`);

                // 只对涉及当前国家的冲突区域执行差集操作
                for (const conflict of relevantConflicts) {
                    // 验证 resultPolygon 有效
                    if (!resultPolygon || !resultPolygon.geometry) {
                        console.log(`   ⚠️ 宣称块已被完全删除，停止处理`);
                        break;
                    }

                    // 1) 只取块与冲突区的交集
                    const overlap = turf.intersect(resultPolygon, conflict.intersectionGeometry);
                    if (!overlap || !overlap.geometry) {
                        console.log(`   无交集，跳过 ${conflict.id}`);
                        continue;
                    }

                    // 2) 用 overlap 做真实差集
                    const beforeArea = turf.area(resultPolygon);
                    const diff = turf.difference(resultPolygon, overlap);
                    if (!diff || !diff.geometry) {
                        console.log(`   🔥 完全被冲突覆盖: ${conflict.id}`);
                        resultPolygon = null;
                        break;
                    }

                    const afterArea = turf.area(diff);
                    const removed = beforeArea - afterArea;
                    console.log(`   ✅ 移除 ${Math.round(removed)} 平方米 (剩 ${Math.round(afterArea)})`);
                    resultPolygon = diff;
                }

                // 如果还有剩余区域，保存清理后的宣称块
                if (resultPolygon && resultPolygon.geometry) {
                    const finalArea = turf.area(resultPolygon);

                    if (finalArea > 1000) { // 只保留面积大于1000平方米的区域
                        // 转换回MC坐标格式
                        const cleanedBoundary = convertTurfPolygonToMCCoords(resultPolygon);

                        if (cleanedBoundary && cleanedBoundary.length >= 3) {
                            const cleanedBlock = {
                                ...block,
                                id: `${block.id}_cleaned`,
                                boundary: cleanedBoundary,
                                area: finalArea,
                                metadata: {
                                    ...block.metadata,
                                    blockType: 'conflict-cleaned',
                                    originalArea: block.area,
                                    removedArea: removedArea,
                                    cleanedAt: new Date().toISOString()
                                }
                            };

                            cleanedBlocks.push(cleanedBlock);
                            totalResultBlocks++;
                            totalRemovedArea += removedArea;

                            console.log(`     ✅ 清理完成: 剩余面积 ${Math.round(finalArea)} 平方米，移除 ${Math.round(removedArea)} 平方米`);
                        } else {
                            console.log(`     ⚠️ 清理后坐标转换失败，跳过`);
                        }
                    } else {
                        console.log(`     ⚠️ 清理后面积过小 (${Math.round(finalArea)} 平方米)，跳过`);
                        totalRemovedArea += removedArea;
                    }
                } else {
                    console.log(`     ⚠️ 清理后无剩余区域，整个宣称块被冲突区域覆盖`);
                    totalRemovedArea += removedArea;
                }
            }

            if (cleanedBlocks.length > 0) {
                optimizationState.cleanedClaimBlocks.set(countryName, cleanedBlocks);
                console.log(`   国家 "${countryName}" 清理完成: ${cleanedBlocks.length} 个清理后的宣称块`);
            } else {
                console.log(`   国家 "${countryName}" 清理后无有效宣称块`);
            }
        }

        console.log(`✅ 冲突区域删除完成！（修复版本：只删除涉及各国的相关冲突区域）`);
        console.log(`   处理了 ${totalProcessedBlocks} 个原始宣称块`);
        console.log(`   生成了 ${totalResultBlocks} 个清理后的宣称块`);
        console.log(`   总计移除面积: ${Math.round(totalRemovedArea).toLocaleString()} 平方米`);
        console.log(`   每个国家只删除了涉及该国的冲突区域，避免过度删除`);
        console.log(`   冲突区域将在后续步骤中进行栅格化和重新分配`);

        updateStatus('success', `步骤3完成: 处理 ${totalProcessedBlocks} 个宣称块，生成 ${totalResultBlocks} 个清理后的块`);

        // 可视化清理后的结果
        visualizeCleanedClaimBlocks();

    } catch (error) {
        console.error('❌ 删除冲突区域失败:', error);
        updateStatus('error', `步骤3失败: ${error.message}`);
    }
}

/**
 * 确定冲突区域的归属国家（优先级策略）
 * @param {Array} conflicts - 冲突区域数组
 * @returns {Map} 冲突ID到归属国家的映射
 */
function determineConflictOwnership(conflicts) {
    console.log('🎯 开始确定冲突区域归属...');

    const ownership = new Map();

    for (const conflict of conflicts) {
        let ownerCountry = null;

        if (conflict.countries.length === 2) {
            // 两国冲突：使用字母序，优先级高的国家（字母序靠前）获得冲突区域
            ownerCountry = conflict.countries.sort()[0];
            console.log(`   两国冲突 ${conflict.id}: ${conflict.countries.join(' vs ')} → 归属 ${ownerCountry}`);
        } else if (conflict.countries.length > 2) {
            // 多国冲突：使用更复杂的策略

            // 策略1：优先考虑宣称面积最大的国家
            let maxArea = 0;
            let maxAreaCountry = null;

            for (const country of conflict.countries) {
                const claimBlocks = optimizationState.claimBlocks.get(country);
                if (claimBlocks) {
                    const totalArea = claimBlocks.reduce((sum, block) => sum + (block.area || 0), 0);
                    if (totalArea > maxArea) {
                        maxArea = totalArea;
                        maxAreaCountry = country;
                    }
                }
            }

            // 策略2：如果面积相近，使用字母序
            if (maxAreaCountry) {
                ownerCountry = maxAreaCountry;
            } else {
                ownerCountry = conflict.countries.sort()[0];
            }

            console.log(`   多国冲突 ${conflict.id}: ${conflict.countries.join(', ')} → 归属 ${ownerCountry} (面积策略)`);
        }

        if (ownerCountry) {
            ownership.set(conflict.id, ownerCountry);
        }
    }

    console.log(`✅ 冲突归属确定完成: ${ownership.size} 个冲突区域已分配归属`);
    return ownership;
}

/**
 * 调试单个差集操作
 * @param {Object} claimPolygon - 宣称块多边形
 * @param {Object} conflictGeometry - 冲突区域几何
 * @param {string} claimId - 宣称块ID
 * @param {string} conflictId - 冲突ID
 * @returns {Object|null} 差集结果或null
 */
function debugDifferenceOperation(claimPolygon, conflictGeometry, claimId, conflictId) {
    console.log(`🔧 调试差集操作: ${claimId} - ${conflictId}`);

    try {
        // 1. 验证输入几何
        console.log(`   1. 验证输入几何...`);
        const claimValid = validateTurfGeometry(claimPolygon, `宣称块 ${claimId}`);
        const conflictValid = validateTurfGeometry(conflictGeometry, `冲突 ${conflictId}`);

        if (!claimValid || !conflictValid) {
            console.log(`   ❌ 输入几何无效`);
            return null;
        }

        // 2. 检查交集
        console.log(`   2. 检查交集...`);
        const intersection = turf.intersect(claimPolygon, conflictGeometry);
        if (!intersection || !intersection.geometry) {
            console.log(`   ℹ️ 无交集，无需差集操作`);
            return claimPolygon;
        }

        const intersectionArea = turf.area(intersection);
        console.log(`   📐 交集面积: ${Math.round(intersectionArea)} 平方米`);

        // 3. 执行差集操作
        console.log(`   3. 执行差集操作...`);
        let difference = null;

        try {
            difference = turf.difference(claimPolygon, conflictGeometry);
        } catch (diffError) {
            console.log(`   ⚠️ 标准差集失败: ${diffError.message}`);

            // 尝试缓冲区修复
            try {
                console.log(`   🔧 尝试缓冲区修复...`);
                const bufferedClaim = turf.buffer(claimPolygon, 0);
                const bufferedConflict = turf.buffer(conflictGeometry, 0);
                difference = turf.difference(bufferedClaim, bufferedConflict);
            } catch (bufferError) {
                console.log(`   ❌ 缓冲区修复失败: ${bufferError.message}`);
                return null;
            }
        }

        // 4. 验证结果
        if (difference && difference.geometry) {
            const beforeArea = turf.area(claimPolygon);
            const afterArea = turf.area(difference);
            const removedArea = beforeArea - afterArea;

            console.log(`   ✅ 差集成功: 移除 ${Math.round(removedArea)} 平方米，剩余 ${Math.round(afterArea)} 平方米`);

            // 验证是否真的移除了交集
            const remainingIntersection = turf.intersect(difference, conflictGeometry);
            if (remainingIntersection && remainingIntersection.geometry) {
                const remainingArea = turf.area(remainingIntersection);
                if (remainingArea > 100) {
                    console.log(`   ⚠️ 警告: 仍有 ${Math.round(remainingArea)} 平方米交集残留`);
                }
            } else {
                console.log(`   ✅ 确认: 交集已完全移除`);
            }

            return difference;
        } else {
            console.log(`   🔥 差集结果为空，整个宣称块被移除`);
            return null;
        }

    } catch (error) {
        console.error(`   ❌ 调试差集操作失败: ${error.message}`);
        return null;
    }
}





// 使用 ConflictUtils.convertTurfPolygonToMCCoords 替代

/**
 * 可视化清理后的宣称块
 */
function visualizeCleanedClaimBlocks() {
    console.log('🎨 开始可视化清理后的宣称块...');

    // 清除当前显示
    if (countryClaimsManager) {
        countryClaimsManager.clearDisplayedLayers();
    }

    // 临时将清理后的数据应用到宣称管理器进行显示
    setTimeout(() => {
        if (countryClaimsManager && optimizationState.cleanedClaimBlocks.size > 0) {
            // 创建临时的宣称数据格式
            const tempClaims = new Map();

            for (const [countryName, cleanedBlocks] of optimizationState.cleanedClaimBlocks) {
                const claims = cleanedBlocks.map((block, index) => ({
                    id: block.id,
                    boundary: [block.boundary.map(coord => mcToMapCoords(coord[0], coord[1]))],
                    area: block.area,
                    metadata: block.metadata,
                    spawnPoints: block.spawnPoints || []
                }));

                tempClaims.set(countryName, {
                    success: true,
                    claims: claims,
                    metadata: {
                        type: 'conflict-cleaned',
                        generatedAt: new Date().toISOString()
                    }
                });
            }

            // 临时替换生成的宣称数据
            const originalClaims = countryClaimsManager.generatedClaims;
            countryClaimsManager.generatedClaims = tempClaims;

            // 显示清理后的结果
            countryClaimsManager.showCurrentGeneratedClaims();

            // 恢复原始数据（可选）
            // countryClaimsManager.generatedClaims = originalClaims;
        }
    }, 500);
}

/**
 * 步骤4: 栅格化冲突区域（使用自定义循环逻辑）
 * 按 gridSize 等分冲突区域，生成标准格子，每个格子记录中心点坐标
 */
function step4_rasterizeConflictAreas() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.conflictAreas.size === 0) {
        updateStatus('error', '请先执行步骤2: 检测冲突区域');
        return;
    }

    console.log('4️⃣ 开始栅格化冲突区域（使用自定义循环逻辑）...');
    updateStatus('info', '步骤4: 正在使用自定义逻辑对冲突区域进行标准栅格划分...');

    try {
        // 获取步骤4冲突栅格配置（从配置界面读取）
        const gridSize = typeof getConflictGridSize === 'function' ? getConflictGridSize() : 4; // 从配置获取，默认4区块
        const cellSizeBlocks = gridSize * 16; // 转换为方块单位

        optimizationState.gridCells.clear();
        let totalCells = 0;

        console.log(`📐 步骤4冲突栅格配置: ${gridSize}区块 = ${cellSizeBlocks}方块 (来自配置界面)`);

        // 为每个冲突区域生成标准栅格
        for (const [conflictId, conflictInfo] of optimizationState.conflictAreas) {
            console.log(`📐 栅格化冲突区域: ${conflictId}`);

            if (!conflictInfo.intersectionGeometry || !conflictInfo.intersectionGeometry.geometry) {
                console.warn(`⚠️ 冲突区域 ${conflictId} 缺少几何数据`);
                continue;
            }

            // 获取冲突区域的边界框
            const bounds = conflictInfo.bounds; // [minX, minY, maxX, maxY]
            const [originalMinX, originalMinY, originalMaxX, originalMaxY] = bounds;

            // 对栅格生成区域四边进行扩张，每个边扩张1个栅格大小，确保栅格区域100%覆盖冲突区域
            const gridMinX = originalMinX - cellSizeBlocks;
            const gridMinY = originalMinY - cellSizeBlocks;
            const gridMaxX = originalMaxX + cellSizeBlocks;
            const gridMaxY = originalMaxY + cellSizeBlocks;

            console.log(`   冲突区域边界框: X(${originalMinX} ~ ${originalMaxX}) Y(${originalMinY} ~ ${originalMaxY})`);
            console.log(`   栅格生成区域: X(${gridMinX} ~ ${gridMaxX}) Y(${gridMinY} ~ ${gridMaxY}) [每边扩张${cellSizeBlocks}方块]`);

            // 计算栅格数量（基于扩张后的区域）
            const gridWidth = gridMaxX - gridMinX;
            const gridHeight = gridMaxY - gridMinY;
            const cellsX = Math.ceil(gridWidth / cellSizeBlocks);
            const cellsY = Math.ceil(gridHeight / cellSizeBlocks);

            console.log(`   栅格数量: ${cellsX} x ${cellsY} = ${cellsX * cellsY} 个格子`);

            let conflictCells = 0;

            // 生成栅格（使用扩张后的栅格区域）
            for (let i = 0; i < cellsX; i++) {
                for (let j = 0; j < cellsY; j++) {
                    const cellMinX = gridMinX + i * cellSizeBlocks;
                    const cellMinY = gridMinY + j * cellSizeBlocks;
                    const cellMaxX = Math.min(cellMinX + cellSizeBlocks, gridMaxX);
                    const cellMaxY = Math.min(cellMinY + cellSizeBlocks, gridMaxY);

                    // 计算格子中心点
                    const centerX = (cellMinX + cellMaxX) / 2;
                    const centerY = (cellMinY + cellMaxY) / 2;

                    // 调试：输出前几个格子的信息
                    if (conflictCells < 3) {
                        console.log(`     格子[${i},${j}]: 中心(${Math.round(centerX)}, ${Math.round(centerY)}) 边界(${Math.round(cellMinX)},${Math.round(cellMinY)},${Math.round(cellMaxX)},${Math.round(cellMaxY)})`);
                    }

                    // 检查栅格单元是否与冲突区域有重叠或接触
                    let isValidCell = false;

                    try {
                        // 方法1: 检查中心点是否在冲突区域内
                        const centerPoint = turf.point([centerX, centerY]);
                        const centerInConflict = turf.booleanPointInPolygon(centerPoint, conflictInfo.intersectionGeometry);

                        if (centerInConflict) {
                            isValidCell = true;
                            if (conflictCells < 3) {
                                console.log(`     栅格中心在冲突区域内: true`);
                            }
                        } else {
                            // 方法2: 检查栅格单元是否与冲突区域相交
                            const cellPolygon = turf.polygon([[
                                [cellMinX, cellMinY],
                                [cellMaxX, cellMinY],
                                [cellMaxX, cellMaxY],
                                [cellMinX, cellMaxY],
                                [cellMinX, cellMinY]
                            ]]);

                            const intersection = turf.intersect(cellPolygon, conflictInfo.intersectionGeometry);
                            isValidCell = intersection !== null;

                            if (conflictCells < 3) {
                                console.log(`     栅格与冲突区域相交: ${isValidCell}`);
                            }
                        }
                    } catch (checkError) {
                        console.warn(`⚠️ 栅格有效性检测失败: ${checkError.message}`);
                        continue;
                    }

                    if (isValidCell) {
                        const cellId = `${conflictId}_cell_${i}_${j}`;

                        const cellInfo = {
                            id: cellId,
                            conflictId: conflictId,
                            centerX: centerX,
                            centerY: centerY,
                            bounds: [cellMinX, cellMinY, cellMaxX, cellMaxY],
                            gridPosition: [i, j],
                            area: (cellMaxX - cellMinX) * (cellMaxY - cellMinY),
                            countries: conflictInfo.countries,
                            createdAt: new Date().toISOString()
                        };

                        optimizationState.gridCells.set(cellId, cellInfo);
                        conflictCells++;
                        totalCells++;

                        if (conflictCells <= 3) {
                            console.log(`     ✅ 生成栅格单元: ${cellId}`);
                        }
                    }
                }
            }

            console.log(`   生成了 ${conflictCells} 个有效栅格单元`);
        }

        console.log(`✅ 栅格化完成！总计生成 ${totalCells} 个栅格单元`);
        updateStatus('success', `步骤4完成: 生成 ${totalCells} 个栅格单元`);

        // 可视化栅格（强制显示用于调试）
        if (totalCells > 0) {
            console.log(`🎨 开始可视化 ${totalCells} 个栅格单元...`);
            visualizeGridCells();
        } else {
            console.warn('⚠️ 没有生成任何栅格单元，无法可视化');
            updateStatus('warning', '没有生成栅格单元 - 可能冲突区域太小或检测失败');
        }

    } catch (error) {
        console.error('❌ 栅格化冲突区域失败:', error);
        updateStatus('error', `步骤4失败: ${error.message}`);
    }
}

/**
 * 可视化栅格单元
 */
function visualizeGridCells() {
    console.log('🎨 开始可视化栅格单元...');

    // 清除之前的栅格图层
    if (window.gridCellLayers) {
        window.gridCellLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
    }
    window.gridCellLayers = [];

    let visualizedCount = 0;

    for (const [cellId, cellInfo] of optimizationState.gridCells) {
        try {
            const [minX, minY, maxX, maxY] = cellInfo.bounds;

            // 转换为地图坐标 - mcToMapCoords返回[mapY, mapX]格式
            const topLeft = mcToMapCoords(minX, minY);      // 左上角
            const topRight = mcToMapCoords(maxX, minY);     // 右上角
            const bottomRight = mcToMapCoords(maxX, maxY);  // 右下角
            const bottomLeft = mcToMapCoords(minX, maxY);   // 左下角

            // 创建矩形多边形 - Leaflet需要[lat, lng]格式，即[mapY, mapX]
            const rectangle = L.polygon([
                [topLeft[0], topLeft[1]],       // [mapY, mapX]
                [topRight[0], topRight[1]],     // [mapY, mapX]
                [bottomRight[0], bottomRight[1]], // [mapY, mapX]
                [bottomLeft[0], bottomLeft[1]]    // [mapY, mapX]
            ], {
                color: '#00ff00',
                fillColor: '#00ff00',
                fillOpacity: 0.2,
                weight: 1,
                opacity: 0.6
            });

            // 添加弹出信息
            const popupContent = `
                <div style="font-size: 12px;">
                    <h4 style="margin: 0 0 8px 0; color: #2e7d32;">📐 栅格单元</h4>
                    <div><strong>单元ID:</strong> ${cellId}</div>
                    <div><strong>冲突区域:</strong> ${cellInfo.conflictId}</div>
                    <div><strong>中心坐标:</strong> MC(${Math.round(cellInfo.centerX)}, ${Math.round(cellInfo.centerY)})</div>
                    <div><strong>涉及国家:</strong> ${cellInfo.countries.join(', ')}</div>
                    <div><strong>面积:</strong> ${Math.round(cellInfo.area).toLocaleString()} 平方米</div>
                    <div><strong>栅格边界:</strong> X(${Math.round(minX)}~${Math.round(maxX)}) Y(${Math.round(minY)}~${Math.round(maxY)})</div>
                </div>
            `;

            rectangle.bindPopup(popupContent);
            rectangle.addTo(map);
            window.gridCellLayers.push(rectangle);
            visualizedCount++;

            // 调试信息：输出前几个栅格的坐标转换
            if (visualizedCount <= 3) {
                console.log(`   栅格 ${cellId}:`);
                console.log(`     MC边界: X(${minX}~${maxX}) Y(${minY}~${maxY})`);
                console.log(`     地图坐标: 左上${topLeft} 右下${bottomRight}`);
            }

        } catch (error) {
            console.error(`❌ 可视化栅格单元 ${cellId} 失败:`, error);
        }
    }

    console.log(`✅ 栅格单元可视化完成: ${visualizedCount}/${optimizationState.gridCells.size} 个单元已显示`);

    if (visualizedCount === 0) {
        console.warn('⚠️ 没有可视化任何栅格单元，尝试调试可视化...');
        debugVisualizeConflictBounds();
    }
}

/**
 * 调试可视化：显示冲突区域边界框
 */
function debugVisualizeConflictBounds() {
    console.log('🔧 调试可视化：显示冲突区域边界框...');

    // 清除之前的调试图层
    if (window.debugBoundsLayers) {
        window.debugBoundsLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除调试边界图层时出错:', e);
            }
        });
    }
    window.debugBoundsLayers = [];

    let debugCount = 0;

    for (const [conflictId, conflictInfo] of optimizationState.conflictAreas) {
        try {
            if (!conflictInfo.bounds) {
                console.warn(`⚠️ 冲突区域 ${conflictId} 没有边界信息`);
                continue;
            }

            const [minX, minY, maxX, maxY] = conflictInfo.bounds;
            console.log(`   冲突区域 ${conflictId} 边界: X(${minX}~${maxX}) Y(${minY}~${maxY})`);

            // 转换为地图坐标
            const topLeft = mcToMapCoords(minX, minY);
            const bottomRight = mcToMapCoords(maxX, maxY);

            console.log(`   地图坐标: 左上${topLeft} 右下${bottomRight}`);

            // 创建边界框矩形
            const bounds = [
                [topLeft[0], topLeft[1]],
                [bottomRight[0], bottomRight[1]]
            ];

            const rectangle = L.rectangle(bounds, {
                color: '#ff0000',
                fillColor: '#ff0000',
                fillOpacity: 0.1,
                weight: 2,
                opacity: 0.8,
                dashArray: '5, 5'
            });

            rectangle.bindPopup(`
                <div style="font-size: 12px;">
                    <h4 style="margin: 0 0 8px 0; color: #d32f2f;">🔧 调试边界框</h4>
                    <div><strong>冲突ID:</strong> ${conflictId}</div>
                    <div><strong>MC边界:</strong> X(${Math.round(minX)}~${Math.round(maxX)}) Y(${Math.round(minY)}~${Math.round(maxY)})</div>
                    <div><strong>涉及国家:</strong> ${conflictInfo.countries.join(', ')}</div>
                </div>
            `);

            rectangle.addTo(map);
            window.debugBoundsLayers.push(rectangle);
            debugCount++;

        } catch (error) {
            console.error(`❌ 调试可视化冲突边界 ${conflictId} 失败:`, error);
        }
    }

    console.log(`✅ 调试边界可视化完成: ${debugCount} 个边界框已显示`);
}

/**
 * 步骤5: 归属判定（优化版本）
 * 1. 优先判断点是否在领地内
 * 2. 使用 polygonToLine 简化边界提取逻辑
 * 3. 处理边界误差与相等距离冲突
 */
async function step5_assignOwnership() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.gridCells.size === 0) {
        updateStatus('error', '请先执行步骤4: 栅格化冲突区域');
        return;
    }

    console.log('5️⃣ 开始归属判定（优化版本：优先领地内判断 + 简化边界提取 + 边界误差处理）...');
    updateStatus('info', '步骤5: 正在使用优化算法确定格子归属...');

    try {
        optimizationState.cellAssignments.clear();

        // 收集所有国家的出生点数据
        const countrySpawnData = new Map();

        // 从IndexedDB获取国家出生点数据
        console.log('🔍 正在从IndexedDB获取国家出生点数据...');
        let storedCountrySpawn = await getStoredCountrySpawn();
        console.log('📊 获取到的国家出生点数据:', storedCountrySpawn);

        if (!storedCountrySpawn) {
            // 尝试检查是否有原始数据
            const markers = await getStoredMarkers();
            const areas = await getStoredAreas();
            console.log('🔍 检查原始数据 - markers:', markers ? Object.keys(markers).length : 0, 'areas:', areas ? Object.keys(areas).length : 0);

            if (markers || areas) {
                updateStatus('info', '发现原始数据但缺少国家分组数据，正在重新处理...');
                console.log('🔄 重新处理国家数据...');
                await processCountryData();

                // 重新尝试获取
                storedCountrySpawn = await getStoredCountrySpawn();
                if (!storedCountrySpawn) {
                    throw new Error('重新处理后仍未找到国家出生点数据');
                }
                console.log('✅ 重新处理后成功获取国家数据');
            } else {
                throw new Error('未找到国家出生点数据，请先加载国家数据（点击"🔄 刷新所有数据"按钮）');
            }
        }

        const countrySpawnInfo = storedCountrySpawn;
        console.log('📍 加载的国家出生点数据:', countrySpawnInfo);

        // 直接从 countrySpawnInfo 中收集每个国家的出生点数据
        console.log('🔍 开始从国家出生点数据中收集信息...');
        for (const [countryName, countryData] of Object.entries(countrySpawnInfo)) {
            // 跳过不是国家数据的条目（如单独的spawn条目）
            if (countryName.includes('_spawn') || !countryData || typeof countryData !== 'object') {
                continue;
            }

            const spawnPoints = [];
            const polygons = [];

            // 从 spawns 数组中获取出生点数据
            if (countryData.spawns && Array.isArray(countryData.spawns)) {
                console.log(`   处理国家 "${countryName}" 的 ${countryData.spawns.length} 个出生点`);
                for (const spawn of countryData.spawns) {
                    if (spawn.x !== undefined && spawn.z !== undefined) {
                        spawnPoints.push({
                            x: spawn.x,
                            z: spawn.z,
                            name: spawn.name || spawn.markerId || 'unknown',
                            y: spawn.y || 64
                        });
                    }
                }
            }

            // 尝试从宣称管理器获取该国家的多边形数据
            const claimsResult = countryClaimsManager.generatedClaims.get(countryName);
            if (claimsResult && claimsResult.success && claimsResult.claims) {
                console.log(`   为国家 "${countryName}" 添加 ${claimsResult.claims.length} 个宣称区域的多边形`);
                for (const claim of claimsResult.claims) {
                    // 收集宣称区域的多边形
                    if (claim.boundary && Array.isArray(claim.boundary)) {
                        let coords = [];
                        if (claim.boundary.length > 0 && Array.isArray(claim.boundary[0])) {
                            coords = claim.boundary[0];
                        } else {
                            coords = claim.boundary;
                        }

                        if (coords.length >= 3) {
                            const mcCoords = coords.map(mapCoord => {
                                const mc = mapToMcCoords(mapCoord[0], mapCoord[1]);
                                return [mc.x, mc.z];
                            });

                            const polygon = createValidTurfPolygon(mcCoords);
                            if (polygon) {
                                polygons.push(polygon);
                            }
                        }
                    }
                }
            }

            if (spawnPoints.length > 0 || polygons.length > 0) {
                countrySpawnData.set(countryName, {
                    spawnPoints: spawnPoints,
                    polygons: polygons
                });
                console.log(`   ✅ 国家 "${countryName}": ${spawnPoints.length} 个出生点, ${polygons.length} 个多边形`);
            } else {
                console.warn(`   ⚠️ 国家 "${countryName}" 没有有效的出生点或多边形数据`);
            }
        }

        console.log(`📊 收集了 ${countrySpawnData.size} 个国家的出生点数据`);

        let assignedCount = 0;
        let unassignedCount = 0;
        const assignmentStats = new Map();

        // 为每个栅格单元分配归属（基于出生点距离）
        for (const [cellId, cellInfo] of optimizationState.gridCells) {
            const centerPoint = turf.point([cellInfo.centerX, cellInfo.centerY]);
            let assignedCountry = null;
            let assignmentMethod = '';
            let assignmentDistance = Infinity;
            let closestSpawnPoint = null;

            // 只考虑冲突涉及的国家
            const conflictCountries = cellInfo.countries || [];

            console.log(`🎯 为栅格 ${cellId} 分配归属，涉及国家: ${conflictCountries.join(', ')}`);

            // 检查是否有涉及的国家
            if (conflictCountries.length === 0) {
                console.warn(`⚠️ 栅格 ${cellId} 没有涉及的国家信息`);
                unassignedCount++;
                continue;
            }

            // 步骤1: 检查是否在任何涉及国家的领地内
            for (const countryName of conflictCountries) {
                const countryData = countrySpawnData.get(countryName);
                if (!countryData) {
                    console.warn(`⚠️ 国家 "${countryName}" 在出生点数据中未找到`);
                    continue;
                }

                for (const polygon of countryData.polygons) {
                    try {
                        const isInside = turf.booleanPointInPolygon(centerPoint, polygon);
                        if (isInside) {
                            assignedCountry = countryName;
                            assignmentMethod = 'inside-territory';
                            assignmentDistance = 0;
                            console.log(`   ✅ 栅格在 ${countryName} 领地内`);
                            break;
                        }
                    } catch (error) {
                        console.warn(`⚠️ 检查点是否在多边形内时出错:`, error.message);
                    }
                }
                if (assignedCountry) break;
            }

            // 步骤2: 如果不在任何领地内，找距离最近的出生点
            if (!assignedCountry) {
                let minDistance = Infinity;
                const distanceResults = {};

                for (const countryName of conflictCountries) {
                    const countryData = countrySpawnData.get(countryName);
                    if (!countryData) {
                        console.warn(`⚠️ 国家 "${countryName}" 在出生点数据中未找到（距离计算阶段）`);
                        continue;
                    }
                    if (!countryData.spawnPoints || countryData.spawnPoints.length === 0) {
                        console.warn(`⚠️ 国家 "${countryName}" 没有出生点数据`);
                        continue;
                    }

                    let countryMinDistance = Infinity;
                    let countryClosestSpawn = null;

                    for (const spawnPoint of countryData.spawnPoints) {
                        try {
                            // 使用 Minecraft 坐标系统计算欧几里得距离（以方块为单位）
                            const dx = cellInfo.centerX - spawnPoint.x;
                            const dz = cellInfo.centerY - spawnPoint.z;
                            const distance = Math.sqrt(dx * dx + dz * dz);

                            if (distance < countryMinDistance) {
                                countryMinDistance = distance;
                                countryClosestSpawn = spawnPoint;
                            }
                        } catch (error) {
                            console.warn(`⚠️ 计算到出生点距离时出错:`, error.message);
                        }
                    }

                    distanceResults[countryName] = countryMinDistance;
                    if (countryMinDistance < minDistance) {
                        minDistance = countryMinDistance;
                        assignedCountry = countryName;
                        assignmentMethod = 'nearest-spawn';
                        assignmentDistance = minDistance;
                        closestSpawnPoint = countryClosestSpawn;
                    }
                }

                console.log(`   📏 距离结果:`, distanceResults);
                console.log(`   🎯 最近出生点: ${assignedCountry} (${Math.round(minDistance)}方块)`);

                // 处理相等距离的情况（使用方块为单位的误差范围）
                const equalDistanceCountries = Object.entries(distanceResults)
                    .filter(([_, distance]) => Math.abs(distance - minDistance) < 5) // 5方块误差范围
                    .map(([country, _]) => country);

                if (equalDistanceCountries.length > 1) {
                    // 如果有多个国家距离相等，选择字母序最小的
                    assignedCountry = equalDistanceCountries.sort()[0];
                    assignmentMethod = 'spawn-distance-tie';
                    console.log(`   ⚖️ 距离相等，选择: ${assignedCountry}`);
                }
            }

            // 记录分配结果
            if (assignedCountry) {
                const assignment = {
                    cellId: cellId,
                    assignedCountry: assignedCountry,
                    method: assignmentMethod,
                    distance: assignmentDistance,
                    centerX: cellInfo.centerX,
                    centerY: cellInfo.centerY,
                    area: cellInfo.area,
                    assignedAt: new Date().toISOString()
                };

                optimizationState.cellAssignments.set(cellId, assignment);
                assignedCount++;

                // 统计各国分配情况
                if (!assignmentStats.has(assignedCountry)) {
                    assignmentStats.set(assignedCountry, { count: 0, area: 0, methods: {} });
                }
                const stats = assignmentStats.get(assignedCountry);
                stats.count++;
                stats.area += cellInfo.area;
                stats.methods[assignmentMethod] = (stats.methods[assignmentMethod] || 0) + 1;
            } else {
                unassignedCount++;
                console.warn(`⚠️ 无法为栅格单元 ${cellId} 分配归属`);
                console.warn(`   涉及国家: ${conflictCountries.join(', ')}`);
                console.warn(`   可用国家数据: ${Array.from(countrySpawnData.keys()).join(', ')}`);

                // 检查每个涉及国家的数据情况
                for (const countryName of conflictCountries) {
                    const countryData = countrySpawnData.get(countryName);
                    if (countryData) {
                        console.warn(`   国家 "${countryName}": ${countryData.spawnPoints?.length || 0} 个出生点, ${countryData.polygons?.length || 0} 个多边形`);
                    } else {
                        console.warn(`   国家 "${countryName}": 数据缺失`);
                    }
                }
            }
        }

        console.log(`✅ 归属判定完成！`);
        console.log(`   已分配: ${assignedCount} 个栅格单元`);
        console.log(`   未分配: ${unassignedCount} 个栅格单元`);

        // 显示各国分配统计
        console.log(`📊 各国分配统计:`);
        for (const [country, stats] of assignmentStats) {
            console.log(`   ${country}: ${stats.count} 个单元, ${Math.round(stats.area).toLocaleString()} 平方米`);
            console.log(`     分配方式: ${JSON.stringify(stats.methods)}`);
        }

        updateStatus('success', `步骤5完成: 分配 ${assignedCount} 个栅格单元给 ${assignmentStats.size} 个国家`);

        // 可视化分配结果（强制显示）
        if (assignedCount > 0) {
            console.log(`🎨 开始可视化 ${assignedCount} 个分配结果...`);
            visualizeAssignments();
        } else {
            console.warn('⚠️ 没有分配任何栅格单元，无法可视化');
            updateStatus('warning', '没有分配栅格单元 - 可能归属判定失败');
        }

    } catch (error) {
        console.error('❌ 归属判定失败:', error);
        updateStatus('error', `步骤5失败: ${error.message}`);
    }
}

/**
 * 可视化分配结果
 */
async function visualizeAssignments() {
    console.log('🎨 开始可视化分配结果...');

    // 初始化国家颜色
    await window.CountryColorManager.initializeCountryColors();

    // 清除之前的所有栅格相关图层
    if (window.gridCellLayers) {
        window.gridCellLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
        window.gridCellLayers = [];
    }

    if (window.assignmentLayers) {
        window.assignmentLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除分配图层时出错:', e);
            }
        });
    }
    window.assignmentLayers = [];

    // 清除连线图层
    if (window.connectionLayers) {
        window.connectionLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除连线图层时出错:', e);
            }
        });
    }
    window.connectionLayers = [];

    let visualizedCount = 0;

    console.log(`📊 准备可视化 ${optimizationState.cellAssignments.size} 个分配结果...`);

    for (const [cellId, assignment] of optimizationState.cellAssignments) {
        try {
            const cellInfo = optimizationState.gridCells.get(cellId);
            if (!cellInfo) continue;

            // 使用 CountryColorManager 获取国家颜色
            const color = window.CountryColorManager.getCountryColor(assignment.assignedCountry);

            // 调试：输出前几个分配的详细信息
            if (visualizedCount < 3) {
                console.log(`   分配 ${cellId}: ${assignment.assignedCountry} (${color}) 方式: ${assignment.method}`);
            }

            const [minX, minY, maxX, maxY] = cellInfo.bounds;

            // 转换为地图坐标
            const topLeft = mcToMapCoords(minX, minY);
            const topRight = mcToMapCoords(maxX, minY);
            const bottomRight = mcToMapCoords(maxX, maxY);
            const bottomLeft = mcToMapCoords(minX, maxY);

            const rectangle = L.polygon([
                [topLeft[0], topLeft[1]],       // [mapY, mapX]
                [topRight[0], topRight[1]],     // [mapY, mapX]
                [bottomRight[0], bottomRight[1]], // [mapY, mapX]
                [bottomLeft[0], bottomLeft[1]]    // [mapY, mapX]
            ], {
                color: color,
                fillColor: color,
                fillOpacity: 0.6,  // 增加透明度以便更好地看到颜色
                weight: 2,
                opacity: 0.9
            });

            // 添加弹出信息
            const popupContent = `
                <div style="font-size: 12px;">
                    <h4 style="margin: 0 0 8px 0; color: ${color};">🎯 归属分配</h4>
                    <div><strong>单元ID:</strong> ${cellId}</div>
                    <div><strong>归属国家:</strong> ${assignment.assignedCountry}</div>
                    <div><strong>分配方式:</strong> ${assignment.method}</div>
                    <div><strong>距离:</strong> ${Math.round(assignment.distance)} 方块</div>
                    <div><strong>中心坐标:</strong> (${Math.round(assignment.centerX)}, ${Math.round(assignment.centerY)})</div>
                    <div style="margin-top: 8px; padding: 4px; background-color: #f0f0f0; border-radius: 3px; font-size: 11px;">
                        💡 <strong>提示:</strong> 点击栅格显示到出生点的连线<br>
                        🖱️ 双击地图清除连线
                    </div>
                </div>
            `;

            rectangle.bindPopup(popupContent);

            // 添加点击事件来显示到出生点的连线
            rectangle.on('click', function(e) {
                showConnectionToSpawn(cellId, assignment, cellInfo, color).catch(console.error);
            });

            rectangle.addTo(map);
            window.assignmentLayers.push(rectangle);
            visualizedCount++;

        } catch (error) {
            console.error(`❌ 可视化分配结果 ${cellId} 失败:`, error);
        }
    }

    console.log(`✅ 分配结果可视化完成: ${visualizedCount}/${optimizationState.cellAssignments.size} 个分配已显示`);

    // 添加双击地图清除连线的功能
    map.on('dblclick', function(e) {
        clearConnectionLines();
    });
}

/**
 * 显示栅格到出生点的连线
 * @param {string} cellId - 栅格单元ID
 * @param {Object} assignment - 分配信息
 * @param {Object} cellInfo - 栅格信息
 * @param {string} color - 国家颜色
 */
async function showConnectionToSpawn(cellId, assignment, cellInfo, color) {
    console.log(`🔗 显示栅格 ${cellId} 到出生点的连线`);

    // 清除之前的连线
    if (window.connectionLayers) {
        window.connectionLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除连线时出错:', e);
            }
        });
        window.connectionLayers = [];
    }

    try {
        // 从IndexedDB获取国家出生点数据
        const storedCountrySpawn = await getStoredCountrySpawn();
        if (!storedCountrySpawn) {
            console.warn(`⚠️ 未找到国家出生点数据`);
            return;
        }

        const countryData = storedCountrySpawn[assignment.assignedCountry];

        if (!countryData || !countryData.spawns || countryData.spawns.length === 0) {
            console.warn(`⚠️ 未找到国家 "${assignment.assignedCountry}" 的出生点数据`);
            return;
        }

        // 找到最近的出生点
        let closestSpawn = null;
        let minDistance = Infinity;

        for (const spawn of countryData.spawns) {
            const dx = cellInfo.centerX - spawn.x;
            const dz = cellInfo.centerY - spawn.z;
            const distance = Math.sqrt(dx * dx + dz * dz);

            if (distance < minDistance) {
                minDistance = distance;
                closestSpawn = spawn;
            }
        }

        if (!closestSpawn) {
            console.warn(`⚠️ 未找到最近的出生点`);
            return;
        }

        // 转换坐标到地图坐标系
        const cellMapCoords = mcToMapCoords(cellInfo.centerX, cellInfo.centerY);
        const spawnMapCoords = mcToMapCoords(closestSpawn.x, closestSpawn.z);

        // 创建连线
        const connectionLine = L.polyline([
            [cellMapCoords[0], cellMapCoords[1]],  // 栅格中心
            [spawnMapCoords[0], spawnMapCoords[1]]  // 出生点
        ], {
            color: color,
            weight: 3,
            opacity: 0.8,
            dashArray: '10, 5'  // 虚线样式
        });

        // 创建箭头标记（在出生点位置）
        const arrowIcon = L.divIcon({
            html: `<div style="
                width: 0;
                height: 0;
                border-left: 8px solid transparent;
                border-right: 8px solid transparent;
                border-bottom: 12px solid ${color};
                transform: rotate(${getArrowRotation(cellMapCoords, spawnMapCoords)}deg);
            "></div>`,
            className: 'arrow-marker',
            iconSize: [16, 12],
            iconAnchor: [8, 6]
        });

        const arrowMarker = L.marker([spawnMapCoords[0], spawnMapCoords[1]], {
            icon: arrowIcon
        });

        // 创建出生点标记
        const spawnMarker = L.circleMarker([spawnMapCoords[0], spawnMapCoords[1]], {
            color: color,
            fillColor: color,
            fillOpacity: 0.8,
            radius: 6,
            weight: 2
        });

        // 添加出生点信息弹窗
        const spawnPopupContent = `
            <div style="font-size: 12px;">
                <h4 style="margin: 0 0 8px 0; color: ${color};">🏠 出生点</h4>
                <div><strong>国家:</strong> ${assignment.assignedCountry}</div>
                <div><strong>名称:</strong> ${closestSpawn.name || '未知'}</div>
                <div><strong>坐标:</strong> (${Math.round(closestSpawn.x)}, ${Math.round(closestSpawn.z)})</div>
                <div><strong>距离:</strong> ${Math.round(minDistance)} 方块</div>
            </div>
        `;

        spawnMarker.bindPopup(spawnPopupContent);

        // 添加到地图
        connectionLine.addTo(map);
        arrowMarker.addTo(map);
        spawnMarker.addTo(map);

        // 保存图层引用
        if (!window.connectionLayers) {
            window.connectionLayers = [];
        }
        window.connectionLayers.push(connectionLine, arrowMarker, spawnMarker);

        console.log(`✅ 已显示到出生点 "${closestSpawn.name}" 的连线，距离: ${Math.round(minDistance)} 方块`);

    } catch (error) {
        console.error('❌ 显示连线失败:', error);
    }
}

/**
 * 清除所有连线
 */
function clearConnectionLines() {
    console.log('🧹 清除所有连线');

    if (window.connectionLayers) {
        window.connectionLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除连线时出错:', e);
            }
        });
        window.connectionLayers = [];
    }
}

/**
 * 计算箭头旋转角度
 * @param {Array} from - 起点坐标 [lat, lng]
 * @param {Array} to - 终点坐标 [lat, lng]
 * @returns {number} 旋转角度（度）
 */
function getArrowRotation(from, to) {
    const dx = to[1] - from[1];  // lng差值
    const dy = to[0] - from[0];  // lat差值
    const angle = Math.atan2(dx, dy) * 180 / Math.PI;
    return angle;
}

/**
 * 步骤6: 融合栅格块生成新的宣称区域（使用Union操作自动识别连通性）
 * 将同一国家的栅格块通过Union操作合并，自动识别连通性：
 * - 如果栅格块相连，合并为单个Polygon，生成1个新宣称区域
 * - 如果栅格块不相连，生成MultiPolygon，每个部分成为独立的新宣称区域
 * 注意：此步骤只处理栅格块，不操作第3步清理后的无冲突区域
 */
function step6_mergeOwnershipAreas() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.cellAssignments.size === 0) {
        updateStatus('error', '请先执行步骤5: 归属判定');
        return;
    }

    console.log('6️⃣ 开始融合栅格块生成新的宣称区域...');
    updateStatus('info', '步骤6: 正在融合栅格块生成新的宣称区域...');

    try {
        optimizationState.mergedClaimBlocks.clear();

        // 按国家分组归属结果
        const assignmentsByCountry = new Map();

        for (const [cellId, assignment] of optimizationState.cellAssignments) {
            const country = assignment.assignedCountry;
            if (!assignmentsByCountry.has(country)) {
                assignmentsByCountry.set(country, []);
            }
            assignmentsByCountry.get(country).push(assignment);
        }

        let totalMergedBlocks = 0;
        let totalFusedCountries = 0;
        let totalProcessedCells = 0;
        let totalFusedCells = 0;

        // 为每个国家处理归属的栅格单元
        for (const [countryName, assignments] of assignmentsByCountry) {
            totalProcessedCells += assignments.length;

            // 1. 将栅格单元转换为多边形集合
            const cellPolygons = [];
            for (const assignment of assignments) {
                // 确保assignment有cellId属性
                const cellId = assignment.cellId || assignment.id;
                const cellInfo = optimizationState.gridCells.get(cellId);
                if (cellInfo) {
                    const [minX, minY, maxX, maxY] = cellInfo.bounds;

                    // 创建栅格单元的矩形多边形
                    const cellBoundary = [
                        [minX, minY],
                        [maxX, minY],
                        [maxX, maxY],
                        [minX, maxY],
                        [minX, minY]  // 闭合
                    ];

                    const cellPolygon = createValidTurfPolygon(cellBoundary);
                    if (cellPolygon) {
                        cellPolygons.push(cellPolygon);
                    }
                }
            }

            // 2. 使用union逐步合并所有栅格多边形，自动处理连通性
            const mergedCellGroups = [];
            if (cellPolygons.length > 0) {
                try {
                    // 从第一个多边形开始，逐个union
                    let currentUnion = cellPolygons[0];

                    for (let i = 1; i < cellPolygons.length; i++) {
                        const union = turf.union(currentUnion, cellPolygons[i]);
                        if (union && union.geometry) {
                            currentUnion = union;
                        }
                    }

                    // 检查结果是单个多边形还是多个多边形
                    if (currentUnion.geometry.type === 'Polygon') {
                        // 单个连通区域
                        mergedCellGroups.push({
                            geometry: currentUnion,
                            groupIndex: 0,
                            cellCount: cellPolygons.length
                        });
                    } else if (currentUnion.geometry.type === 'MultiPolygon') {
                        // 多个不连通区域，分别处理每个多边形
                        const coordinates = currentUnion.geometry.coordinates;
                        for (let i = 0; i < coordinates.length; i++) {
                            const singlePolygon = turf.polygon(coordinates[i]);
                            mergedCellGroups.push({
                                geometry: singlePolygon,
                                groupIndex: i,
                                cellCount: Math.ceil(cellPolygons.length / coordinates.length) // 估算每个组的栅格数
                            });
                        }
                    }
                } catch (error) {
                    // 如果union失败，将每个栅格作为独立组
                    cellPolygons.forEach((polygon, index) => {
                        mergedCellGroups.push({
                            geometry: polygon,
                            groupIndex: index,
                            cellCount: 1
                        });
                    });
                }
            }

            // 3. 将栅格组转换为新的宣称区域（不操作清理后的无冲突区域）
            const newClaimBlocks = [];

            for (let i = 0; i < mergedCellGroups.length; i++) {
                const cellGroup = mergedCellGroups[i];
                const cellsBoundary = convertTurfPolygonToMCCoords(cellGroup.geometry);
                if (cellsBoundary && cellsBoundary.length >= 3) {
                    const newClaimBlock = {
                        id: `${countryName}_conflict_resolution_group_${i}`,
                        countryName: countryName,
                        boundary: cellsBoundary,
                        area: turf.area(cellGroup.geometry),
                        spawnPoints: [],
                        metadata: {
                            blockType: 'conflict-resolved-cells-group',
                            sourceAssignments: cellGroup.cellCount,
                            groupIndex: i,
                            resolutionMethod: 'grid-union',
                            mergedAt: new Date().toISOString()
                        }
                    };
                    newClaimBlocks.push(newClaimBlock);
                    totalFusedCells += cellGroup.cellCount;
                }
            }

            if (newClaimBlocks.length > 0) {
                optimizationState.mergedClaimBlocks.set(countryName, newClaimBlocks);
                totalMergedBlocks += newClaimBlocks.length;
                totalFusedCountries++;
            }
        }

        // 输出最终总结
        console.log(`✅ 栅格块融合完成！共处理了 ${totalProcessedCells} 个栅格块，通过Union操作自动识别连通性，生成了 ${totalMergedBlocks} 个新的宣称区域。`);
        console.log(`   这些新区域是基于栅格化分配冲突区域后重新生成的宣称区域。`);

        updateStatus('success', `步骤6完成: 栅格块融合完成，共处理了 ${totalProcessedCells} 个栅格块，生成了 ${totalMergedBlocks} 个新的宣称区域`);

        // 应用融合后的宣称块到宣称管理器
        applyMergedClaimBlocksToClaimsManager();

    } catch (error) {
        console.error('❌ 区域融合失败:', error);
        updateStatus('error', `步骤6失败: ${error.message}`);
    }
}

/**
 * 应用栅格融合结果到宣称管理器（组合清理后的区域和新生成的栅格区域）
 */
function applyMergedClaimBlocksToClaimsManager() {

    try {
        const finalClaims = new Map();

        // 1. 先添加所有国家的清理后宣称块（第3步的结果）
        for (const [countryName, cleanedBlocks] of optimizationState.cleanedClaimBlocks) {
            const claims = cleanedBlocks.map((block, index) => ({
                id: block.id,
                boundary: [block.boundary.map(coord => mcToMapCoords(coord[0], coord[1]))],
                area: block.area,
                metadata: {
                    ...block.metadata,
                    appliedAt: new Date().toISOString()
                },
                spawnPoints: block.spawnPoints || []
            }));

            finalClaims.set(countryName, {
                success: true,
                claims: claims,
                metadata: {
                    type: 'conflict-cleaned',
                    description: '清理冲突后的宣称区域',
                    generatedAt: new Date().toISOString()
                }
            });
        }

        // 2. 添加新生成的栅格区域（第6步的结果）
        for (const [countryName, newBlocks] of optimizationState.mergedClaimBlocks) {
            const newClaims = newBlocks.map((block, index) => ({
                id: block.id,
                boundary: [block.boundary.map(coord => mcToMapCoords(coord[0], coord[1]))],
                area: block.area,
                metadata: {
                    ...block.metadata,
                    appliedAt: new Date().toISOString()
                },
                spawnPoints: block.spawnPoints || []
            }));

            if (finalClaims.has(countryName)) {
                // 如果已有清理后的宣称块，添加新的栅格区域
                finalClaims.get(countryName).claims.push(...newClaims);
                finalClaims.get(countryName).metadata.type = 'conflict-resolved-combined';
                finalClaims.get(countryName).metadata.description = '清理冲突后的区域 + 新生成的栅格区域';
            } else {
                // 如果没有清理后的宣称块，只有新的栅格区域
                finalClaims.set(countryName, {
                    success: true,
                    claims: newClaims,
                    metadata: {
                        type: 'conflict-resolved-grid-only',
                        description: '仅包含新生成的栅格区域',
                        generatedAt: new Date().toISOString()
                    }
                });
            }
        }

        // 应用到宣称管理器
        countryClaimsManager.generatedClaims = finalClaims;

        // 刷新地图显示
        countryClaimsManager.clearDisplayedLayers();
        setTimeout(() => {
            countryClaimsManager.showCurrentGeneratedClaims();
        }, 300);

        console.log(`✅ 宣称区域已应用到地图显示: ${finalClaims.size} 个国家（包含清理后的区域和新生成的栅格区域）`);

    } catch (error) {
        console.error('❌ 应用融合后的宣称块失败:', error);
    }
}

/**
 * 步骤7: 生成最终宣称边界（Union合并清理后的区域和新生成的栅格区域）
 * 将第3步清理后的无冲突宣称区域与第6步生成的新栅格区域进行Union操作，
 * 生成每个国家最终的完整宣称区域
 */
function step7_outputFinalBoundaries() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    if (optimizationState.cleanedClaimBlocks.size === 0 && optimizationState.mergedClaimBlocks.size === 0) {
        updateStatus('error', '请先执行步骤3和步骤6');
        return;
    }

    console.log('7️⃣ 开始生成最终宣称边界（Union合并清理后的区域和新栅格区域）...');
    updateStatus('info', '步骤7: 正在Union合并各国的清理后区域和新栅格区域...');

    try {
        optimizationState.finalBoundaries.clear();

        let totalCountries = 0;
        let totalFinalClaims = 0;
        let totalUnionOperations = 0;

        // 获取所有涉及的国家
        const allCountries = new Set([
            ...optimizationState.cleanedClaimBlocks.keys(),
            ...optimizationState.mergedClaimBlocks.keys()
        ]);

        for (const countryName of allCountries) {
            const cleanedBlocks = optimizationState.cleanedClaimBlocks.get(countryName) || [];
            const newBlocks = optimizationState.mergedClaimBlocks.get(countryName) || [];

            if (cleanedBlocks.length === 0 && newBlocks.length === 0) {
                continue;
            }

            // 收集所有需要合并的多边形
            const allPolygons = [];

            // 添加清理后的宣称块
            for (const block of cleanedBlocks) {
                const polygon = createValidTurfPolygon(block.boundary);
                if (polygon) {
                    allPolygons.push({
                        geometry: polygon,
                        source: 'cleaned',
                        id: block.id,
                        area: block.area
                    });
                }
            }

            // 添加新生成的栅格区域
            for (const block of newBlocks) {
                const polygon = createValidTurfPolygon(block.boundary);
                if (polygon) {
                    allPolygons.push({
                        geometry: polygon,
                        source: 'grid',
                        id: block.id,
                        area: block.area
                    });
                }
            }

            if (allPolygons.length === 0) {
                continue;
            }

            // 执行Union操作合并所有多边形
            let finalUnion = null;
            if (allPolygons.length === 1) {
                finalUnion = allPolygons[0].geometry;
            } else {
                try {
                    finalUnion = allPolygons[0].geometry;
                    for (let i = 1; i < allPolygons.length; i++) {
                        const union = turf.union(finalUnion, allPolygons[i].geometry);
                        if (union && union.geometry) {
                            finalUnion = union;
                            totalUnionOperations++;
                        }
                    }
                } catch (error) {
                    console.warn(`⚠️ 国家 "${countryName}" Union操作失败: ${error.message}`);
                    continue;
                }
            }

            if (!finalUnion) {
                continue;
            }

            // 处理Union结果，生成最终宣称区域
            const finalClaims = [];

            if (finalUnion.geometry.type === 'Polygon') {
                // 单个连通区域 - 创建单一宣称区域
                const boundary = convertTurfPolygonToMCCoords(finalUnion);
                if (boundary && boundary.length >= 3) {
                    finalClaims.push({
                        id: `${countryName}_final_unified`,
                        boundary: boundary,
                        area: turf.area(finalUnion),
                        metadata: {
                            boundaryType: 'final-unified-single',
                            geometryType: 'Polygon',
                            sourceBlocks: allPolygons.length,
                            cleanedBlocks: cleanedBlocks.length,
                            gridBlocks: newBlocks.length,
                            unionOperations: totalUnionOperations,
                            finalizedAt: new Date().toISOString()
                        },
                        spawnPoints: []
                    });
                }
                console.log(`   国家 "${countryName}": Union结果为单个连通区域 (Polygon)`);
            } else if (finalUnion.geometry.type === 'MultiPolygon') {
                // 多个不连通区域 - 创建一个包含所有不相连区域的MultiPolygon宣称
                const coordinates = finalUnion.geometry.coordinates;
                const totalArea = turf.area(finalUnion);

                // 将MultiPolygon的所有坐标转换为MC坐标格式
                const multiPolygonBoundary = coordinates.map(polygonCoords => {
                    // 每个polygon的外环坐标
                    return polygonCoords[0].map(coord => [coord[0], coord[1]]);
                });

                finalClaims.push({
                    id: `${countryName}_final_unified_multipolygon`,
                    boundary: multiPolygonBoundary, // 多环边界结构
                    area: totalArea,
                    metadata: {
                        boundaryType: 'final-unified-multipolygon',
                        geometryType: 'MultiPolygon',
                        disconnectedRegions: coordinates.length,
                        sourceBlocks: allPolygons.length,
                        cleanedBlocks: cleanedBlocks.length,
                        gridBlocks: newBlocks.length,
                        unionOperations: totalUnionOperations,
                        finalizedAt: new Date().toISOString()
                    },
                    spawnPoints: []
                });

                console.log(`   国家 "${countryName}": Union结果为 ${coordinates.length} 个不相连区域 (MultiPolygon)`);
                console.log(`     总面积: ${Math.round(totalArea).toLocaleString()} 平方米`);

                // 输出每个不相连区域的详细信息
                coordinates.forEach((polygonCoords, i) => {
                    const singlePolygon = turf.polygon(polygonCoords);
                    const partArea = turf.area(singlePolygon);
                    console.log(`     区域 ${i + 1}: ${Math.round(partArea).toLocaleString()} 平方米`);
                });
            }

            if (finalClaims.length > 0) {
                optimizationState.finalBoundaries.set(countryName, finalClaims);
                totalCountries++;
                totalFinalClaims += finalClaims.length;
            }
        }

        // 统计MultiPolygon结果
        let singlePolygonCount = 0;
        let multiPolygonCount = 0;
        let totalDisconnectedRegions = 0;

        for (const [countryName, boundaries] of optimizationState.finalBoundaries) {
            for (const boundary of boundaries) {
                if (boundary.metadata?.geometryType === 'MultiPolygon') {
                    multiPolygonCount++;
                    totalDisconnectedRegions += boundary.metadata?.disconnectedRegions || 0;
                } else {
                    singlePolygonCount++;
                }
            }
        }

        // 输出最终总结
        console.log(`✅ 最终宣称边界生成完成！通过Union操作将清理后的区域和新栅格区域合并为完整的国家宣称区域。`);
        console.log(`   处理了 ${totalCountries} 个国家，执行了 ${totalUnionOperations} 次Union操作，生成了 ${totalFinalClaims} 个最终宣称区域。`);
        console.log(`   其中: ${singlePolygonCount} 个连通区域 (Polygon), ${multiPolygonCount} 个不相连区域集合 (MultiPolygon)`);
        if (multiPolygonCount > 0) {
            console.log(`   MultiPolygon包含总计 ${totalDisconnectedRegions} 个不相连的子区域`);
        }
        updateStatus('success', `步骤7完成: 为 ${totalCountries} 个国家生成 ${totalFinalClaims} 个最终统一宣称区域 (含 ${multiPolygonCount} 个MultiPolygon)`);

        // 应用最终边界到宣称管理器
        applyFinalBoundariesToClaimsManager();

        // 显示最终结果统计
        displayFinalStatistics();

    } catch (error) {
        console.error('❌ 生成最终边界失败:', error);
        updateStatus('error', `步骤7失败: ${error.message}`);
    }
}

/**
 * 应用最终边界到宣称管理器
 */
function applyFinalBoundariesToClaimsManager() {
    try {
        const finalClaims = new Map();

        for (const [countryName, boundaries] of optimizationState.finalBoundaries) {
            const claims = boundaries.map((boundary, index) => {
                let boundaryForMap;

                // 根据边界类型处理坐标转换
                if (boundary.metadata?.geometryType === 'MultiPolygon') {
                    // MultiPolygon: boundary是多环结构 [[ring1], [ring2], ...]
                    boundaryForMap = boundary.boundary.map(ring =>
                        ring.map(coord => mcToMapCoords(coord[0], coord[1]))
                    );
                    console.log(`   转换MultiPolygon边界: ${boundary.boundary.length} 个不相连区域`);
                } else {
                    // Polygon: boundary是单环结构 [coord1, coord2, ...]
                    boundaryForMap = [boundary.boundary.map(coord => mcToMapCoords(coord[0], coord[1]))];
                    console.log(`   转换Polygon边界: 单个区域`);
                }

                return {
                    id: boundary.id,
                    boundary: boundaryForMap,
                    area: boundary.area,
                    metadata: {
                        ...boundary.metadata,
                        appliedAt: new Date().toISOString()
                    },
                    spawnPoints: boundary.spawnPoints || []
                };
            });

            finalClaims.set(countryName, {
                success: true,
                claims: claims,
                metadata: {
                    type: 'final-unified',
                    description: '最终统一的宣称区域（清理后区域 + 新栅格区域）',
                    generatedAt: new Date().toISOString(),
                    processingSteps: [
                        'step1-build-claim-blocks',
                        'step2-detect-conflicts',
                        'step3-remove-conflicts',
                        'step4-rasterize-conflicts',
                        'step5-assign-ownership',
                        'step6-merge-grid-areas',
                        'step7-union-final-boundaries'
                    ]
                }
            });
        }

        // 应用到宣称管理器
        countryClaimsManager.generatedClaims = finalClaims;

        // 刷新地图显示
        countryClaimsManager.clearDisplayedLayers();
        setTimeout(() => {
            countryClaimsManager.showCurrentGeneratedClaims();
        }, 300);

        console.log(`✅ 最终统一边界已应用到地图显示: ${finalClaims.size} 个国家`);

    } catch (error) {
        console.error('❌ 应用最终边界失败:', error);
    }
}



// 测试函数已删除

// 调试函数已删除

// 验证函数已删除

// 验证函数已删除

// 测试函数已删除

// 测试函数已删除

// 测试函数已删除

// 测试函数已删除

/**
 * 显示最终统计信息
 */
function displayFinalStatistics() {
    console.log('📊 最终统计信息:');

    let totalArea = 0;
    let cleanedBlocks = 0;
    let resolvedBlocks = 0;
    let originalBlocks = 0;

    for (const [countryName, claims] of optimizationState.finalBoundaries) {
        let countryArea = 0;
        let countryCleanedBlocks = 0;
        let countryResolvedBlocks = 0;
        let countryOriginalBlocks = 0;

        for (const claim of claims) {
            countryArea += claim.area || 0;

            if (claim.metadata?.blockType === 'conflict-cleaned') {
                countryCleanedBlocks++;
                cleanedBlocks++;
            } else if (claim.metadata?.blockType === 'conflict-resolved') {
                countryResolvedBlocks++;
                resolvedBlocks++;
            } else {
                countryOriginalBlocks++;
                originalBlocks++;
            }
        }

        totalArea += countryArea;

        console.log(`   ${countryName}:`);
        console.log(`     总面积: ${Math.round(countryArea).toLocaleString()} 平方米`);
        console.log(`     宣称块: ${claims.length} 个 (原始: ${countryOriginalBlocks}, 清理: ${countryCleanedBlocks}, 解决: ${countryResolvedBlocks})`);
    }

    console.log(`📈 总体统计:`);
    console.log(`   总面积: ${Math.round(totalArea).toLocaleString()} 平方米`);
    console.log(`   总宣称块: ${originalBlocks + cleanedBlocks + resolvedBlocks} 个`);
    console.log(`   - 原始宣称块: ${originalBlocks} 个`);
    console.log(`   - 冲突清理块: ${cleanedBlocks} 个`);
    console.log(`   - 冲突解决块: ${resolvedBlocks} 个`);
}

/**
 * 清除所有高亮显示
 */
function clearAllHighlights() {
    console.log('🗑️ 清除所有高亮显示...');

    // 清除冲突区域图层
    if (window.conflictAreaLayers) {
        window.conflictAreaLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除冲突区域图层时出错:', e);
            }
        });
        window.conflictAreaLayers = [];
    }

    // 清除栅格图层
    if (window.gridCellLayers) {
        window.gridCellLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
        window.gridCellLayers = [];
    }

    // 清除分配图层
    if (window.assignmentLayers) {
        window.assignmentLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除分配图层时出错:', e);
            }
        });
        window.assignmentLayers = [];
    }

    console.log('✅ 所有高亮显示已清除');
    updateStatus('info', '已清除所有高亮显示');
}

// 调试函数已删除

// 验证函数已删除

// 调试函数已删除

/**
 * 检查高级处理状态
 */
function checkAdvancedProcessStatus() {
    console.log('📊 检查高级处理状态...');

    const status = {
        step1: optimizationState.claimBlocks.size > 0,
        step2: optimizationState.conflictAreas.size > 0,
        step3: optimizationState.cleanedClaimBlocks.size > 0,
        step4: optimizationState.gridCells.size > 0,
        step5: optimizationState.cellAssignments.size > 0,
        step6: optimizationState.mergedClaimBlocks.size > 0,
        step7: optimizationState.finalBoundaries.size > 0
    };

    console.log('📋 各步骤状态:');
    console.log(`   步骤1 (构建宣称块): ${status.step1 ? '✅' : '❌'} (${optimizationState.claimBlocks.size} 个国家)`);
    console.log(`   步骤2 (检测冲突): ${status.step2 ? '✅' : '❌'} (${optimizationState.conflictAreas.size} 个冲突区域)`);
    console.log(`   步骤3 (删除冲突): ${status.step3 ? '✅' : '❌'} (${optimizationState.cleanedClaimBlocks.size} 个国家)`);
    console.log(`   步骤4 (栅格化): ${status.step4 ? '✅' : '❌'} (${optimizationState.gridCells.size} 个栅格单元)`);
    console.log(`   步骤5 (归属判定): ${status.step5 ? '✅' : '❌'} (${optimizationState.cellAssignments.size} 个分配)`);
    console.log(`   步骤6 (合并区域): ${status.step6 ? '✅' : '❌'} (${optimizationState.mergedClaimBlocks.size} 个国家)`);
    console.log(`   步骤7 (最终边界): ${status.step7 ? '✅' : '❌'} (${optimizationState.finalBoundaries.size} 个国家)`);

    const completedSteps = Object.values(status).filter(s => s).length;
    const statusMessage = `高级处理状态: ${completedSteps}/7 步骤完成`;

    updateStatus('info', statusMessage);
    console.log(`📊 ${statusMessage}`);

    return status;
}

/**
 * 调试生成的宣称数据结构
 */
function debugGeneratedClaimsStructure() {
    console.log('🔍 调试生成的宣称数据结构...');

    if (!countryClaimsManager || !countryClaimsManager.generatedClaims) {
        console.log('❌ 宣称管理器或生成的宣称数据不存在');
        updateStatus('error', '宣称管理器未初始化');
        return;
    }

    console.log(`📊 生成的宣称数据概览:`);
    console.log(`   国家数量: ${countryClaimsManager.generatedClaims.size}`);

    for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
        console.log(`🏛️ 国家: ${countryName}`);
        console.log(`   成功状态: ${claimsResult.success ? '✅' : '❌'}`);

        if (claimsResult.success && claimsResult.claims) {
            console.log(`   宣称区域数量: ${claimsResult.claims.length}`);

            claimsResult.claims.forEach((claim, index) => {
                console.log(`     区域 ${index}:`);
                console.log(`       ID: ${claim.id}`);
                console.log(`       面积: ${claim.area ? Math.round(claim.area).toLocaleString() : '未知'} 平方米`);
                console.log(`       边界点数: ${claim.boundary ? (Array.isArray(claim.boundary[0]) ? claim.boundary[0].length : claim.boundary.length) : 0}`);
                console.log(`       出生点数: ${claim.spawnPoints ? claim.spawnPoints.length : 0}`);
                console.log(`       元数据类型: ${claim.metadata?.blockType || claim.metadata?.type || '未知'}`);
            });
        } else {
            console.log(`   错误信息: ${claimsResult.error || '未知错误'}`);
        }
    }

    updateStatus('info', `调试完成: ${countryClaimsManager.generatedClaims.size} 个国家的数据结构已输出到控制台`);
}

/**
 * 查看存储的冲突解决边界
 */
function viewStoredConflictResolvedBoundaries() {
    console.log('📋 查看存储的冲突解决边界...');

    if (optimizationState.finalBoundaries.size === 0) {
        console.log('❌ 没有找到最终边界数据');
        updateStatus('warning', '请先执行步骤7: 输出最终边界');
        return;
    }

    console.log(`📊 冲突解决边界概览:`);
    console.log(`   国家数量: ${optimizationState.finalBoundaries.size}`);

    let totalArea = 0;
    let totalClaims = 0;

    for (const [countryName, claims] of optimizationState.finalBoundaries) {
        let countryArea = 0;

        console.log(`🏛️ 国家: ${countryName}`);
        console.log(`   宣称区域数量: ${claims.length}`);

        claims.forEach((claim, index) => {
            const area = claim.area || 0;
            countryArea += area;

            console.log(`     区域 ${index}:`);
            console.log(`       ID: ${claim.id}`);
            console.log(`       面积: ${Math.round(area).toLocaleString()} 平方米`);
            console.log(`       边界点数: ${claim.boundary ? claim.boundary.length : 0}`);
            console.log(`       边界类型: ${claim.metadata?.boundaryType || '未知'}`);
            console.log(`       最终化时间: ${claim.metadata?.finalizedAt || '未知'}`);
        });

        console.log(`   国家总面积: ${Math.round(countryArea).toLocaleString()} 平方米`);
        totalArea += countryArea;
        totalClaims += claims.length;
    }

    console.log(`📈 总体统计:`);
    console.log(`   总面积: ${Math.round(totalArea).toLocaleString()} 平方米`);
    console.log(`   总宣称区域: ${totalClaims} 个`);

    updateStatus('success', `冲突解决边界: ${optimizationState.finalBoundaries.size} 个国家，${totalClaims} 个区域，总面积 ${Math.round(totalArea).toLocaleString()} 平方米`);
}

/**
 * 步骤8: 栅格化所有国家的所有宣称区域（修复版本）
 * 对步骤7生成的最终边界进行栅格化，为后续距离检测做准备
 * 修复：使用optimizationState.finalBoundaries作为数据源，而不是countryClaimsManager.generatedClaims
 */
function step8_rasterizeAllClaims() {
    console.log('8️⃣ 开始栅格化所有国家的最终宣称边界（修复版本：使用步骤7的结果）...');
    updateStatus('info', '步骤8: 正在对步骤7的最终边界进行栅格化...');

    try {
        // 检查是否有步骤7的最终边界数据
        if (!optimizationState.finalBoundaries || optimizationState.finalBoundaries.size === 0) {
            updateStatus('error', '请先完成步骤7: 生成最终宣称边界');
            return;
        }

        // 获取步骤8宣称栅格配置（从配置界面读取）
        const gridSize = typeof getClaimsGridSize === 'function' ? getClaimsGridSize() : 4; // 从配置获取，默认4区块
        const cellSizeBlocks = gridSize * 16; // 转换为方块单位

        // 初始化全局栅格状态
        if (!window.globalRasterState) {
            window.globalRasterState = {
                allCountryGrids: new Map(), // 存储所有国家的栅格
                gridSize: gridSize,
                cellSizeBlocks: cellSizeBlocks,
                totalGrids: 0,
                gridDistances: new Map(), // 存储栅格到出生点的距离
                gridAssignments: new Map() // 存储栅格的国家归属
            };
        } else {
            // 更新栅格配置（如果配置发生变化）
            window.globalRasterState.gridSize = gridSize;
            window.globalRasterState.cellSizeBlocks = cellSizeBlocks;
        }

        const rasterState = window.globalRasterState;
        rasterState.allCountryGrids.clear();
        rasterState.gridDistances.clear();
        rasterState.gridAssignments.clear();
        rasterState.totalGrids = 0;

        console.log(`📐 步骤8宣称栅格配置: ${rasterState.gridSize}区块 = ${rasterState.cellSizeBlocks}方块 (来自配置界面)`);

        // 调试：检查步骤7的最终边界数据结构
        console.log(`📊 检查步骤7的最终边界数据结构:`);
        console.log(`   总国家数: ${optimizationState.finalBoundaries.size}`);
        for (const [countryName, boundaries] of optimizationState.finalBoundaries) {
            console.log(`   国家 "${countryName}": ${boundaries.length} 个最终边界区域`);
            if (boundaries.length > 0) {
                const firstBoundary = boundaries[0];
                console.log(`     第一个边界区域结构:`, {
                    id: firstBoundary.id,
                    geometryType: firstBoundary.metadata?.geometryType,
                    boundaryType: firstBoundary.metadata?.boundaryType,
                    boundaryLength: Array.isArray(firstBoundary.boundary) ? firstBoundary.boundary.length : 'N/A',
                    area: Math.round(firstBoundary.area || 0)
                });
            }
        }

        // 为每个国家的每个最终边界区域生成栅格
        for (const [countryName, boundaries] of optimizationState.finalBoundaries) {
            console.log(`🏛️ 栅格化国家 "${countryName}" 的 ${boundaries.length} 个最终边界区域...`);
            const countryGrids = [];

            for (const boundary of boundaries) {
                console.log(`   处理最终边界区域: ${boundary.id}`);

                // 处理不同类型的边界结构
                const boundaryPolygons = [];

                if (boundary.metadata?.geometryType === 'MultiPolygon') {
                    // MultiPolygon: boundary是多环结构 [[ring1], [ring2], ...]
                    console.log(`     MultiPolygon结构，包含 ${boundary.boundary.length} 个不相连区域`);

                    for (let i = 0; i < boundary.boundary.length; i++) {
                        const ring = boundary.boundary[i];
                        console.log(`       处理不相连区域 ${i + 1}: ${ring.length} 个坐标点`);

                        if (ring.length >= 3) {
                            boundaryPolygons.push({
                                coordinates: ring,
                                regionIndex: i,
                                type: 'MultiPolygon-part'
                            });
                        } else {
                            console.warn(`       跳过区域 ${i + 1}: 坐标点不足 (${ring.length} < 3)`);
                        }
                    }
                } else {
                    // Polygon: boundary是单环结构 [coord1, coord2, ...]
                    console.log(`     Polygon结构，单个区域: ${boundary.boundary.length} 个坐标点`);

                    if (boundary.boundary.length >= 3) {
                        boundaryPolygons.push({
                            coordinates: boundary.boundary,
                            regionIndex: 0,
                            type: 'Polygon'
                        });
                    } else {
                        console.warn(`     跳过区域: 坐标点不足 (${boundary.boundary.length} < 3)`);
                    }
                }

                // 为每个多边形生成栅格
                for (const polygon of boundaryPolygons) {
                    const polygonId = `${boundary.id}_region_${polygon.regionIndex}`;
                    console.log(`     处理多边形: ${polygonId} (${polygon.type})`);

                    // 边界数据已经是MC坐标格式，无需转换
                    const mcBoundary = polygon.coordinates;

                    console.log(`       MC坐标数量: ${mcBoundary.length}`);
                    if (mcBoundary.length > 0) {
                        console.log(`       第一个MC坐标:`, mcBoundary[0]);
                        console.log(`       最后一个MC坐标:`, mcBoundary[mcBoundary.length - 1]);
                    }

                    // 创建Turf多边形用于栅格检测
                    const turfPolygon = createValidTurfPolygon(mcBoundary);
                    if (!turfPolygon) {
                        console.warn(`⚠️ 多边形 ${polygonId} 无法创建有效多边形，跳过`);
                        continue;
                    }

                    // 计算边界框
                    const bounds = turf.bbox(turfPolygon);
                    const [minX, minY, maxX, maxY] = bounds;

                    console.log(`       边界框: X(${Math.round(minX)} ~ ${Math.round(maxX)}) Y(${Math.round(minY)} ~ ${Math.round(maxY)})`);

                    // 生成栅格
                    const polygonGrids = generateGridsForClaim(turfPolygon, bounds, countryName, polygonId, rasterState);
                    countryGrids.push(...polygonGrids);

                    console.log(`       生成了 ${polygonGrids.length} 个栅格单元`);
                }
            }

            if (countryGrids.length > 0) {
                rasterState.allCountryGrids.set(countryName, countryGrids);
                rasterState.totalGrids += countryGrids.length;
                console.log(`   国家 "${countryName}" 总计生成 ${countryGrids.length} 个栅格单元`);
            }
        }

        console.log(`✅ 栅格化完成！总计生成 ${rasterState.totalGrids} 个栅格单元`);
        updateStatus('success', `步骤8完成: 生成 ${rasterState.totalGrids} 个栅格单元，覆盖 ${rasterState.allCountryGrids.size} 个国家`);

        // 可视化所有栅格
        visualizeAllCountryGrids();

    } catch (error) {
        console.error('❌ 栅格化所有宣称区域失败:', error);
        updateStatus('error', `步骤8失败: ${error.message}`);
    }
}

/**
 * 为单个宣称区域生成栅格
 * @param {Object} turfPolygon - Turf多边形对象
 * @param {Array} bounds - 边界框 [minX, minY, maxX, maxY]
 * @param {string} countryName - 国家名称
 * @param {string} claimId - 宣称区域ID
 * @param {Object} rasterState - 栅格状态对象
 * @returns {Array} 栅格单元数组
 */
function generateGridsForClaim(turfPolygon, bounds, countryName, claimId, rasterState) {
    const grids = [];
    const [minX, minY, maxX, maxY] = bounds;
    const cellSize = rasterState.cellSizeBlocks;

    console.log(`       栅格生成参数:`, {
        bounds: `X(${Math.round(minX)} ~ ${Math.round(maxX)}) Y(${Math.round(minY)} ~ ${Math.round(maxY)})`,
        cellSize: cellSize,
        area: `${Math.round(maxX - minX)} x ${Math.round(maxY - minY)} 方块`
    });

    // 计算栅格数量
    const cellsX = Math.ceil((maxX - minX) / cellSize);
    const cellsY = Math.ceil((maxY - minY) / cellSize);

    console.log(`       将生成 ${cellsX} x ${cellsY} = ${cellsX * cellsY} 个候选栅格`);

    let validCells = 0;
    let checkedCells = 0;

    // 生成栅格
    for (let i = 0; i < cellsX; i++) {
        for (let j = 0; j < cellsY; j++) {
            checkedCells++;
            const cellMinX = minX + i * cellSize;
            const cellMinY = minY + j * cellSize;
            const cellMaxX = Math.min(cellMinX + cellSize, maxX);
            const cellMaxY = Math.min(cellMinY + cellSize, maxY);

            // 计算格子中心点
            const centerX = (cellMinX + cellMaxX) / 2;
            const centerY = (cellMinY + cellMaxY) / 2;

            // 检查栅格单元是否在宣称区域内
            let isValidCell = false;

            try {
                // 检查中心点是否在多边形内
                const centerPoint = turf.point([centerX, centerY]);
                const centerInPolygon = turf.booleanPointInPolygon(centerPoint, turfPolygon);

                if (centerInPolygon) {
                    isValidCell = true;
                } else {
                    // 检查栅格单元是否与多边形相交
                    const cellPolygon = turf.polygon([[
                        [cellMinX, cellMinY],
                        [cellMaxX, cellMinY],
                        [cellMaxX, cellMaxY],
                        [cellMinX, cellMaxY],
                        [cellMinX, cellMinY]
                    ]]);

                    const intersection = turf.intersect(cellPolygon, turfPolygon);
                    isValidCell = intersection !== null;
                }
            } catch (checkError) {
                console.warn(`⚠️ 栅格有效性检测失败: ${checkError.message}`);
                continue;
            }

            if (isValidCell) {
                validCells++;
                const gridId = `${countryName}_${claimId}_grid_${i}_${j}`;

                const gridInfo = {
                    id: gridId,
                    countryName: countryName,
                    claimId: claimId,
                    centerX: centerX,
                    centerY: centerY,
                    bounds: [cellMinX, cellMinY, cellMaxX, cellMaxY],
                    gridPosition: [i, j],
                    area: (cellMaxX - cellMinX) * (cellMaxY - cellMinY),
                    createdAt: new Date().toISOString(),
                    distanceToNearestSpawn: null, // 将在步骤9中计算
                    nearestSpawnPoint: null // 将在步骤9中设置
                };

                grids.push(gridInfo);
                rasterState.gridAssignments.set(gridId, countryName);
            }
        }
    }

    console.log(`       栅格生成完成: ${validCells}/${checkedCells} 个有效栅格`);
    return grids;
}

/**
 * 步骤9: 检测每个国家栅格到最近出生点的距离
 * 每个国家自己的栅格区域进行对最近的国家的城镇的出生点检测，距离进行排列，点击栅格会显示距离
 */
async function step9_detectNearestSpawnPoints() {
    console.log('9️⃣ 开始检测每个国家栅格到最近出生点的距离...');
    updateStatus('info', '步骤9: 正在计算栅格到最近出生点的距离...');

    try {
        // 检查是否完成了步骤8
        if (!window.globalRasterState || window.globalRasterState.totalGrids === 0) {
            updateStatus('error', '请先执行步骤8: 栅格化所有宣称区域');
            return;
        }

        const rasterState = window.globalRasterState;
        rasterState.gridDistances.clear();

        // 获取所有国家的出生点数据
        console.log('🔍 正在从IndexedDB获取国家出生点数据...');
        let storedCountrySpawn = await getStoredCountrySpawn();

        if (!storedCountrySpawn || Object.keys(storedCountrySpawn).length === 0) {
            console.log('⚠️ 没有找到存储的出生点数据，尝试从领地数据中提取...');
            storedCountrySpawn = await extractSpawnPointsFromTerritories();
        }

        if (!storedCountrySpawn || Object.keys(storedCountrySpawn).length === 0) {
            updateStatus('error', '无法获取国家出生点数据，请确保已加载领地数据');
            return;
        }

        console.log(`📊 获取到 ${Object.keys(storedCountrySpawn).length} 个国家的出生点数据`);

        let totalProcessedGrids = 0;
        let totalDistancesCalculated = 0;

        // 为每个国家的栅格计算到最近出生点的距离
        for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
            console.log(`🏛️ 处理国家 "${countryName}" 的 ${countryGrids.length} 个栅格...`);

            // 获取该国家的出生点数据
            const countryData = storedCountrySpawn[countryName];
            if (!countryData) {
                console.warn(`⚠️ 国家 "${countryName}" 没有数据，跳过`);
                continue;
            }

            // 提取出生点数组
            let spawnPoints = [];

            // 检查数据结构：优先使用 spawns 数组
            if (countryData.spawns && Array.isArray(countryData.spawns)) {
                spawnPoints = countryData.spawns;
                console.log(`   从 spawns 数组找到 ${spawnPoints.length} 个出生点`);
            } else if (Array.isArray(countryData)) {
                // 如果 countryData 本身就是数组（备用方案）
                spawnPoints = countryData;
                console.log(`   从数组格式找到 ${spawnPoints.length} 个出生点`);
            } else {
                // 尝试从对象属性中提取出生点
                for (const [key, value] of Object.entries(countryData)) {
                    if (key !== 'spawns' && value && typeof value === 'object' &&
                        value.x !== undefined && value.z !== undefined) {
                        spawnPoints.push({
                            x: value.x,
                            z: value.z,
                            name: value.name || value.label || key,
                            markerId: key
                        });
                    }
                }
                console.log(`   从对象属性提取到 ${spawnPoints.length} 个出生点`);
            }

            if (spawnPoints.length === 0) {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的出生点数据，跳过`);
                console.log(`   数据结构:`, countryData);
                continue;
            }

            console.log(`   找到 ${spawnPoints.length} 个出生点，开始计算距离...`);

            // 为每个栅格计算到最近出生点的距离
            for (const grid of countryGrids) {
                let minDistance = Infinity;
                let nearestSpawnPoint = null;

                // 计算到每个出生点的距离
                for (const spawnPoint of spawnPoints) {
                    const distance = calculateDistance(
                        { x: grid.centerX, z: grid.centerY },
                        { x: spawnPoint.x, z: spawnPoint.z }
                    );

                    if (distance < minDistance) {
                        minDistance = distance;
                        nearestSpawnPoint = spawnPoint;
                    }
                }

                // 存储距离信息
                grid.distanceToNearestSpawn = minDistance;
                grid.nearestSpawnPoint = nearestSpawnPoint;

                const distanceKey = `${grid.id}`;
                rasterState.gridDistances.set(distanceKey, {
                    gridId: grid.id,
                    countryName: countryName,
                    distance: minDistance,
                    nearestSpawn: nearestSpawnPoint,
                    gridCenter: { x: grid.centerX, y: grid.centerY }
                });

                totalDistancesCalculated++;
            }

            // 按距离排序该国家的栅格
            countryGrids.sort((a, b) => a.distanceToNearestSpawn - b.distanceToNearestSpawn);

            console.log(`   完成距离计算，最近距离: ${Math.round(countryGrids[0]?.distanceToNearestSpawn || 0)}方块，最远距离: ${Math.round(countryGrids[countryGrids.length - 1]?.distanceToNearestSpawn || 0)}方块`);
            totalProcessedGrids += countryGrids.length;
        }

        console.log(`✅ 距离检测完成！处理了 ${totalProcessedGrids} 个栅格，计算了 ${totalDistancesCalculated} 个距离`);
        updateStatus('success', `步骤9完成: 计算了 ${totalDistancesCalculated} 个栅格到出生点的距离`);

        // 可视化带距离信息的栅格
        visualizeGridsWithDistances();

    } catch (error) {
        console.error('❌ 检测最近出生点距离失败:', error);
        updateStatus('error', `步骤9失败: ${error.message}`);
    }
}

/**
 * 计算两点之间的欧几里得距离
 * @param {Object} point1 - 点1 {x, z}
 * @param {Object} point2 - 点2 {x, z}
 * @returns {number} 距离（方块）
 */
function calculateDistance(point1, point2) {
    const dx = point1.x - point2.x;
    const dz = point1.z - point2.z;
    return Math.sqrt(dx * dx + dz * dz);
}

/**
 * 从领地数据中提取出生点信息（修复版本）
 * 返回与数据管理器一致的数据结构
 * @returns {Object} 国家出生点数据
 */
async function extractSpawnPointsFromTerritories() {
    try {
        const storedData = await getStoredData();
        const countrySpawnPoints = {};

        if (storedData && storedData.territories) {
            for (const territory of storedData.territories) {
                if (territory.nation && territory.spawn) {
                    const countryName = territory.nation;

                    if (!countrySpawnPoints[countryName]) {
                        countrySpawnPoints[countryName] = {
                            spawns: []  // 使用与数据管理器一致的结构
                        };
                    }

                    countrySpawnPoints[countryName].spawns.push({
                        x: territory.spawn.x,
                        z: territory.spawn.z,
                        name: territory.name,
                        territoryName: territory.name
                    });
                }
            }
        }

        console.log(`📊 从领地数据中提取到 ${Object.keys(countrySpawnPoints).length} 个国家的出生点`);

        // 输出详细统计
        for (const [countryName, countryData] of Object.entries(countrySpawnPoints)) {
            console.log(`   国家 "${countryName}": ${countryData.spawns.length} 个出生点`);
        }

        return countrySpawnPoints;

    } catch (error) {
        console.error('❌ 从领地数据提取出生点失败:', error);
        return {};
    }
}

/**
 * 步骤10: 删除距离最远的栅格（可配置百分比）
 * 为每个国家删除距离出生点最远的指定百分比栅格，优化宣称区域
 */
function step10_removeFarthestGrids() {
    const removalPercentage = typeof getRemovalPercentage === 'function' ? getRemovalPercentage() : 10;
    console.log(`🔟 开始删除距离最远的${removalPercentage}%栅格...`);
    updateStatus('info', `步骤10: 正在删除每个国家距离最远的${removalPercentage}%栅格...`);

    try {
        // 检查是否完成了步骤9
        if (!window.globalRasterState || window.globalRasterState.gridDistances.size === 0) {
            updateStatus('error', '请先执行步骤9: 检测最近出生点距离');
            return;
        }

        const rasterState = window.globalRasterState;
        let totalRemovedGrids = 0;
        let totalRemainingGrids = 0;

        // 获取删除百分比配置
        const removalPercentage = typeof getRemovalPercentage === 'function' ? getRemovalPercentage() : 10; // 从配置获取，默认10%
        const removalRatio = removalPercentage / 100;

        console.log(`🔧 使用配置的删除百分比: ${removalPercentage}%`);

        // 为每个国家删除最远的指定百分比栅格
        for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
            console.log(`🏛️ 处理国家 "${countryName}" 的 ${countryGrids.length} 个栅格...`);

            // 确保栅格已按距离排序（步骤9中已排序）
            const sortedGrids = [...countryGrids].sort((a, b) => a.distanceToNearestSpawn - b.distanceToNearestSpawn);

            // 计算要删除的栅格数量（使用配置的百分比）
            const totalGrids = sortedGrids.length;
            const gridsToRemove = Math.floor(totalGrids * removalRatio);
            const gridsToKeep = totalGrids - gridsToRemove;

            console.log(`   总栅格: ${totalGrids}, 删除: ${gridsToRemove} (${removalPercentage}%), 保留: ${gridsToKeep}`);

            if (gridsToRemove > 0) {
                // 保留距离最近的90%栅格
                const remainingGrids = sortedGrids.slice(0, gridsToKeep);
                const removedGrids = sortedGrids.slice(gridsToKeep);

                // 更新栅格状态
                rasterState.allCountryGrids.set(countryName, remainingGrids);

                // 从距离映射中删除被移除的栅格
                for (const removedGrid of removedGrids) {
                    rasterState.gridDistances.delete(removedGrid.id);
                    rasterState.gridAssignments.delete(removedGrid.id);
                }

                totalRemovedGrids += gridsToRemove;
                totalRemainingGrids += gridsToKeep;

                console.log(`   删除了最远的 ${gridsToRemove} 个栅格`);
                console.log(`   删除的栅格距离范围: ${Math.round(removedGrids[0]?.distanceToNearestSpawn || 0)} ~ ${Math.round(removedGrids[removedGrids.length - 1]?.distanceToNearestSpawn || 0)} 方块`);
                console.log(`   保留的栅格距离范围: ${Math.round(remainingGrids[0]?.distanceToNearestSpawn || 0)} ~ ${Math.round(remainingGrids[remainingGrids.length - 1]?.distanceToNearestSpawn || 0)} 方块`);
            } else {
                console.log(`   栅格数量太少，不删除任何栅格`);
                totalRemainingGrids += totalGrids;
            }
        }

        // 更新总栅格数
        rasterState.totalGrids = totalRemainingGrids;

        console.log(`✅ 栅格优化完成！删除了 ${totalRemovedGrids} 个最远栅格，保留 ${totalRemainingGrids} 个栅格`);
        updateStatus('success', `步骤10完成: 删除 ${totalRemovedGrids} 个最远栅格，保留 ${totalRemainingGrids} 个栅格`);

        // 可视化优化后的栅格
        visualizeOptimizedGrids();

    } catch (error) {
        console.error('❌ 删除最远栅格失败:', error);
        updateStatus('error', `步骤10失败: ${error.message}`);
    }
}

/**
 * 步骤11: 合并成多个国家宣称
 * 将优化后的栅格合并成最终的国家宣称区域
 */
function step11_mergeCountryClaims() {
    console.log('1️⃣1️⃣ 开始合并成多个国家宣称...');
    updateStatus('info', '步骤11: 正在将优化后的栅格合并成最终国家宣称...');

    try {
        // 检查是否完成了步骤10
        if (!window.globalRasterState || window.globalRasterState.totalGrids === 0) {
            updateStatus('error', '请先执行步骤10: 删除最远栅格');
            return;
        }

        const rasterState = window.globalRasterState;
        const finalClaims = new Map();
        let totalMergedClaims = 0;

        // 为每个国家合并栅格成宣称区域
        for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
            console.log(`🏛️ 合并国家 "${countryName}" 的 ${countryGrids.length} 个栅格...`);

            if (countryGrids.length === 0) {
                console.log(`   国家 "${countryName}" 没有栅格，跳过`);
                continue;
            }

            // 将栅格转换为多边形并合并
            const mergedClaims = mergeGridsToPolygons(countryGrids, countryName);

            if (mergedClaims.length > 0) {
                finalClaims.set(countryName, mergedClaims);
                totalMergedClaims += mergedClaims.length;
                console.log(`   生成了 ${mergedClaims.length} 个合并后的宣称区域`);
            }
        }

        // 将合并后的宣称应用到宣称管理器
        applyFinalMergedClaimsToManager(finalClaims);

        console.log(`✅ 国家宣称合并完成！生成了 ${totalMergedClaims} 个最终宣称区域，覆盖 ${finalClaims.size} 个国家`);
        updateStatus('success', `步骤11完成: 生成 ${totalMergedClaims} 个最终宣称区域`);

        // 可视化最终宣称
        visualizeFinalMergedClaims();

    } catch (error) {
        console.error('❌ 合并国家宣称失败:', error);
        updateStatus('error', `步骤11失败: ${error.message}`);
    }
}

// 使用独立的 CountryColorManager 模块

/**
 * 步骤12: 应用国家颜色并显示最终宣称（直接实现版本）
 */
async function step12_applyColorsAndDisplay() {
    console.log('1️⃣2️⃣ 开始应用国家颜色并显示最终宣称（直接实现版本）...');
    updateStatus('info', '步骤12: 正在根据国家颜色显示最终宣称区域...');

    try {
        // 检查是否有最终宣称数据
        if (!countryClaimsManager || countryClaimsManager.generatedClaims.size === 0) {
            updateStatus('error', '请先完成步骤11: 合并国家宣称');
            return;
        }

        // 清除之前的显示图层
        clearAllHighlights();
        if (countryClaimsManager) {
            countryClaimsManager.clearDisplayedLayers();
        }

        // 初始化颜色管理器并预加载国家颜色
        window.CountryColorManager.clearAllColors();
        await window.CountryColorManager.initializeCountryColors();

        let totalDisplayedClaims = 0;
        let totalCountries = 0;

        console.log('🎨 开始直接显示带颜色的宣称区域...');

        // 直接显示带颜色的宣称区域
        for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
            if (!claimsResult.success || !claimsResult.claims) continue;

            console.log(`🎨 显示国家 "${countryName}" 的 ${claimsResult.claims.length} 个宣称区域...`);

            // 获取国家颜色
            const countryColor = window.CountryColorManager.getCountryColor(countryName);

            let countryClaimsDisplayed = 0;

            for (const claim of claimsResult.claims) {
                try {
                    // 使用countryClaimsManager的现有显示功能，但指定颜色
                    const displayOptions = {
                        color: countryColor,
                        fillColor: countryColor,
                        fillOpacity: 0.3,
                        weight: 3,
                        opacity: 0.8
                    };

                    // 调用countryClaimsManager的显示方法
                    const layers = countryClaimsManager.renderClaimBoundary(countryName, claim, displayOptions);

                    if (layers && layers.length > 0) {
                        countryClaimsDisplayed += layers.length;
                        totalDisplayedClaims += layers.length;

                        // 为每个图层添加颜色信息到弹窗
                        layers.forEach(layer => {
                            if (layer.getPopup) {
                                const originalContent = layer.getPopup().getContent();
                                const enhancedContent = originalContent.replace(
                                    '</div>',
                                    `<div style="color: ${countryColor}; font-weight: bold;">● 国家颜色: ${countryColor}</div></div>`
                                );
                                layer.getPopup().setContent(enhancedContent);
                            }
                        });

                        console.log(`     ✅ 显示宣称区域 ${claim.id}，颜色: ${countryColor}`);
                    }

                } catch (error) {
                    console.warn(`⚠️ 显示国家 "${countryName}" 宣称区域 ${claim.id} 失败:`, error);

                    // 回退到基本显示
                    try {
                        countryClaimsManager.renderClaimBoundary(countryName, claim);
                        countryClaimsDisplayed++;
                        totalDisplayedClaims++;
                    } catch (fallbackError) {
                        console.error(`❌ 回退显示也失败:`, fallbackError);
                    }
                }
            }

            if (countryClaimsDisplayed > 0) {
                totalCountries++;
                console.log(`   国家 "${countryName}" 显示了 ${countryClaimsDisplayed} 个宣称区域，颜色: ${countryColor}`);
            }
        }

        // 显示颜色分配统计
        console.log(`🎨 国家颜色分配统计:`);
        const colorMap = window.CountryColorManager.getAllCountryColors();
        for (const [country, color] of colorMap) {
            console.log(`   ${country}: ${color}`);
        }

        console.log(`✅ 国家颜色显示完成！显示了 ${totalDisplayedClaims} 个宣称区域，覆盖 ${totalCountries} 个国家`);
        updateStatus('success', `步骤12完成: 显示了 ${totalDisplayedClaims} 个带颜色的宣称区域`);

    } catch (error) {
        console.error('❌ 应用国家颜色失败:', error);
        updateStatus('error', `步骤12失败: ${error.message}`);
    }
}

/**
 * 应用颜色到现有图层
 */
async function applyColorsToExistingLayers() {
    console.log('🎨 开始应用颜色到现有图层...');

    // 初始化国家颜色
    await window.CountryColorManager.initializeCountryColors();

    try {
        // 获取所有地图图层
        map.eachLayer(function(layer) {
            // 检查是否是多边形图层且有弹窗
            if (layer instanceof L.Polygon && layer.getPopup) {
                const popup = layer.getPopup();
                if (popup && popup.getContent) {
                    const content = popup.getContent();

                    // 从弹窗内容中提取国家名称
                    const countryMatch = content.match(/国家:\s*([^<\n]+)/);
                    if (countryMatch) {
                        const countryName = countryMatch[1].trim();
                        const countryColor = window.CountryColorManager.getCountryColor(countryName);

                        // 应用颜色
                        layer.setStyle({
                            color: countryColor,
                            fillColor: countryColor,
                            fillOpacity: 0.3,
                            weight: 3,
                            opacity: 0.8
                        });

                        console.log(`   ✅ 为国家 "${countryName}" 应用颜色: ${countryColor}`);
                    }
                }
            }
        });

        console.log('✅ 颜色应用完成');

    } catch (error) {
        console.error('❌ 应用颜色到现有图层失败:', error);
    }
}

/**
 * 手动显示带颜色的宣称区域（备用方案）
 */
function manualDisplayWithColors() {
    console.log('🔄 开始手动显示带颜色的宣称区域...');

    try {
        // 这里可以实现手动显示逻辑
        // 暂时使用现有的显示功能
        if (countryClaimsManager) {
            countryClaimsManager.showCurrentGeneratedClaims();
        }

        // 显示颜色分配统计
        console.log(`🎨 国家颜色分配统计:`);
        const colorMap = window.CountryColorManager.getAllCountryColors();
        for (const [country, color] of colorMap) {
            console.log(`   ${country}: ${color}`);
        }

        // 自动调整视图以显示所有宣称区域
        if (window.finalClaimsLayers && window.finalClaimsLayers.length > 0) {
            try {
                const group = new L.featureGroup(window.finalClaimsLayers);
                map.fitBounds(group.getBounds(), { padding: [20, 20] });
            } catch (error) {
                console.warn('⚠️ 自动调整视图失败:', error);
            }
        }

        console.log(`✅ 国家宣称颜色显示完成！`);
        updateStatus('success', `手动显示完成`);

    } catch (error) {
        console.error('❌ 手动显示失败:', error);
        updateStatus('error', `手动显示失败: ${error.message}`);
    }
}

/**
 * 步骤13: 导出带颜色的GeoJSON（新增功能）
 */
async function step13_exportColoredGeoJSON() {
    console.log('1️⃣3️⃣ 开始导出带颜色的GeoJSON...');
    updateStatus('info', '步骤13: 正在导出带国家颜色的GeoJSON数据...');

    // 初始化国家颜色
    await window.CountryColorManager.initializeCountryColors();

    try {
        // 检查是否有最终宣称数据
        if (!countryClaimsManager || countryClaimsManager.generatedClaims.size === 0) {
            updateStatus('error', '请先完成步骤11: 合并国家宣称');
            return;
        }

        // 创建GeoJSON FeatureCollection
        const geoJSON = {
            type: "FeatureCollection",
            features: [],
            metadata: {
                generatedAt: new Date().toISOString(),
                totalCountries: countryClaimsManager.generatedClaims.size,
                source: "Dynmap Territory System - Advanced Raster Processing with Colors",
                version: "2.1.0",
                processSteps: "8-12步骤优化处理 + 国家颜色",
                colorPalette: window.CountryColorManager.colorPalette,
                countryColors: Object.fromEntries(window.CountryColorManager.getAllCountryColors())
            }
        };

        let totalFeatures = 0;

        // 为每个国家创建带颜色的GeoJSON Feature
        for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
            if (!claimsResult.success || !claimsResult.claims) continue;

            console.log(`📄 处理国家 "${countryName}" 的 ${claimsResult.claims.length} 个宣称区域...`);

            // 获取国家颜色
            const countryColor = window.CountryColorManager.getCountryColor(countryName);

            for (const claim of claimsResult.claims) {
                if (claim.boundary && claim.boundary.length >= 3) {
                    // 处理边界坐标
                    let coordinates = [];

                    if (Array.isArray(claim.boundary[0]) && Array.isArray(claim.boundary[0][0])) {
                        // 多环结构
                        coordinates = claim.boundary;
                    } else {
                        // 单环结构，确保闭合
                        coordinates = [...claim.boundary];
                        const firstPoint = coordinates[0];
                        const lastPoint = coordinates[coordinates.length - 1];

                        if (firstPoint[0] !== lastPoint[0] || firstPoint[1] !== lastPoint[1]) {
                            coordinates.push([firstPoint[0], firstPoint[1]]);
                        }
                        coordinates = [coordinates];
                    }

                    const feature = {
                        type: "Feature",
                        properties: {
                            country: countryName,
                            id: claim.id,
                            area: claim.area || 0,
                            boundaryType: claim.metadata?.boundaryType || 'raster-optimized',
                            processedAt: claim.metadata?.finalizedAt || new Date().toISOString(),
                            optimizationMethod: 'raster-distance-optimization',
                            // 新增颜色属性
                            color: countryColor,
                            fillColor: countryColor,
                            fillOpacity: 0.3,
                            weight: 3,
                            opacity: 0.8
                        },
                        geometry: {
                            type: "Polygon",
                            coordinates: coordinates
                        }
                    };

                    geoJSON.features.push(feature);
                    totalFeatures++;
                }
            }
        }

        // 下载GeoJSON文件
        const jsonString = JSON.stringify(geoJSON, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `country-claims-colored-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.geojson`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        console.log(`✅ 带颜色的GeoJSON导出完成！包含 ${totalFeatures} 个边界特征`);
        updateStatus('success', `步骤13完成: 已导出包含 ${totalFeatures} 个带颜色边界的GeoJSON文件`);

    } catch (error) {
        console.error('❌ 导出带颜色的GeoJSON失败:', error);
        updateStatus('error', `步骤13失败: ${error.message}`);
    }
}

/**
 * 智能检测坐标格式
 * @param {Array} coord - 坐标数组 [x, y]
 * @returns {boolean} true表示是地图坐标，false表示是MC坐标
 */
function isMapCoordinate(coord) {
    if (!Array.isArray(coord) || coord.length < 2) {
        return false;
    }

    const [x, y] = coord;

    // 地图坐标的特征：
    // - 通常是小数
    // - X坐标范围大约在 0 到 WORLD_HEIGHT (15999)
    // - Y坐标范围大约在 0 到 WORLD_WIDTH (18999)

    // MC坐标的特征：
    // - 可能是整数或小数
    // - X坐标范围在 MC_BOUNDS.minX (-10459) 到 MC_BOUNDS.maxX (8540)
    // - Z坐标范围在 MC_BOUNDS.minZ (-8384) 到 MC_BOUNDS.maxZ (7616)

    // 简单的启发式判断：
    // 如果坐标都是正数且在地图范围内，很可能是地图坐标
    if (x >= 0 && y >= 0 && x <= 16000 && y <= 19000) {
        return true;
    }

    // 如果坐标有负数且在MC范围内，很可能是MC坐标
    if (x >= -11000 && x <= 9000 && y >= -9000 && y <= 8000) {
        return false;
    }

    // 默认假设是MC坐标
    return false;
}

/**
 * 调试第12步骤的数据结构
 */
function debugStep12Data() {
    console.log('🔍 调试第12步骤的数据结构...');

    if (!countryClaimsManager || countryClaimsManager.generatedClaims.size === 0) {
        console.log('❌ 没有宣称数据');
        return;
    }

    console.log(`📊 宣称数据概览:`);
    console.log(`   国家数量: ${countryClaimsManager.generatedClaims.size}`);

    for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
        console.log(`\n🏛️ 国家 "${countryName}":`);
        console.log(`   success: ${claimsResult.success}`);
        console.log(`   claims数量: ${claimsResult.claims ? claimsResult.claims.length : 'null'}`);

        if (claimsResult.claims && claimsResult.claims.length > 0) {
            const firstClaim = claimsResult.claims[0];
            console.log(`   第一个宣称区域:`, {
                id: firstClaim.id,
                hasBoundary: !!firstClaim.boundary,
                boundaryType: Array.isArray(firstClaim.boundary) ? 'array' : typeof firstClaim.boundary,
                boundaryLength: Array.isArray(firstClaim.boundary) ? firstClaim.boundary.length : 'N/A'
            });

            if (firstClaim.boundary && Array.isArray(firstClaim.boundary) && firstClaim.boundary.length > 0) {
                const firstElement = firstClaim.boundary[0];
                console.log(`   第一个边界元素:`, {
                    type: Array.isArray(firstElement) ? 'array' : typeof firstElement,
                    length: Array.isArray(firstElement) ? firstElement.length : 'N/A',
                    value: firstElement
                });

                if (Array.isArray(firstElement) && firstElement.length > 0) {
                    const firstCoord = firstElement[0];
                    console.log(`   第一个坐标:`, {
                        type: Array.isArray(firstCoord) ? 'array' : typeof firstCoord,
                        length: Array.isArray(firstCoord) ? firstCoord.length : 'N/A',
                        value: firstCoord
                    });
                }
            }
        }
    }
}

/**
 * 清除所有高亮显示
 */
function clearAllHighlights() {
    // 清除最终宣称图层
    if (window.finalClaimsLayers) {
        window.finalClaimsLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除最终宣称图层时出错:', e);
            }
        });
        window.finalClaimsLayers = [];
    }

    // 清除其他可能的图层
    if (window.allCountryGridLayers) {
        window.allCountryGridLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
    }

    console.log('🧹 已清除所有高亮显示');
}

/**
 * 可视化所有国家的栅格
 */
async function visualizeAllCountryGrids() {
    console.log('🎨 开始可视化所有国家的栅格...');

    // 初始化国家颜色
    await window.CountryColorManager.initializeCountryColors();

    // 清除之前的栅格图层
    if (window.allCountryGridLayers) {
        window.allCountryGridLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
    }
    window.allCountryGridLayers = [];

    if (!window.globalRasterState || window.globalRasterState.totalGrids === 0) {
        console.warn('⚠️ 没有栅格数据可视化');
        return;
    }

    const rasterState = window.globalRasterState;
    let visualizedCount = 0;

    for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
        // 使用 CountryColorManager 获取国家颜色
        const color = window.CountryColorManager.getCountryColor(countryName);

        console.log(`   可视化国家 "${countryName}" 的 ${countryGrids.length} 个栅格，颜色: ${color}`);

        for (const grid of countryGrids) {
            try {
                const [minX, minY, maxX, maxY] = grid.bounds;

                // 转换为地图坐标
                const mapCoords = [
                    mcToMapCoords(minX, minY),
                    mcToMapCoords(maxX, minY),
                    mcToMapCoords(maxX, maxY),
                    mcToMapCoords(minX, maxY)
                ];

                const rectangle = L.polygon(mapCoords, {
                    color: color,
                    fillColor: color,
                    fillOpacity: 0.3,
                    weight: 1,
                    opacity: 0.8
                });

                // 添加弹出信息
                const popupContent = `
                    <div style="font-size: 12px;">
                        <h4 style="margin: 0 0 8px 0; color: ${color};">🔲 栅格单元</h4>
                        <div><strong>国家:</strong> ${countryName}</div>
                        <div><strong>栅格ID:</strong> ${grid.id}</div>
                        <div><strong>中心坐标:</strong> (${Math.round(grid.centerX)}, ${Math.round(grid.centerY)})</div>
                        <div><strong>面积:</strong> ${Math.round(grid.area).toLocaleString()} 平方方块</div>
                        ${grid.distanceToNearestSpawn ? `<div><strong>到最近出生点距离:</strong> ${Math.round(grid.distanceToNearestSpawn)} 方块</div>` : ''}
                        ${grid.nearestSpawnPoint ? `<div><strong>最近出生点:</strong> (${grid.nearestSpawnPoint.x}, ${grid.nearestSpawnPoint.z})</div>` : ''}
                    </div>
                `;

                rectangle.bindPopup(popupContent);
                rectangle.addTo(map);
                window.allCountryGridLayers.push(rectangle);
                visualizedCount++;

            } catch (error) {
                console.error(`❌ 可视化栅格 ${grid.id} 失败:`, error);
            }
        }
    }

    console.log(`✅ 栅格可视化完成: ${visualizedCount}/${rasterState.totalGrids} 个栅格已显示`);
}

/**
 * 可视化带距离信息的栅格
 */
async function visualizeGridsWithDistances() {
    console.log('🎨 开始可视化带距离信息的栅格...');

    // 初始化国家颜色
    await window.CountryColorManager.initializeCountryColors();

    // 清除之前的图层
    if (window.allCountryGridLayers) {
        window.allCountryGridLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除栅格图层时出错:', e);
            }
        });
    }
    window.allCountryGridLayers = [];

    if (!window.globalRasterState || window.globalRasterState.totalGrids === 0) {
        console.warn('⚠️ 没有栅格数据可视化');
        return;
    }

    const rasterState = window.globalRasterState;
    let visualizedCount = 0;

    for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
        // 使用 CountryColorManager 获取国家颜色
        const baseColor = window.CountryColorManager.getCountryColor(countryName);

        // 计算该国家栅格的距离范围
        const distances = countryGrids.map(g => g.distanceToNearestSpawn).filter(d => d !== null);
        const minDistance = Math.min(...distances);
        const maxDistance = Math.max(...distances);
        const distanceRange = maxDistance - minDistance;

        console.log(`   可视化国家 "${countryName}" 的 ${countryGrids.length} 个栅格，距离范围: ${Math.round(minDistance)} ~ ${Math.round(maxDistance)} 方块`);

        for (const grid of countryGrids) {
            try {
                const [minX, minY, maxX, maxY] = grid.bounds;

                // 转换为地图坐标
                const mapCoords = [
                    mcToMapCoords(minX, minY),
                    mcToMapCoords(maxX, minY),
                    mcToMapCoords(maxX, maxY),
                    mcToMapCoords(minX, maxY)
                ];

                // 根据距离计算透明度（距离越近，透明度越高）
                let fillOpacity = 0.3;
                if (grid.distanceToNearestSpawn !== null && distanceRange > 0) {
                    const normalizedDistance = (grid.distanceToNearestSpawn - minDistance) / distanceRange;
                    fillOpacity = 0.7 - (normalizedDistance * 0.5); // 0.7 到 0.2
                }

                const rectangle = L.polygon(mapCoords, {
                    color: baseColor,
                    fillColor: baseColor,
                    fillOpacity: fillOpacity,
                    weight: 1,
                    opacity: 0.8
                });

                // 添加弹出信息，重点显示距离
                const popupContent = `
                    <div style="font-size: 12px;">
                        <h4 style="margin: 0 0 8px 0; color: ${baseColor};">📏 栅格距离信息</h4>
                        <div><strong>国家:</strong> ${countryName}</div>
                        <div><strong>栅格ID:</strong> ${grid.id}</div>
                        <div><strong>中心坐标:</strong> (${Math.round(grid.centerX)}, ${Math.round(grid.centerY)})</div>
                        <div style="background-color: #f0f8ff; padding: 4px; border-radius: 3px; margin: 4px 0;">
                            <strong style="color: #0066cc;">到最近出生点距离: ${Math.round(grid.distanceToNearestSpawn || 0)} 方块</strong>
                        </div>
                        ${grid.nearestSpawnPoint ? `<div><strong>最近出生点:</strong> (${grid.nearestSpawnPoint.x}, ${grid.nearestSpawnPoint.z})</div>` : ''}
                        ${grid.nearestSpawnPoint?.territoryName ? `<div><strong>出生点领地:</strong> ${grid.nearestSpawnPoint.territoryName}</div>` : ''}
                        <div><strong>面积:</strong> ${Math.round(grid.area).toLocaleString()} 平方方块</div>
                    </div>
                `;

                rectangle.bindPopup(popupContent);
                rectangle.addTo(map);
                window.allCountryGridLayers.push(rectangle);
                visualizedCount++;

            } catch (error) {
                console.error(`❌ 可视化栅格 ${grid.id} 失败:`, error);
            }
        }
    }

    console.log(`✅ 带距离信息的栅格可视化完成: ${visualizedCount}/${rasterState.totalGrids} 个栅格已显示`);
}

/**
 * 可视化优化后的栅格（删除最远10%后）
 */
function visualizeOptimizedGrids() {
    console.log('🎨 开始可视化优化后的栅格...');

    // 重用带距离信息的可视化，但添加优化标识
    visualizeGridsWithDistances();

    if (window.globalRasterState) {
        const rasterState = window.globalRasterState;
        console.log(`📊 优化后栅格统计:`);

        for (const [countryName, countryGrids] of rasterState.allCountryGrids) {
            const distances = countryGrids.map(g => g.distanceToNearestSpawn).filter(d => d !== null);
            if (distances.length > 0) {
                const avgDistance = distances.reduce((a, b) => a + b, 0) / distances.length;
                console.log(`   ${countryName}: ${countryGrids.length} 个栅格，平均距离: ${Math.round(avgDistance)} 方块`);
            }
        }
    }
}

/**
 * 将栅格合并为多边形
 * @param {Array} grids - 栅格数组
 * @param {string} countryName - 国家名称
 * @returns {Array} 合并后的宣称区域数组
 */
function mergeGridsToPolygons(grids, countryName) {
    console.log(`🔗 开始合并国家 "${countryName}" 的 ${grids.length} 个栅格...`);

    if (grids.length === 0) {
        return [];
    }

    try {
        // 将所有栅格转换为Turf多边形
        const gridPolygons = grids.map(grid => {
            const [minX, minY, maxX, maxY] = grid.bounds;
            return turf.polygon([[
                [minX, minY],
                [maxX, minY],
                [maxX, maxY],
                [minX, maxY],
                [minX, minY]
            ]]);
        });

        // 合并所有多边形
        let mergedPolygon = gridPolygons[0];

        for (let i = 1; i < gridPolygons.length; i++) {
            try {
                const union = turf.union(mergedPolygon, gridPolygons[i]);
                if (union && union.geometry) {
                    mergedPolygon = union;
                }
            } catch (unionError) {
                console.warn(`⚠️ 合并栅格 ${i} 失败:`, unionError.message);
            }
        }

        // 处理合并结果
        const mergedClaims = [];

        if (mergedPolygon && mergedPolygon.geometry) {
            if (mergedPolygon.geometry.type === 'Polygon') {
                // 单个多边形
                const claim = createClaimFromPolygon(mergedPolygon, countryName, 0);
                if (claim) {
                    mergedClaims.push(claim);
                }
            } else if (mergedPolygon.geometry.type === 'MultiPolygon') {
                // 多个多边形
                mergedPolygon.geometry.coordinates.forEach((polygonCoords, index) => {
                    const singlePolygon = turf.polygon(polygonCoords);
                    const claim = createClaimFromPolygon(singlePolygon, countryName, index);
                    if (claim) {
                        mergedClaims.push(claim);
                    }
                });
            }
        }

        console.log(`   合并完成，生成了 ${mergedClaims.length} 个宣称区域`);
        return mergedClaims;

    } catch (error) {
        console.error(`❌ 合并栅格失败:`, error);
        return [];
    }
}

/**
 * 从Turf多边形创建宣称区域对象
 * @param {Object} turfPolygon - Turf多边形
 * @param {string} countryName - 国家名称
 * @param {number} index - 索引
 * @returns {Object|null} 宣称区域对象
 */
function createClaimFromPolygon(turfPolygon, countryName, index) {
    try {
        const area = turf.area(turfPolygon);

        if (area < 1000) { // 忽略面积太小的区域
            return null;
        }

        // 转换为MC坐标
        const mcBoundary = convertTurfPolygonToMCCoords(turfPolygon);
        if (!mcBoundary || mcBoundary.length < 3) {
            return null;
        }

        // 转换为地图坐标用于显示
        const mapBoundary = mcBoundary.map(coord => mcToMapCoords(coord[0], coord[1]));

        return {
            id: `${countryName}_raster_merged_${index}`,
            boundary: [mapBoundary], // 多环结构
            area: area,
            metadata: {
                boundaryType: 'raster-merged',
                generatedAt: new Date().toISOString(),
                optimizationMethod: 'raster-distance-optimization',
                originalGridCount: 'merged-from-grids'
            },
            spawnPoints: [] // 可以后续添加
        };

    } catch (error) {
        console.error(`❌ 创建宣称区域失败:`, error);
        return null;
    }
}

/**
 * 将最终合并的宣称应用到宣称管理器
 * @param {Map} finalClaims - 最终宣称映射
 */
function applyFinalMergedClaimsToManager(finalClaims) {
    console.log('🔄 将最终合并的宣称应用到宣称管理器...');

    try {
        // 清空当前的生成宣称
        countryClaimsManager.generatedClaims.clear();

        // 应用新的宣称
        for (const [countryName, claims] of finalClaims) {
            const claimsResult = {
                success: true,
                claims: claims,
                metadata: {
                    type: 'raster-optimized',
                    generatedAt: new Date().toISOString(),
                    optimizationSteps: '8-11',
                    totalClaims: claims.length
                }
            };

            countryClaimsManager.generatedClaims.set(countryName, claimsResult);
            console.log(`   应用国家 "${countryName}" 的 ${claims.length} 个宣称区域`);
        }

        console.log(`✅ 最终宣称应用完成，共 ${finalClaims.size} 个国家`);

    } catch (error) {
        console.error('❌ 应用最终宣称失败:', error);
    }
}

/**
 * 可视化最终合并的宣称
 */
function visualizeFinalMergedClaims() {
    console.log('🎨 开始可视化最终合并的宣称...');

    // 清除之前的图层
    if (window.allCountryGridLayers) {
        window.allCountryGridLayers.forEach(layer => {
            try {
                map.removeLayer(layer);
            } catch (e) {
                console.warn('清除图层时出错:', e);
            }
        });
        window.allCountryGridLayers = [];
    }

    // 使用宣称管理器显示最终结果
    if (countryClaimsManager) {
        countryClaimsManager.clearDisplayedLayers();
        setTimeout(() => {
            countryClaimsManager.showCurrentGeneratedClaims();
        }, 500);
    }
}

// 导出函数到全局作用域（确保在浏览器环境中可用）
if (typeof window !== 'undefined') {
    // 浏览器环境：将函数添加到全局作用域
    window.step1_buildClaimBlocks = step1_buildClaimBlocks;
    window.step2_detectConflictAreas = step2_detectConflictAreas;
    window.step3_removeConflictAreas = step3_removeConflictAreas;
    window.step4_rasterizeConflictAreas = step4_rasterizeConflictAreas;
    window.step5_assignOwnership = step5_assignOwnership;
    window.step6_mergeOwnershipAreas = step6_mergeOwnershipAreas;
    window.step7_outputFinalBoundaries = step7_outputFinalBoundaries;
    window.step8_rasterizeAllClaims = step8_rasterizeAllClaims;
    window.step9_detectNearestSpawnPoints = step9_detectNearestSpawnPoints;
    window.step10_removeFarthestGrids = step10_removeFarthestGrids;
    window.step11_mergeCountryClaims = step11_mergeCountryClaims;
    window.step12_applyColorsAndDisplay = step12_applyColorsAndDisplay;
    window.step13_exportColoredGeoJSON = step13_exportColoredGeoJSON;
    window.clearAllHighlights = clearAllHighlights;
    window.checkAdvancedProcessStatus = checkAdvancedProcessStatus;
    window.debugGeneratedClaimsStructure = debugGeneratedClaimsStructure;
    window.viewStoredConflictResolvedBoundaries = viewStoredConflictResolvedBoundaries;

    console.log('✅ 高级冲突处理模块已加载到全局作用域');
}

// Node.js环境导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        step1_buildClaimBlocks,
        step2_detectConflictAreas,
        step3_removeConflictAreas,
        step4_rasterizeConflictAreas,
        step5_assignOwnership,
        step6_mergeOwnershipAreas,
        step7_outputFinalBoundaries,
        step8_rasterizeAllClaims,
        step9_detectNearestSpawnPoints,
        step10_removeFarthestGrids,
        step11_mergeCountryClaims,
        step12_applyColorsAndDisplay,
        step13_exportColoredGeoJSON,
        // CountryColorManager 已移至独立模块,
        createValidTurfPolygon,
        visualizeConflictAreas,
        convertGeoJSONToLeafletCoords,
        convertTurfPolygonToMCCoords,
        visualizeCleanedClaimBlocks,
        visualizeGridCells,
        visualizeAssignments,
        applyMergedClaimBlocksToClaimsManager,
        displayFinalStatistics,
        clearAllHighlights,
        checkAdvancedProcessStatus,
        debugGeneratedClaimsStructure,
        viewStoredConflictResolvedBoundaries,
        debugNewConflictDetection,
        detectSpatialOverlaps,
        calculateMultiPolygonIntersection,
        determineConflictOwnership,
        findAllOverlapRegions,
        mergeIntersectionRegions,
        verifyConflictRemoval,
        debugConflictGeometry,
        generateGridsForClaim,
        calculateDistance,
        extractSpawnPointsFromTerritories,
        visualizeAllCountryGrids,
        visualizeGridsWithDistances,
        visualizeOptimizedGrids,
        mergeGridsToPolygons,
        createClaimFromPolygon,
        applyFinalMergedClaimsToManager,
        visualizeFinalMergedClaims,
        verifyStep8Fix,
        debugSpawnPointsStructure,
        debugStep12Data,
        isMapCoordinate,
        applyColorsToExistingLayers,
        manualDisplayWithColors
    };
}
