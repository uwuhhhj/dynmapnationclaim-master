/**
 * 国家边界和宣称管理模块
 * 负责国家宣称数据的生成、优化和边界冲突处理
 */

/**
 * 内部使用的加载国家数据函数（保留自动加载功能）
 */
async function loadCountryDataInternal() {
    if (countryClaimsManager) {
        const success = await countryClaimsManager.loadCountryData();
        if (success) {
            updateStatistics();
        }
    }
}

/**
 * 显示选中国家的边界
 */
function showSelectedCountryBoundary() {
    if (countryClaimsManager) {
        countryClaimsManager.showSelectedCountryBoundary();
    }
}

/**
 * 生成并存储所有国家宣称数据
 */
async function generateAndStoreAllCountryClaims() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return { success: false, error: '管理器未初始化' };
    }

    try {
        updateStatus('info', '正在检查数据状态...');

        // 检查是否已有国家数据
        const countrySpawn = await getStoredCountrySpawn();
        const countryAreas = await getStoredCountryAreas();

        if (!countrySpawn && !countryAreas) {
            updateStatus('info', '未找到国家数据，正在加载领地数据...');

            // 先加载领地数据
            await loadTerritoryData();

            // 等待一下让数据处理完成
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        // 确保国家宣称管理器已加载国家数据
        const loadSuccess = await countryClaimsManager.loadCountryData();
        if (!loadSuccess) {
            updateStatus('error', '无法加载国家数据，请先确保已成功加载领地数据');
            return { success: false, error: '无法加载国家数据' };
        }

        // 检查 Turf.js 是否可用
        if (typeof turf === 'undefined') {
            updateStatus('error', 'Turf.js 库未加载，无法进行几何处理');
            return { success: false, error: 'Turf.js 库未加载' };
        }

        // 使用新的基于 Turf.js 的生成方法
        const result = await countryClaimsManager.generateAndStoreAllCountryClaims();
        updateStatistics();
        return result;

    } catch (error) {
        console.error('❌ 生成宣称数据时发生错误:', error);
        updateStatus('error', `生成失败: ${error.message}`);
        return { success: false, error: error.message };
    }
}



/**
 * 显示所有国家边界（从存储数据中读取）
 */
function showAllCountryBoundaries() {
    if (countryClaimsManager) {
        countryClaimsManager.showAllCountryBoundaries();
        updateStatistics();
        // 更新显示控制开关状态
        if (typeof updateToggleStates === 'function') {
            setTimeout(updateToggleStates, 100);
        }
    }
}

/**
 * 清除所有国家边界显示
 */
function clearCountryBoundaries() {
    if (countryClaimsManager) {
        countryClaimsManager.clearCountryBoundaries();
        updateStatistics();
        // 更新显示控制开关状态
        if (typeof updateToggleStates === 'function') {
            setTimeout(updateToggleStates, 100);
        }
    }
}

/**
 * 检测边界冲突
 */
function detectBoundaryConflicts() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    updateStatus('info', '正在检测边界冲突...');

    const result = countryClaimsManager.detectBoundaryConflicts();

    if (result.success) {
        const conflictCount = result.conflicts.length;
        const affectedCountries = result.statistics ? result.statistics.affectedCountries : 0;

        if (conflictCount === 0) {
            updateStatus('success', '未检测到边界冲突');
        } else {
            updateStatus('warning', `检测到 ${conflictCount} 个边界冲突，涉及 ${affectedCountries} 个国家`);

            // 在控制台显示详细冲突信息
            console.log('🔍 边界冲突详情:', result.conflicts);

            // 根据配置决定是否高亮显示冲突区域
            const config = getOptimizationConfig();
            if (config.showConflictAreas) {
                highlightConflictAreas(result.conflicts);
            }
        }
    } else {
        updateStatus('error', `冲突检测失败: ${result.error}`);
    }
}

/**
 * 优化边界重叠
 */
async function optimizeBoundaryOverlaps() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    updateStatus('info', '正在优化边界重叠，请稍候...');

    try {
        const config = getOptimizationConfig();
        // 强制启用调试模式以便查看详细处理过程
        config.debug = true;

        console.log('🚀 开始边界重叠优化，配置:', config);
        const result = await countryClaimsManager.optimizeBoundaryOverlaps(config);

        if (result.success) {
            const stats = result.result.statistics;
            updateStatus('success',
                `边界优化完成！解决了 ${stats.resolvedConflicts} 个冲突，` +
                `影响 ${stats.affectedCountries} 个国家`
            );

            // 显示优化报告
            console.log('📊 优化报告:', result.report);
            console.log('🔍 验证结果:', result.validation);

            // 强制刷新地图显示优化后的边界
            console.log('🔄 强制刷新地图显示优化后的边界...');

            // 等待一小段时间确保数据更新完成
            setTimeout(async () => {
                const refreshResult = countryClaimsManager.showCurrentGeneratedClaims();
                if (refreshResult.success) {
                    console.log('✅ 优化后的边界显示成功');

                    // 自动保存冲突修复后的边界数据
                    try {
                        await saveConflictResolvedBoundaries();
                        updateStatus('success', `优化完成并已刷新显示 (${refreshResult.successCount} 个国家)，数据已自动保存`);
                    } catch (error) {
                        console.error('❌ 自动保存冲突修复数据失败:', error);
                        updateStatus('success', `优化完成并已刷新显示 (${refreshResult.successCount} 个国家)，但自动保存失败`);
                    }
                } else {
                    console.error('❌ 优化后的边界显示失败:', refreshResult.error);
                    updateStatus('warning', '优化完成但显示刷新失败，请手动点击"显示当前数据"');
                }
            }, 500);

        } else {
            updateStatus('error', `边界优化失败: ${result.error}`);
        }

    } catch (error) {
        console.error('❌ 边界优化过程出错:', error);
        updateStatus('error', `优化过程出错: ${error.message}`);
    }
}

/**
 * 手动保存当前显示的所有国家宣称数据
 */
async function saveAllDisplayedCountryClaims() {
    if (countryClaimsManager) {
        const result = await countryClaimsManager.saveAllDisplayedClaimsToLocalStorage();

        if (result.success) {
            console.log('💾 手动保存成功:', result);
        } else {
            console.error('❌ 手动保存失败:', result.error);
        }

        return result;
    } else {
        updateStatus('error', '国家宣称管理器未初始化');
        return { success: false, error: '管理器未初始化' };
    }
}



/**
 * 显示当前内存中的宣称数据
 */
function showCurrentClaims() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    updateStatus('info', '正在显示当前内存中的宣称数据...');
    const result = countryClaimsManager.showCurrentGeneratedClaims();

    if (result.success) {
        updateStatus('success', `成功显示 ${result.successCount} 个国家的宣称范围`);
    } else {
        updateStatus('error', `显示失败: ${result.error}`);
    }
}

/**
 * 保存优化后的宣称数据
 */
function saveOptimizedClaims() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    updateStatus('info', '正在保存优化后的数据...');

    const saveAsFile = confirm('是否同时导出为JSON文件？\n点击"确定"导出文件，点击"取消"仅保存到浏览器存储。');

    const result = countryClaimsManager.saveOptimizedClaims({
        saveAsFile: saveAsFile
    });

    if (result.success) {
        if (saveAsFile) {
            updateStatus('success', '优化数据已保存并导出为文件');
        } else {
            updateStatus('success', '优化数据已保存到浏览器存储');
        }
    } else {
        updateStatus('error', `保存失败: ${result.error}`);
    }
}

/**
 * 查看存储的冲突修复边界数据
 */
async function viewStoredConflictResolvedBoundaries() {
    try {
        const conflictResolvedData = await getStoredConflictResolvedBoundaries();

        if (!conflictResolvedData) {
            updateStatus('warning', '暂无存储的冲突修复边界数据');
            return;
        }

        const countryKeys = Object.keys(conflictResolvedData);
        const totalRegions = Object.values(conflictResolvedData).reduce((sum, claims) => sum + claims.length, 0);

        console.log('📋 存储的冲突修复边界数据:', conflictResolvedData);

        // 显示详细信息
        let detailInfo = `📋 冲突修复边界数据详情:\n`;
        detailInfo += `${'='.repeat(40)}\n`;
        detailInfo += `总国家数: ${countryKeys.length}\n`;
        detailInfo += `总修复区域数: ${totalRegions}\n\n`;

        for (const [countryKey, claims] of Object.entries(conflictResolvedData)) {
            const countryName = countryKey.replace('_冲突修复', '');
            detailInfo += `🏛️ ${countryName} (${claims.length} 个修复区域):\n`;

            claims.forEach((claim, index) => {
                detailInfo += `  区域 ${claim.regionIndex}: `;
                detailInfo += `边界顶点[${claim.boundary.length}个]\n`;
                detailInfo += `    面积: ${Math.round(claim.area).toLocaleString()}\n`;
                detailInfo += `    边界类型: ${claim.metadata.boundaryType}\n`;
                detailInfo += `    修复时间: ${claim.metadata.resolvedAt}\n`;
            });
            detailInfo += '\n';
        }

        console.log(detailInfo);
        updateStatus('success', `已显示 ${countryKeys.length} 个国家的冲突修复边界数据 (共 ${totalRegions} 个区域)`);

        // 可选：在控制台中显示原始数据结构示例
        if (countryKeys.length > 0) {
            const firstCountryKey = countryKeys[0];
            console.log(`📝 数据结构示例 (${firstCountryKey}):`, conflictResolvedData[firstCountryKey]);
        }

    } catch (error) {
        console.error('❌ 查看冲突修复边界数据失败:', error);
        updateStatus('error', `查看失败: ${error.message}`);
    }
}

/**
 * 保存冲突修复后的边界数据
 */
async function saveConflictResolvedBoundaries() {
    if (!countryClaimsManager) {
        throw new Error('国家宣称管理器未初始化');
    }

    try {
        console.log('💾 开始保存冲突修复边界数据...');

        // 收集当前内存中的优化后宣称数据
        const conflictResolvedData = {};

        for (const [countryName, claimsResult] of countryClaimsManager.generatedClaims) {
            if (claimsResult && claimsResult.success && claimsResult.claims) {
                // 只保存已优化的宣称数据
                const optimizedClaims = claimsResult.claims.filter(claim =>
                    claim.metadata?.boundaryType === 'optimized' ||
                    claim.metadata?.optimizedAt
                );

                if (optimizedClaims.length > 0) {
                    const countryKey = `${countryName}_冲突修复`;
                    conflictResolvedData[countryKey] = optimizedClaims.map((claim, index) => ({
                        regionIndex: index,
                        boundary: claim.boundary,
                        area: claim.metadata?.area || claim.area || 0,
                        metadata: {
                            ...claim.metadata,
                            boundaryType: 'conflict-resolved',
                            resolvedAt: new Date().toISOString(),
                            originalClaimId: claim.id
                        }
                    }));
                }
            }
        }

        const totalCountries = Object.keys(conflictResolvedData).length;
        const totalRegions = Object.values(conflictResolvedData).reduce((sum, claims) => sum + claims.length, 0);

        console.log(`💾 准备保存 ${totalCountries} 个国家的 ${totalRegions} 个冲突修复区域`);

        // 保存到IndexedDB
        if (typeof setStoredConflictResolvedBoundaries === 'function') {
            await setStoredConflictResolvedBoundaries(conflictResolvedData);
            console.log('✅ 冲突修复边界数据已保存到IndexedDB');

            return {
                success: true,
                totalCountries,
                totalRegions,
                countries: Object.keys(conflictResolvedData)
            };
        } else {
            throw new Error('setStoredConflictResolvedBoundaries 函数不存在');
        }

    } catch (error) {
        console.error('❌ 保存冲突修复边界数据失败:', error);
        throw error;
    }
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        loadCountryDataInternal,
        showSelectedCountryBoundary,
        generateAndStoreAllCountryClaims,
        clearStoredCountryClaims,
        showAllCountryBoundaries,
        clearCountryBoundaries,
        detectBoundaryConflicts,
        optimizeBoundaryOverlaps,
        saveAllDisplayedCountryClaims,
        viewStoredCountryClaims,
        showCurrentClaims,
        saveOptimizedClaims,
        viewStoredConflictResolvedBoundaries,
        saveConflictResolvedBoundaries
    };
}
