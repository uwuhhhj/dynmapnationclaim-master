/**
 * 步骤执行模块
 * 包含主流程的6个步骤执行函数和相关的管理函数
 */

/**
 * 执行步骤1: 获取原始领地数据
 */
async function executeStep1() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(1, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step1_loadOriginalTerritories();
        console.log('步骤1执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤1完成: 已获取 ${result.countriesCount} 个国家的原始领地数据`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(1, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤1失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(1, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤1失败:', error);
        updateStatus('error', `步骤1执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(1, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行步骤2: 为每个国家的每个领地区域分别创建方形缓冲区
 */
async function executeStep2() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(2, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step2_bufferTerritories();
        console.log('步骤2执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤2完成: ${result.successCount} 个国家缓冲成功${result.failureCount > 0 ? `，${result.failureCount} 个失败` : ''}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(2, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤2失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(2, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤2失败:', error);
        updateStatus('error', `步骤2执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(2, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行步骤3: 合并每个国家的缓冲领地
 */
async function executeStep3() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(3, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step3_mergeCountryTerritories();
        console.log('步骤3执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤3完成: ${result.successCount} 个国家合并成功${result.failureCount > 0 ? `，${result.failureCount} 个失败` : ''}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(3, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤3失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(3, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤3失败:', error);
        updateStatus('error', `步骤3执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(3, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行步骤4: 处理合并结果的多个区域
 */
async function executeStep4() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(4, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step4_handleMultipleRegions();
        console.log('步骤4执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤4完成: ${result.successCount} 个国家处理成功，共 ${result.totalRegions} 个区域${result.failureCount > 0 ? `，${result.failureCount} 个失败` : ''}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(4, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤4失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(4, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤4失败:', error);
        updateStatus('error', `步骤4执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(4, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行步骤5: 计算面积、生成ID、转换格式
 */
async function executeStep5() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(5, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step5_calculateAndFormat();
        console.log('步骤5执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤5完成: ${result.successCount} 个国家格式化成功，共 ${result.totalClaims} 个宣称区域${result.failureCount > 0 ? `，${result.failureCount} 个失败` : ''}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(5, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤5失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(5, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤5失败:', error);
        updateStatus('error', `步骤5执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(5, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行步骤6: 存入generatedClaims
 */
async function executeStep6() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        // 更新按钮状态为执行中
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(6, '🔄 执行中...', 'executing');
        }

        const result = await countryClaimsManager.step6_storeResults();
        console.log('步骤6执行结果:', result);

        if (result.success) {
            updateStatus('success', `步骤6完成: ${result.successCount} 个国家存储成功，共 ${result.totalClaims} 个宣称区域${result.failureCount > 0 ? `，${result.failureCount} 个失败` : ''}`);
            updateStatistics(); // 更新统计信息
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(6, '✅ 已完成', 'completed');
            }
        } else {
            updateStatus('error', `步骤6失败: ${result.error}`);
            if (typeof updateStepStatus === 'function') {
                updateStepStatus(6, '❌ 失败', 'error');
            }
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行步骤6失败:', error);
        updateStatus('error', `步骤6执行失败: ${error.message}`);
        if (typeof updateStepStatus === 'function') {
            updateStepStatus(6, '❌ 失败', 'error');
        }
    }
}

/**
 * 执行所有步骤
 */
async function executeAllSteps() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        updateStatus('info', '开始执行所有步骤...');
        const result = await countryClaimsManager.executeAllSteps();
        console.log('所有步骤执行结果:', result);

        if (result.success) {
            updateStatus('success', `所有步骤执行完成！共生成 ${result.totalClaims} 个宣称区域`);
            updateStatistics(); // 更新统计信息
        } else {
            updateStatus('error', `执行失败，在步骤 ${result.failedAt || '未知'} 处停止: ${result.error || '未知错误'}`);
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('执行所有步骤失败:', error);
        updateStatus('error', `执行失败: ${error.message}`);
    }
}

/**
 * 重置步骤数据
 */
function resetStepData() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        countryClaimsManager.resetStepData();
        updateStatus('info', '步骤数据已重置');
        console.log('步骤数据重置完成');

        // 重置所有按钮状态
        if (typeof resetAllStepStatus === 'function') {
            resetAllStepStatus();
        }

        // 更新状态显示
        updateStepStatusDisplay();
    } catch (error) {
        console.error('重置步骤数据失败:', error);
        updateStatus('error', `重置失败: ${error.message}`);
    }
}

/**
 * 更新步骤状态显示
 */
function updateStepStatusDisplay() {
    if (!countryClaimsManager) {
        console.warn('国家宣称管理器未初始化');
        return;
    }

    try {
        const status = countryClaimsManager.getStepStatus();

        // 更新每个步骤的状态显示
        for (let step = 1; step <= 6; step++) {
            const stepElement = document.querySelector(`[data-step="${step}"]`);
            if (stepElement) {
                const stepStatus = status.stepStatus[step]; // 使用对象属性访问而不是Map.get()
                if (stepStatus && stepStatus.success) {
                    stepElement.textContent = '✅ 已完成';
                    stepElement.className = 'step-status step-completed';
                } else {
                    stepElement.textContent = '⏳ 待执行';
                    stepElement.className = 'step-status step-pending';
                }
            }
        }

        console.log('步骤状态显示已更新');
    } catch (error) {
        console.error('更新步骤状态显示失败:', error);
    }
}

/**
 * 清除所有步骤的渲染图层
 */
function clearStepRenders() {
    if (!countryClaimsManager) {
        updateStatus('error', '国家宣称管理器未初始化');
        return;
    }

    try {
        countryClaimsManager.clearAllStepRenderLayers();
        updateStatus('info', '已清除所有步骤的渲染图层');
        console.log('所有步骤渲染图层已清除');
    } catch (error) {
        console.error('清除步骤渲染失败:', error);
        updateStatus('error', `清除渲染失败: ${error.message}`);
    }
}



/**
 * 测试IndexedDB存储功能
 */
async function testIndexedDBStorage() {
    console.log('🧪 开始测试 IndexedDB 存储功能...');

    try {
        // 测试数据
        const testData = {
            "测试国家": [
                {
                    id: "test_claim_1",
                    regionIndex: 1,
                    rings: [{
                        xCoords: [0, 100, 100, 0],
                        zCoords: [0, 0, 100, 100]
                    }],
                    area: 10000,
                    metadata: {
                        generatedAt: new Date().toISOString(),
                        bufferDistance: 80,
                        blockType: "test"
                    }
                }
            ]
        };

        // 测试保存
        console.log('🔄 测试保存数据...');
        console.log('🔍 检查函数可用性:', {
            setStoredCountryClaims: typeof setStoredCountryClaims,
            getStoredCountryClaims: typeof getStoredCountryClaims
        });

        if (typeof setStoredCountryClaims === 'function') {
            await setStoredCountryClaims(testData);
            console.log('✅ 测试数据保存成功');

            // 测试读取
            console.log('🔄 测试读取数据...');
            const retrievedData = await getStoredCountryClaims();
            console.log('📋 读取的数据:', retrievedData);

            if (retrievedData && retrievedData["测试国家"]) {
                console.log('✅ IndexedDB 存储功能正常');
                updateStatus('success', 'IndexedDB 存储功能测试通过');

                // 清理测试数据
                const cleanData = { ...retrievedData };
                delete cleanData["测试国家"];
                await setStoredCountryClaims(cleanData);
                console.log('🧹 测试数据已清理');
            } else {
                console.error('❌ 读取的数据不正确');
                updateStatus('error', 'IndexedDB 读取数据失败');
            }
        } else {
            console.error('❌ setStoredCountryClaims 函数不存在');
            updateStatus('error', 'setStoredCountryClaims 函数不存在');
        }

    } catch (error) {
        console.error('❌ IndexedDB 测试失败:', error);
        updateStatus('error', `IndexedDB 测试失败: ${error.message}`);
    }
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        executeStep1,
        executeStep2,
        executeStep3,
        executeStep4,
        executeStep5,
        executeStep6,
        executeAllSteps,
        resetStepData,
        updateStepStatusDisplay,
        clearStepRenders,
        testIndexedDBStorage
    };
}
