/**
 * 领地数据处理模块
 * 负责加载、显示和管理领地数据
 */

/**
 * 加载领地数据
 */
async function loadTerritoryData() {
    updateStatus('info', '正在加载领地数据...');

    try {
        // 首先尝试从IndexedDB获取数据
        let markers = await getStoredMarkers();
        let areas = await getStoredAreas();

        // 如果没有数据，则从服务器获取
        if (!markers && !areas) {
            updateStatus('info', '本地无数据，正在从服务器获取...');
            await fetchAndStoreAllData();
            markers = await getStoredMarkers();
            areas = await getStoredAreas();
        }

        if (!markers && !areas) {
            throw new Error('无法获取领地数据');
        }

        // 处理数据
        territoryData = {
            markers: markers || {},
            areas: areas || {}
        };

        const markerCount = Object.keys(territoryData.markers).length;
        const areaCount = Object.keys(territoryData.areas).length;

        updateStatus('success', `成功加载 ${markerCount} 个标记点和 ${areaCount} 个区域`);
        updateTerritoryList();
        updateStatistics();

    } catch (error) {
        console.error('加载领地数据失败:', error);
        updateStatus('error', `加载失败: ${error.message}`);
    }
}

/**
 * 显示所有领地
 */
function showAllTerritories() {
    if (!territoryData) {
        updateStatus('error', '请先加载领地数据');
        return;
    }

    clearTerritories();

    let markersDisplayed = 0;
    let areasDisplayed = 0;

    // 显示标记点
    for (const [key, marker] of Object.entries(territoryData.markers)) {
        if (marker.x !== undefined && marker.z !== undefined) {
            const mapCoords = mcToMapCoords(marker.x, marker.z);

            const markerIcon = L.marker(mapCoords, {
                title: marker.label || '未命名领地'
            }).addTo(map);

            // 创建弹窗内容
            const popupContent = createMarkerPopup(marker, key);
            markerIcon.bindPopup(popupContent);

            markerLayers.push(markerIcon);
            markersDisplayed++;
        }
    }

    // 显示区域
    for (const [key, area] of Object.entries(territoryData.areas)) {
        if (area.x && area.z && area.x.length > 0) {
            const polygonCoords = [];

            // 转换所有坐标点
            for (let i = 0; i < area.x.length; i++) {
                const mapCoords = mcToMapCoords(area.x[i], area.z[i]);
                polygonCoords.push(mapCoords);
            }

            // 创建多边形
            const polygon = L.polygon(polygonCoords, {
                color: area.color || '#3388ff',
                fillColor: area.fillcolor || '#3388ff',
                fillOpacity: 0.3,
                weight: area.weight || 2
            }).addTo(map);

            // 创建弹窗内容
            const popupContent = createAreaPopup(area, key);
            polygon.bindPopup(popupContent);

            territoryLayers.push(polygon);
            areasDisplayed++;
        }
    }

    displayedAreasCount = areasDisplayed;
    displayedMarkersCount = markersDisplayed;

    const totalDisplayed = areasDisplayed + markersDisplayed;
    updateStatus('success', `已显示 ${totalDisplayed} 个领地对象 (${areasDisplayed} 个区域, ${markersDisplayed} 个出生点)`);
    updateDisplayCounts();
}

/**
 * 只显示领地区域
 */
function showTerritoryAreas() {
    if (!territoryData) {
        updateStatus('error', '请先加载领地数据');
        return;
    }

    // 清除现有的区域显示
    clearTerritoryAreas();

    let areasDisplayed = 0;

    // 显示区域
    for (const [key, area] of Object.entries(territoryData.areas)) {
        if (area.x && area.z && area.x.length > 0) {
            const polygonCoords = [];

            // 转换所有坐标点
            for (let i = 0; i < area.x.length; i++) {
                const mapCoords = mcToMapCoords(area.x[i], area.z[i]);
                polygonCoords.push(mapCoords);
            }

            // 创建多边形
            const polygon = L.polygon(polygonCoords, {
                color: area.color || '#3388ff',
                fillColor: area.fillcolor || '#3388ff',
                fillOpacity: 0.3,
                weight: area.weight || 2
            }).addTo(map);

            // 创建弹窗内容
            const popupContent = createAreaPopup(area, key);
            polygon.bindPopup(popupContent);

            territoryLayers.push(polygon);
            areasDisplayed++;
        }
    }

    displayedAreasCount = areasDisplayed;
    updateStatus('success', `已显示 ${areasDisplayed} 个领地区域`);
    updateDisplayCounts();
}

/**
 * 只显示领地出生点
 */
function showTerritoryMarkers() {
    if (!territoryData) {
        updateStatus('error', '请先加载领地数据');
        return;
    }

    // 清除现有的标记显示
    clearTerritoryMarkers();

    let markersDisplayed = 0;

    // 显示标记点
    for (const [key, marker] of Object.entries(territoryData.markers)) {
        if (marker.x !== undefined && marker.z !== undefined) {
            const mapCoords = mcToMapCoords(marker.x, marker.z);

            const markerIcon = L.marker(mapCoords, {
                title: marker.label || '未命名领地'
            }).addTo(map);

            // 创建弹窗内容
            const popupContent = createMarkerPopup(marker, key);
            markerIcon.bindPopup(popupContent);

            markerLayers.push(markerIcon);
            markersDisplayed++;
        }
    }

    displayedMarkersCount = markersDisplayed;
    updateStatus('success', `已显示 ${markersDisplayed} 个领地出生点`);
    updateDisplayCounts();
}

/**
 * 清除领地区域显示
 */
function clearTerritoryAreas() {
    // 清除区域
    territoryLayers.forEach(layer => map.removeLayer(layer));
    territoryLayers = [];

    displayedAreasCount = 0;
    updateStatus('info', '已清除领地区域显示');
    updateDisplayCounts();
}

/**
 * 清除领地出生点显示
 */
function clearTerritoryMarkers() {
    // 清除标记
    markerLayers.forEach(marker => map.removeLayer(marker));
    markerLayers = [];

    displayedMarkersCount = 0;
    updateStatus('info', '已清除领地出生点显示');
    updateDisplayCounts();
}

/**
 * 清除所有领地显示
 */
function clearTerritories() {
    clearTerritoryAreas();
    clearTerritoryMarkers();
    updateStatus('info', '已清除所有领地显示');
}

/**
 * 获取领地数据统计信息
 * @returns {Object} 统计信息对象
 */
function getTerritoryDataStats() {
    if (!territoryData) {
        return {
            markers: 0,
            areas: 0,
            total: 0,
            loaded: false
        };
    }

    const markerCount = Object.keys(territoryData.markers).length;
    const areaCount = Object.keys(territoryData.areas).length;

    return {
        markers: markerCount,
        areas: areaCount,
        total: markerCount + areaCount,
        loaded: true
    };
}

/**
 * 搜索领地
 * @param {string} searchTerm - 搜索词
 * @returns {Object} 搜索结果
 */
function searchTerritories(searchTerm) {
    if (!territoryData || !searchTerm) {
        return { markers: [], areas: [] };
    }

    const term = searchTerm.toLowerCase();
    const results = { markers: [], areas: [] };

    // 搜索标记点
    for (const [key, marker] of Object.entries(territoryData.markers)) {
        if (marker.label && marker.label.toLowerCase().includes(term)) {
            results.markers.push({ key, data: marker });
        }
    }

    // 搜索区域（如果有标记信息）
    for (const [key, area] of Object.entries(territoryData.areas)) {
        if (area.markup && area.markup.toLowerCase().includes(term)) {
            results.areas.push({ key, data: area });
        }
    }

    return results;
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        loadTerritoryData,
        showAllTerritories,
        showTerritoryAreas,
        showTerritoryMarkers,
        clearTerritoryAreas,
        clearTerritoryMarkers,
        clearTerritories,
        getTerritoryDataStats,
        searchTerritories
    };
}
