/**
 * UI 控制 & 状态显示模块
 * 负责更新界面状态、统计信息和用户反馈
 */

/**
 * 更新状态显示
 * @param {string} type - 状态类型 ('info', 'success', 'warning', 'error')
 * @param {string} message - 状态消息
 */
function updateStatus(type, message) {
    const statusEl = document.getElementById('status-display');
    if (statusEl) {
        statusEl.className = `status-indicator status-${type}`;
        statusEl.textContent = message;
    }
    
    // 同时在控制台输出
    const emoji = {
        'info': 'ℹ️',
        'success': '✅',
        'warning': '⚠️',
        'error': '❌'
    };
    console.log(`${emoji[type] || 'ℹ️'} ${message}`);
}

/**
 * 更新显示计数
 */
function updateDisplayCounts() {
    const displayedAreasEl = document.getElementById('displayed-areas-count');
    const displayedMarkersEl = document.getElementById('displayed-markers-count');
    const displayedCountEl = document.getElementById('displayed-count');

    if (displayedAreasEl) {
        displayedAreasEl.textContent = displayedAreasCount;
    }
    if (displayedMarkersEl) {
        displayedMarkersEl.textContent = displayedMarkersCount;
    }
    if (displayedCountEl) {
        displayedCountEl.textContent = displayedAreasCount + displayedMarkersCount;
    }
}

/**
 * 更新统计信息
 */
function updateStatistics() {
    const territoryCountEl = document.getElementById('territory-count');
    const countryCountEl = document.getElementById('country-count');

    if (!territoryData) {
        if (territoryCountEl) {
            territoryCountEl.textContent = '0';
        }
        return;
    }

    const markerCount = Object.keys(territoryData.markers).length;
    const areaCount = Object.keys(territoryData.areas).length;
    const totalCount = markerCount + areaCount;

    if (territoryCountEl) {
        territoryCountEl.textContent = totalCount;
    }

    // 更新国家数量
    const countryCount = countryClaimsManager ? countryClaimsManager.getCountryCount() : 0;
    if (countryCountEl) {
        countryCountEl.textContent = countryCount;
    }
}

/**
 * 更新领地列表
 */
function updateTerritoryList() {
    const listEl = document.getElementById('territory-list');
    
    if (!listEl) {
        console.warn('⚠️ 领地列表元素未找到');
        return;
    }

    if (!territoryData) {
        listEl.innerHTML = '<div style="padding: 20px; text-align: center; color: #6c757d;">暂无数据</div>';
        return;
    }

    let html = '';

    // 添加标记点
    for (const [key, marker] of Object.entries(territoryData.markers)) {
        html += `
            <div class="territory-item" onclick="focusOnTerritory('marker', '${key}')">
                <div class="territory-name">📍 ${marker.label || '未命名标记'}</div>
                <div class="territory-coords">MC: ${marker.x}, ${marker.z}</div>
            </div>
        `;
    }

    // 添加区域
    for (const [key, area] of Object.entries(territoryData.areas)) {
        if (area.x && area.z && area.x.length > 0) {
            const centerX = Math.round(area.x.reduce((a, b) => a + b, 0) / area.x.length);
            const centerZ = Math.round(area.z.reduce((a, b) => a + b, 0) / area.z.length);

            html += `
                <div class="territory-item" onclick="focusOnTerritory('area', '${key}')">
                    <div class="territory-name">🏘️ 区域 ${key}</div>
                    <div class="territory-coords">中心: ${centerX}, ${centerZ}</div>
                </div>
            `;
        }
    }

    if (html === '') {
        html = '<div style="padding: 20px; text-align: center; color: #6c757d;">暂无领地数据</div>';
    }

    listEl.innerHTML = html;
}

/**
 * 创建标记弹窗内容
 * @param {Object} marker - 标记数据
 * @param {string} key - 标记键值
 * @returns {string} HTML内容
 */
function createMarkerPopup(marker, key) {
    return `
        <div style="min-width: 200px;">
            <h4 style="margin: 0 0 10px 0; color: #2c3e50;">📍 ${marker.label || '未命名标记'}</h4>
            <p><strong>MC坐标:</strong> ${marker.x}, ${marker.z}</p>
            <p><strong>描述:</strong> ${marker.desc || '无描述'}</p>
            <p><strong>ID:</strong> ${key}</p>
        </div>
    `;
}

/**
 * 创建区域弹窗内容
 * @param {Object} area - 区域数据
 * @param {string} key - 区域键值
 * @returns {string} HTML内容
 */
function createAreaPopup(area, key) {
    const centerX = Math.round(area.x.reduce((a, b) => a + b, 0) / area.x.length);
    const centerZ = Math.round(area.z.reduce((a, b) => a + b, 0) / area.z.length);

    return `
        <div style="min-width: 200px;">
            <h4 style="margin: 0 0 10px 0; color: #2c3e50;">🏘️ 领地区域</h4>
            <p><strong>中心坐标:</strong> ${centerX}, ${centerZ}</p>
            <p><strong>顶点数量:</strong> ${area.x.length}</p>
            <p><strong>区域ID:</strong> ${key}</p>
            ${area.markup ? `<p><strong>标记:</strong> ${area.markup}</p>` : ''}
        </div>
    `;
}

/**
 * 显示加载进度
 * @param {number} current - 当前进度
 * @param {number} total - 总数
 * @param {string} message - 进度消息
 */
function updateProgress(current, total, message) {
    const percentage = Math.round((current / total) * 100);
    const progressMessage = `${message} (${current}/${total} - ${percentage}%)`;
    updateStatus('info', progressMessage);
}

/**
 * 显示操作确认对话框
 * @param {string} message - 确认消息
 * @param {string} title - 对话框标题
 * @returns {boolean} 用户确认结果
 */
function showConfirmDialog(message, title = '确认操作') {
    return confirm(`${title}\n\n${message}`);
}

/**
 * 显示信息对话框
 * @param {string} message - 信息内容
 * @param {string} title - 对话框标题
 */
function showInfoDialog(message, title = '信息') {
    alert(`${title}\n\n${message}`);
}

/**
 * 更新按钮状态
 * @param {string} buttonId - 按钮ID
 * @param {boolean} enabled - 是否启用
 * @param {string} text - 按钮文本（可选）
 */
function updateButtonState(buttonId, enabled, text = null) {
    const button = document.getElementById(buttonId);
    if (button) {
        button.disabled = !enabled;
        if (text !== null) {
            button.textContent = text;
        }
    }
}

/**
 * 显示/隐藏加载指示器
 * @param {boolean} show - 是否显示
 * @param {string} message - 加载消息
 */
function toggleLoadingIndicator(show, message = '加载中...') {
    const indicator = document.getElementById('loading-indicator');
    if (indicator) {
        if (show) {
            indicator.style.display = 'block';
            indicator.textContent = message;
        } else {
            indicator.style.display = 'none';
        }
    }
}

/**
 * 更新国家选择下拉框
 * @param {Array} countries - 国家列表
 */
function updateCountrySelector(countries) {
    const selector = document.getElementById('country-selector');
    if (!selector) return;

    // 清空现有选项
    selector.innerHTML = '<option value="">选择国家...</option>';

    // 添加国家选项
    countries.forEach(country => {
        const option = document.createElement('option');
        option.value = country;
        option.textContent = country;
        selector.appendChild(option);
    });
}

/**
 * 高亮显示特定元素
 * @param {string} elementId - 元素ID
 * @param {number} duration - 高亮持续时间（毫秒）
 */
function highlightElement(elementId, duration = 2000) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.add('highlight');
        setTimeout(() => {
            element.classList.remove('highlight');
        }, duration);
    }
}

/**
 * 格式化数字显示
 * @param {number} num - 数字
 * @returns {string} 格式化后的字符串
 */
function formatNumber(num) {
    if (typeof num !== 'number') return '0';
    return num.toLocaleString();
}

/**
 * 格式化文件大小
 * @param {number} bytes - 字节数
 * @returns {string} 格式化后的大小字符串
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 导出函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        updateStatus,
        updateDisplayCounts,
        updateStatistics,
        updateTerritoryList,
        createMarkerPopup,
        createAreaPopup,
        updateProgress,
        showConfirmDialog,
        showInfoDialog,
        updateButtonState,
        toggleLoadingIndicator,
        updateCountrySelector,
        highlightElement,
        formatNumber,
        formatFileSize
    };
}
