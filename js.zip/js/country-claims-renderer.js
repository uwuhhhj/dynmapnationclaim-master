/**
 * 国家宣称范围绘制器
 * 专门负责国家宣称范围的可视化绘制
 *
 * @author Dynmap Territory System
 * @version 1.0.0
 */

class CountryClaimsRenderer {
    constructor(map, coordinateConverter, options = {}) {
        this.map = map;
        this.mcToMapCoords = coordinateConverter.mcToMapCoords;
        this.mapToMcCoords = coordinateConverter.mapToMcCoords;

        // 绘制图层管理
        this.claimsLayers = [];
        this.layerGroups = new Map(); // 按国家分组的图层

        // 配置选项
        this.config = {
            // 默认样式配置
            styles: {
                default: {
                    color: '#ff6b6b',
                    fillColor: '#ff6b6b',
                    fillOpacity: 0.2,
                    weight: 3,
                    opacity: 0.8
                },
                hover: {
                    color: '#ff3333',
                    fillColor: '#ff3333',
                    fillOpacity: 0.3,
                    weight: 4,
                    opacity: 1.0
                },
                selected: {
                    color: '#ff0000',
                    fillColor: '#ff0000',
                    fillOpacity: 0.4,
                    weight: 5,
                    opacity: 1.0
                }
            },
            // 几何形状配置
            geometry: {
                circle: {
                    radius: 500, // 单点国家的圆圈半径（米）
                    minRadius: 200,
                    maxRadius: 2000
                },
                line: {
                    weight: 4,
                    minWeight: 2,
                    maxWeight: 8
                },
                polygon: {
                    smoothFactor: 1.0,
                    noClip: false
                }
            },
            // 交互配置
            interaction: {
                enablePopup: true,
                enableTooltip: true,
                autoFitView: true,
                fitViewPadding: 0.1
            },
            // 算法配置
            algorithms: {
                convexHull: {
                    enabled: true,
                    minPoints: 3
                },
                clustering: {
                    enabled: false,
                    maxDistance: 1000
                }
            },
            ...options
        };

        // 事件回调
        this.callbacks = {
            onClaimRendered: null,
            onClaimClicked: null,
            onClaimHovered: null,
            onError: null
        };
    }

    /**
     * 设置事件回调
     * @param {string} event - 事件名称
     * @param {Function} callback - 回调函数
     */
    on(event, callback) {
        if (this.callbacks.hasOwnProperty(`on${event.charAt(0).toUpperCase() + event.slice(1)}`)) {
            this.callbacks[`on${event.charAt(0).toUpperCase() + event.slice(1)}`] = callback;
        }
    }

    /**
     * 渲染国家宣称范围
     * @param {string} countryName - 国家名称
     * @param {Object} countryData - 国家数据（包含标记点）
     * @param {Object} renderOptions - 渲染选项
     * @returns {Object} 渲染结果
     */
    renderCountryClaims(countryName, countryData, renderOptions = {}) {
        try {
            // 验证输入数据
            if (!countryName || !countryData) {
                throw new Error('国家名称和数据不能为空');
            }

            // 提取坐标点
            const coordinates = this.extractCoordinates(countryData);

            if (coordinates.length === 0) {
                throw new Error(`国家 "${countryName}" 没有有效的坐标数据`);
            }

            // 清除该国家之前的绘制
            this.clearCountryClaims(countryName);

            // 根据坐标点数量选择绘制策略
            const renderStrategy = this.selectRenderStrategy(coordinates.length);

            // 执行绘制
            const layers = this.executeRenderStrategy(
                renderStrategy,
                countryName,
                coordinates,
                renderOptions
            );

            // 存储图层
            this.storeCountryLayers(countryName, layers);

            // 设置交互事件
            this.setupLayerInteractions(layers, countryName);

            // 自动调整视图（检查渲染选项中的禁用标志）
            if (this.config.interaction.autoFitView && !renderOptions.disableAutoFit) {
                this.fitViewToCountry(countryName);
            }

            // 触发回调
            if (this.callbacks.onClaimRendered) {
                this.callbacks.onClaimRendered(countryName, layers);
            }

            return {
                success: true,
                countryName,
                layerCount: layers.length,
                strategy: renderStrategy,
                coordinates: coordinates.length
            };

        } catch (error) {
            console.error(`渲染国家宣称失败 [${countryName}]:`, error);

            if (this.callbacks.onError) {
                this.callbacks.onError(error, countryName);
            }

            return {
                success: false,
                error: error.message,
                countryName
            };
        }
    }

    /**
     * 从国家数据中提取坐标
     * @param {Object} countryData - 国家数据
     * @returns {Array} 坐标数组
     */
    extractCoordinates(countryData) {
        const coordinates = [];

        for (const [key, marker] of Object.entries(countryData)) {
            if (this.isValidCoordinate(marker)) {
                const mapCoords = this.mcToMapCoords(marker.x, marker.z);
                coordinates.push({
                    mapCoords,
                    mcCoords: { x: marker.x, z: marker.z },
                    markerId: key,
                    markerData: marker
                });
            }
        }

        return coordinates;
    }

    /**
     * 验证坐标是否有效
     * @param {Object} marker - 标记数据
     * @returns {boolean} 是否有效
     */
    isValidCoordinate(marker) {
        return marker &&
               typeof marker.x === 'number' &&
               typeof marker.z === 'number' &&
               !isNaN(marker.x) &&
               !isNaN(marker.z);
    }

    /**
     * 选择渲染策略
     * @param {number} pointCount - 坐标点数量
     * @returns {string} 渲染策略名称
     */
    selectRenderStrategy(pointCount) {
        if (pointCount === 1) {
            return 'circle';
        } else if (pointCount === 2) {
            return 'line';
        } else if (pointCount >= this.config.algorithms.convexHull.minPoints) {
            return 'polygon';
        } else {
            return 'multipoint';
        }
    }

    /**
     * 执行渲染策略
     * @param {string} strategy - 渲染策略
     * @param {string} countryName - 国家名称
     * @param {Array} coordinates - 坐标数组
     * @param {Object} options - 渲染选项
     * @returns {Array} 图层数组
     */
    executeRenderStrategy(strategy, countryName, coordinates, options) {
        const mergedOptions = { ...this.config.styles.default, ...options };

        switch (strategy) {
            case 'circle':
                return [this.createCircleClaim(countryName, coordinates[0], mergedOptions)];

            case 'line':
                return [this.createLineClaim(countryName, coordinates, mergedOptions)];

            case 'polygon':
                return [this.createPolygonClaim(countryName, coordinates, mergedOptions)];

            case 'multipoint':
                return this.createMultipointClaim(countryName, coordinates, mergedOptions);

            default:
                throw new Error(`未知的渲染策略: ${strategy}`);
        }
    }

    /**
     * 创建圆形宣称范围（单点国家）
     * @param {string} countryName - 国家名称
     * @param {Object} coordinate - 坐标对象
     * @param {Object} style - 样式配置
     * @returns {Object} Leaflet 圆形图层
     */
    createCircleClaim(countryName, coordinate, style) {
        const circle = L.circle(coordinate.mapCoords, {
            ...style,
            radius: this.config.geometry.circle.radius
        }).addTo(this.map);

        // 设置弹窗内容
        if (this.config.interaction.enablePopup) {
            circle.bindPopup(this.createPopupContent(countryName, {
                type: '单点宣称',
                coordinates: `${coordinate.mcCoords.x}, ${coordinate.mcCoords.z}`,
                markerCount: 1,
                area: this.calculateCircleArea(this.config.geometry.circle.radius)
            }));
        }

        // 设置工具提示
        if (this.config.interaction.enableTooltip) {
            circle.bindTooltip(`🏛️ ${countryName} (单点宣称)`, {
                permanent: false,
                direction: 'top'
            });
        }

        return circle;
    }

    /**
     * 创建线性宣称范围（两点国家）
     * @param {string} countryName - 国家名称
     * @param {Array} coordinates - 坐标数组
     * @param {Object} style - 样式配置
     * @returns {Object} Leaflet 线条图层
     */
    createLineClaim(countryName, coordinates, style) {
        const mapCoords = coordinates.map(coord => coord.mapCoords);

        const polyline = L.polyline(mapCoords, {
            color: style.color,
            weight: this.config.geometry.line.weight,
            opacity: style.opacity
        }).addTo(this.map);

        // 设置弹窗内容
        if (this.config.interaction.enablePopup) {
            polyline.bindPopup(this.createPopupContent(countryName, {
                type: '线性宣称',
                markerCount: coordinates.length,
                length: this.calculateLineLength(coordinates)
            }));
        }

        // 设置工具提示
        if (this.config.interaction.enableTooltip) {
            polyline.bindTooltip(`🏛️ ${countryName} (线性宣称)`, {
                permanent: false,
                direction: 'top'
            });
        }

        return polyline;
    }

    /**
     * 创建多边形宣称范围（多点国家）
     * @param {string} countryName - 国家名称
     * @param {Array} coordinates - 坐标数组
     * @param {Object} style - 样式配置
     * @returns {Object} Leaflet 多边形图层
     */
    createPolygonClaim(countryName, coordinates, style) {
        // 计算凸包
        const mapCoords = coordinates.map(coord => coord.mapCoords);
        const hullCoords = this.calculateConvexHull([...mapCoords]);

        const polygon = L.polygon(hullCoords, {
            ...style,
            smoothFactor: this.config.geometry.polygon.smoothFactor,
            noClip: this.config.geometry.polygon.noClip
        }).addTo(this.map);

        // 设置弹窗内容
        if (this.config.interaction.enablePopup) {
            polygon.bindPopup(this.createPopupContent(countryName, {
                type: '多边形宣称',
                markerCount: coordinates.length,
                vertices: hullCoords.length,
                area: this.calculatePolygonArea(hullCoords)
            }));
        }

        // 设置工具提示
        if (this.config.interaction.enableTooltip) {
            polygon.bindTooltip(`🏛️ ${countryName} (多边形宣称)`, {
                permanent: false,
                direction: 'center'
            });
        }

        return polygon;
    }

    /**
     * 创建多点宣称范围（少于3个点的情况）
     * @param {string} countryName - 国家名称
     * @param {Array} coordinates - 坐标数组
     * @param {Object} style - 样式配置
     * @returns {Array} Leaflet 图层数组
     */
    createMultipointClaim(countryName, coordinates, style) {
        const layers = [];

        // 为每个点创建圆形标记
        coordinates.forEach((coordinate, index) => {
            const circle = L.circle(coordinate.mapCoords, {
                ...style,
                radius: this.config.geometry.circle.radius * 0.7 // 稍小的半径
            }).addTo(this.map);

            if (this.config.interaction.enablePopup) {
                circle.bindPopup(this.createPopupContent(countryName, {
                    type: `多点宣称 (${index + 1}/${coordinates.length})`,
                    coordinates: `${coordinate.mcCoords.x}, ${coordinate.mcCoords.z}`,
                    markerCount: coordinates.length
                }));
            }

            layers.push(circle);
        });

        return layers;
    }

    /**
     * 计算凸包（Graham扫描算法的优化版本）
     * @param {Array} points - 点数组
     * @returns {Array} 凸包点数组
     */
    calculateConvexHull(points) {
        if (points.length < 3) return points;

        // 去重
        const uniquePoints = this.removeDuplicatePoints(points);
        if (uniquePoints.length < 3) return uniquePoints;

        // 找到最下方的点（y值最小，如果相同则x值最小）
        let bottom = 0;
        for (let i = 1; i < uniquePoints.length; i++) {
            if (uniquePoints[i][0] < uniquePoints[bottom][0] ||
                (uniquePoints[i][0] === uniquePoints[bottom][0] && uniquePoints[i][1] < uniquePoints[bottom][1])) {
                bottom = i;
            }
        }

        // 将最下方的点移到第一个位置
        [uniquePoints[0], uniquePoints[bottom]] = [uniquePoints[bottom], uniquePoints[0]];

        // 按极角排序
        const start = uniquePoints[0];
        const sortedPoints = [start, ...uniquePoints.slice(1).sort((a, b) => {
            const angleA = Math.atan2(a[0] - start[0], a[1] - start[1]);
            const angleB = Math.atan2(b[0] - start[0], b[1] - start[1]);
            if (angleA === angleB) {
                // 如果角度相同，选择距离更近的点
                const distA = this.calculateDistance(start, a);
                const distB = this.calculateDistance(start, b);
                return distA - distB;
            }
            return angleA - angleB;
        })];

        // 构建凸包
        const hull = [sortedPoints[0]];

        for (let i = 1; i < sortedPoints.length; i++) {
            // 移除不在凸包上的点
            while (hull.length > 1 &&
                   this.crossProduct(hull[hull.length-2], hull[hull.length-1], sortedPoints[i]) <= 0) {
                hull.pop();
            }
            hull.push(sortedPoints[i]);
        }

        return hull;
    }

    /**
     * 去除重复点
     * @param {Array} points - 点数组
     * @returns {Array} 去重后的点数组
     */
    removeDuplicatePoints(points) {
        const unique = [];
        const seen = new Set();

        for (const point of points) {
            const key = `${point[0]},${point[1]}`;
            if (!seen.has(key)) {
                seen.add(key);
                unique.push(point);
            }
        }

        return unique;
    }

    /**
     * 计算叉积（用于判断点的转向）
     * @param {Array} o - 原点
     * @param {Array} a - 点A
     * @param {Array} b - 点B
     * @returns {number} 叉积值
     */
    crossProduct(o, a, b) {
        return (a[1] - o[1]) * (b[0] - o[0]) - (a[0] - o[0]) * (b[1] - o[1]);
    }

    /**
     * 计算两点间距离
     * @param {Array} point1 - 点1
     * @param {Array} point2 - 点2
     * @returns {number} 距离
     */
    calculateDistance(point1, point2) {
        const dx = point2[0] - point1[0];
        const dy = point2[1] - point1[1];
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * 计算圆形面积
     * @param {number} radius - 半径
     * @returns {string} 格式化的面积字符串
     */
    calculateCircleArea(radius) {
        const area = Math.PI * radius * radius;
        return this.formatArea(area);
    }

    /**
     * 计算线条长度
     * @param {Array} coordinates - 坐标数组
     * @returns {string} 格式化的长度字符串
     */
    calculateLineLength(coordinates) {
        if (coordinates.length < 2) return '0 米';

        let totalLength = 0;
        for (let i = 1; i < coordinates.length; i++) {
            totalLength += this.calculateDistance(
                coordinates[i-1].mapCoords,
                coordinates[i].mapCoords
            );
        }

        return this.formatDistance(totalLength);
    }

    /**
     * 计算多边形面积
     * @param {Array} points - 点数组
     * @returns {string} 格式化的面积字符串
     */
    calculatePolygonArea(points) {
        if (points.length < 3) return '0 平方米';

        let area = 0;
        for (let i = 0; i < points.length; i++) {
            const j = (i + 1) % points.length;
            area += points[i][0] * points[j][1];
            area -= points[j][0] * points[i][1];
        }

        return this.formatArea(Math.abs(area) / 2);
    }

    /**
     * 格式化面积显示
     * @param {number} area - 面积值
     * @returns {string} 格式化字符串
     */
    formatArea(area) {
        if (area >= 1000000) {
            return `${(area / 1000000).toFixed(2)} 平方公里`;
        } else if (area >= 10000) {
            return `${(area / 10000).toFixed(2)} 公顷`;
        } else {
            return `${area.toFixed(0)} 平方米`;
        }
    }

    /**
     * 格式化距离显示
     * @param {number} distance - 距离值
     * @returns {string} 格式化字符串
     */
    formatDistance(distance) {
        if (distance >= 1000) {
            return `${(distance / 1000).toFixed(2)} 公里`;
        } else {
            return `${distance.toFixed(0)} 米`;
        }
    }

    /**
     * 创建弹窗内容
     * @param {string} countryName - 国家名称
     * @param {Object} info - 信息对象
     * @returns {string} HTML 内容
     */
    createPopupContent(countryName, info) {
        let content = `
            <div style="min-width: 220px; font-family: Arial, sans-serif;">
                <h4 style="margin: 0 0 12px 0; color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 5px;">
                    🏛️ ${countryName}
                </h4>
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">类型:</strong>
                    <span style="color: #7f8c8d;">${info.type}</span>
                </div>
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">标记点数:</strong>
                    <span style="color: #7f8c8d;">${info.markerCount}</span>
                </div>
        `;

        if (info.coordinates) {
            content += `
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">坐标:</strong>
                    <span style="color: #7f8c8d; font-family: monospace;">${info.coordinates}</span>
                </div>
            `;
        }

        if (info.vertices) {
            content += `
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">边界顶点:</strong>
                    <span style="color: #7f8c8d;">${info.vertices}</span>
                </div>
            `;
        }

        if (info.area) {
            content += `
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">面积:</strong>
                    <span style="color: #e74c3c;">${info.area}</span>
                </div>
            `;
        }

        if (info.length) {
            content += `
                <div style="margin-bottom: 8px;">
                    <strong style="color: #34495e;">长度:</strong>
                    <span style="color: #e74c3c;">${info.length}</span>
                </div>
            `;
        }

        content += `
                <div style="margin-top: 10px; padding-top: 8px; border-top: 1px solid #ecf0f1; font-size: 12px; color: #95a5a6;">
                    点击查看详细信息
                </div>
            </div>
        `;

        return content;
    }

    /**
     * 存储国家图层
     * @param {string} countryName - 国家名称
     * @param {Array} layers - 图层数组
     */
    storeCountryLayers(countryName, layers) {
        // 添加到总图层列表
        this.claimsLayers.push(...layers);

        // 按国家分组存储
        this.layerGroups.set(countryName, layers);
    }

    /**
     * 设置图层交互事件
     * @param {Array} layers - 图层数组
     * @param {string} countryName - 国家名称
     */
    setupLayerInteractions(layers, countryName) {
        layers.forEach(layer => {
            // 点击事件
            layer.on('click', (e) => {
                if (this.callbacks.onClaimClicked) {
                    this.callbacks.onClaimClicked(countryName, layer, e);
                }
            });

            // 鼠标悬停事件
            layer.on('mouseover', (e) => {
                // 应用悬停样式
                if (layer.setStyle) {
                    layer.setStyle(this.config.styles.hover);
                }

                if (this.callbacks.onClaimHovered) {
                    this.callbacks.onClaimHovered(countryName, layer, e);
                }
            });

            // 鼠标离开事件
            layer.on('mouseout', (e) => {
                // 恢复默认样式
                if (layer.setStyle) {
                    layer.setStyle(this.config.styles.default);
                }
            });
        });
    }

    /**
     * 调整视图以适应国家范围
     * @param {string} countryName - 国家名称
     */
    fitViewToCountry(countryName) {
        const layers = this.layerGroups.get(countryName);
        if (!layers || layers.length === 0) return;

        if (layers.length === 1) {
            // 单个图层，直接设置视图
            const layer = layers[0];
            if (layer.getLatLng) {
                // 圆形或标记
                this.map.setView(layer.getLatLng(), Math.max(this.map.getZoom(), 2));
            } else if (layer.getBounds) {
                // 多边形或线条
                this.map.fitBounds(layer.getBounds(), {
                    padding: [20, 20]
                });
            }
        } else {
            // 多个图层，创建组合边界
            const group = new L.featureGroup(layers);
            this.map.fitBounds(group.getBounds().pad(this.config.interaction.fitViewPadding));
        }
    }

    /**
     * 清除指定国家的宣称范围
     * @param {string} countryName - 国家名称
     */
    clearCountryClaims(countryName) {
        const layers = this.layerGroups.get(countryName);
        if (layers) {
            layers.forEach(layer => {
                this.map.removeLayer(layer);
                // 从总图层列表中移除
                const index = this.claimsLayers.indexOf(layer);
                if (index > -1) {
                    this.claimsLayers.splice(index, 1);
                }
            });
            this.layerGroups.delete(countryName);
        }
    }

    /**
     * 清除所有宣称范围
     */
    clearAllClaims() {
        this.claimsLayers.forEach(layer => this.map.removeLayer(layer));
        this.claimsLayers = [];
        this.layerGroups.clear();
    }

    /**
     * 获取已渲染的国家列表
     * @returns {Array} 国家名称数组
     */
    getRenderedCountries() {
        return Array.from(this.layerGroups.keys());
    }

    /**
     * 获取指定国家的图层
     * @param {string} countryName - 国家名称
     * @returns {Array} 图层数组
     */
    getCountryLayers(countryName) {
        return this.layerGroups.get(countryName) || [];
    }

    /**
     * 检查国家是否已渲染
     * @param {string} countryName - 国家名称
     * @returns {boolean} 是否已渲染
     */
    isCountryRendered(countryName) {
        return this.layerGroups.has(countryName);
    }

    /**
     * 获取渲染统计信息
     * @returns {Object} 统计信息
     */
    getRenderStats() {
        return {
            totalLayers: this.claimsLayers.length,
            renderedCountries: this.layerGroups.size,
            countries: Array.from(this.layerGroups.keys()),
            layersByCountry: Object.fromEntries(
                Array.from(this.layerGroups.entries()).map(([country, layers]) => [
                    country,
                    layers.length
                ])
            )
        };
    }

    /**
     * 更新渲染配置
     * @param {Object} newConfig - 新配置
     */
    updateConfig(newConfig) {
        this.config = {
            ...this.config,
            ...newConfig,
            styles: { ...this.config.styles, ...newConfig.styles },
            geometry: { ...this.config.geometry, ...newConfig.geometry },
            interaction: { ...this.config.interaction, ...newConfig.interaction },
            algorithms: { ...this.config.algorithms, ...newConfig.algorithms }
        };
    }

    /**
     * 高亮显示指定国家
     * @param {string} countryName - 国家名称
     */
    highlightCountry(countryName) {
        const layers = this.layerGroups.get(countryName);
        if (layers) {
            layers.forEach(layer => {
                if (layer.setStyle) {
                    layer.setStyle(this.config.styles.selected);
                }
            });
        }
    }

    /**
     * 取消高亮显示指定国家
     * @param {string} countryName - 国家名称
     */
    unhighlightCountry(countryName) {
        const layers = this.layerGroups.get(countryName);
        if (layers) {
            layers.forEach(layer => {
                if (layer.setStyle) {
                    layer.setStyle(this.config.styles.default);
                }
            });
        }
    }

    /**
     * 取消所有高亮
     */
    unhighlightAll() {
        this.claimsLayers.forEach(layer => {
            if (layer.setStyle) {
                layer.setStyle(this.config.styles.default);
            }
        });
    }

    /**
     * 销毁渲染器，清理所有资源
     */
    destroy() {
        this.clearAllClaims();
        this.callbacks = {};
        this.config = null;
        this.map = null;
        this.mcToMapCoords = null;
        this.mapToMcCoords = null;
    }
}

// 导出类（如果使用模块系统）
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CountryClaimsRenderer;
}
