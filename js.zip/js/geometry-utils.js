/**
 * 几何处理工具模块
 * 提供多边形合并、缓冲区处理等几何计算功能
 * 所有操作都基于Minecraft区块对齐（16x16方块）
 */

class GeometryUtils {
    // Minecraft区块大小常量
    static CHUNK_SIZE = 16;

    /**
     * 将坐标对齐到区块边界
     * @param {number} coord - 坐标值
     * @returns {number} 对齐后的坐标
     */
    static alignToChunk(coord) {
        return Math.floor(coord / this.CHUNK_SIZE) * this.CHUNK_SIZE;
    }

    /**
     * 将坐标对齐到区块边界（向上取整）
     * @param {number} coord - 坐标值
     * @returns {number} 对齐后的坐标
     */
    static alignToChunkCeil(coord) {
        return Math.ceil(coord / this.CHUNK_SIZE) * this.CHUNK_SIZE;
    }

    /**
     * 将点对齐到区块网格
     * @param {Array} point - 点坐标 [x, z]
     * @param {boolean} ceil - 是否向上取整
     * @returns {Array} 对齐后的点坐标
     */
    static alignPointToChunk(point, ceil = false) {
        const [x, z] = point;
        if (ceil) {
            return [this.alignToChunkCeil(x), this.alignToChunkCeil(z)];
        } else {
            return [this.alignToChunk(x), this.alignToChunk(z)];
        }
    }

    /**
     * 将边界框对齐到区块网格
     * @param {Object} bounds - 边界框 {minX, maxX, minZ, maxZ}
     * @returns {Object} 对齐后的边界框
     */
    static alignBoundsToChunk(bounds) {
        return {
            minX: this.alignToChunk(bounds.minX),
            maxX: this.alignToChunkCeil(bounds.maxX),
            minZ: this.alignToChunk(bounds.minZ),
            maxZ: this.alignToChunkCeil(bounds.maxZ)
        };
    }
    /**
     * 将区域数据转换为多边形坐标数组
     * @param {Object} area - 区域数据，包含x和z数组
     * @returns {Array} 多边形坐标数组 [[x1, z1], [x2, z2], ...]
     */
    static areaToPolygon(area) {
        if (!area || !area.x || !area.z || area.x.length !== area.z.length) {
            console.warn('⚠️ 无效的区域数据:', area);
            return [];
        }

        const polygon = [];
        for (let i = 0; i < area.x.length; i++) {
            polygon.push([area.x[i], area.z[i]]);
        }

        return polygon;
    }

    /**
     * 计算多边形的面积（使用鞋带公式）
     * @param {Array} polygon - 多边形坐标数组
     * @returns {number} 面积
     */
    static calculatePolygonArea(polygon) {
        if (polygon.length < 3) return 0;

        let area = 0;
        const n = polygon.length;

        for (let i = 0; i < n; i++) {
            const j = (i + 1) % n;
            area += polygon[i][0] * polygon[j][1];
            area -= polygon[j][0] * polygon[i][1];
        }

        return Math.abs(area) / 2;
    }

    /**
     * 计算多边形的中心点（质心）
     * @param {Array} polygon - 多边形坐标数组
     * @returns {Object} 中心点 {x, z}
     */
    static calculatePolygonCenter(polygon) {
        if (polygon.length === 0) return null;

        let sumX = 0, sumZ = 0;
        for (const point of polygon) {
            sumX += point[0];
            sumZ += point[1];
        }

        return {
            x: Math.round(sumX / polygon.length),
            z: Math.round(sumZ / polygon.length)
        };
    }

    /**
     * 计算多边形的边界框
     * @param {Array} polygon - 多边形坐标数组
     * @returns {Object} 边界框 {minX, maxX, minZ, maxZ}
     */
    static calculatePolygonBounds(polygon) {
        if (polygon.length === 0) return null;

        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        for (const point of polygon) {
            minX = Math.min(minX, point[0]);
            maxX = Math.max(maxX, point[0]);
            minZ = Math.min(minZ, point[1]);
            maxZ = Math.max(maxZ, point[1]);
        }

        return { minX, maxX, minZ, maxZ };
    }

    /**
     * 精确的多边形合并（使用Martinez库进行并集运算）
     * @param {Array} polygons - 多边形数组
     * @param {number} bufferDistance - 缓冲距离（方块单位）
     * @returns {Array} 合并后的多边形坐标数组
     */
    static mergePolygons(polygons, bufferDistance = 80) {
        console.log(`🔧 使用Martinez库合并 ${polygons.length} 个多边形，缓冲距离: ${bufferDistance}方块`);

        if (polygons.length === 0) return [];
        if (polygons.length === 1) return this.bufferPolygon(polygons[0], bufferDistance);

        try {
            // 检查Martinez库是否可用
            if (typeof window.MartinezGeometryUtils !== 'undefined') {
                // 使用Martinez库进行精确的并集运算
                const result = MartinezGeometryUtils.unionPolygons(polygons);

                if (result.length < 3) {
                    console.log(`⚠️ Martinez并集运算结果无效，使用边界框合并`);
                    return this.fallbackMergePolygons(polygons, bufferDistance);
                }

                // 应用缓冲区
                const bufferedResult = bufferDistance > 0 ?
                    MartinezGeometryUtils.bufferPolygon(result, bufferDistance) : result;

                console.log(`✅ Martinez并集运算完成: 结果 ${bufferedResult.length} 个顶点`);
                return bufferedResult;
            } else {
                console.log(`⚠️ Martinez库未加载，使用边界框合并`);
                return this.fallbackMergePolygons(polygons, bufferDistance);
            }

        } catch (error) {
            console.error(`❌ Martinez并集运算失败，回退到边界框合并:`, error);
            return this.fallbackMergePolygons(polygons, bufferDistance);
        }
    }

    /**
     * 备用的多边形合并方法（使用边界框）
     * @param {Array} polygons - 多边形数组
     * @param {number} bufferDistance - 缓冲距离
     * @returns {Array} 合并后的多边形
     */
    static fallbackMergePolygons(polygons, bufferDistance) {
        console.log(`🛡️ 执行边界框合并策略`);

        // 计算所有多边形的总边界框
        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        for (const polygon of polygons) {
            const bounds = this.calculatePolygonBounds(polygon);
            if (bounds) {
                minX = Math.min(minX, bounds.minX);
                maxX = Math.max(maxX, bounds.maxX);
                minZ = Math.min(minZ, bounds.minZ);
                maxZ = Math.max(maxZ, bounds.maxZ);
            }
        }

        // 扩展边界框（应用缓冲）
        const expandedBounds = {
            minX: minX - bufferDistance,
            maxX: maxX + bufferDistance,
            minZ: minZ - bufferDistance,
            maxZ: maxZ + bufferDistance
        };

        // 创建合并后的矩形多边形
        const mergedPolygon = [
            [expandedBounds.minX, expandedBounds.minZ],
            [expandedBounds.maxX, expandedBounds.minZ],
            [expandedBounds.maxX, expandedBounds.maxZ],
            [expandedBounds.minX, expandedBounds.maxZ]
        ];

        console.log(`✅ 边界框合并完成: (${expandedBounds.minX}, ${expandedBounds.minZ}) 到 (${expandedBounds.maxX}, ${expandedBounds.maxZ})`);
        return mergedPolygon;
    }

    /**
     * 对多边形应用缓冲区（区块对齐版本，创建矩形缓冲区）
     * @param {Array} polygon - 多边形坐标数组
     * @param {number} bufferDistance - 缓冲距离（方块单位）
     * @returns {Array} 缓冲后的多边形（区块对齐）
     */
    static bufferPolygon(polygon, bufferDistance = null) {
        // 如果没有提供缓冲距离，从配置中获取
        if (bufferDistance === null) {
            const bufferDistanceEl = document.getElementById('buffer-distance');
            const bufferDistanceChunks = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
            bufferDistance = bufferDistanceChunks * 16;
        }
        if (polygon.length === 0) return [];

        const bounds = this.calculatePolygonBounds(polygon);
        if (!bounds) return [];

        // 扩展边界框并对齐到区块
        const expandedBounds = {
            minX: bounds.minX - bufferDistance,
            maxX: bounds.maxX + bufferDistance,
            minZ: bounds.minZ - bufferDistance,
            maxZ: bounds.maxZ + bufferDistance
        };

        // 对齐到区块边界
        const alignedBounds = this.alignBoundsToChunk(expandedBounds);

        // 创建区块对齐的矩形
        return [
            [alignedBounds.minX, alignedBounds.minZ],
            [alignedBounds.maxX, alignedBounds.minZ],
            [alignedBounds.maxX, alignedBounds.maxZ],
            [alignedBounds.minX, alignedBounds.maxZ]
        ];
    }

    /**
     * 创建凸包（Graham扫描算法）
     * @param {Array} points - 点数组 [[x, z], ...]
     * @returns {Array} 凸包点数组
     */
    static calculateConvexHull(points) {
        if (points.length < 3) return points;

        // 去重
        const uniquePoints = this.removeDuplicatePoints(points);
        if (uniquePoints.length < 3) return uniquePoints;

        // 找到最下方的点（z值最小，如果相同则x值最小）
        let bottom = 0;
        for (let i = 1; i < uniquePoints.length; i++) {
            if (uniquePoints[i][1] < uniquePoints[bottom][1] ||
                (uniquePoints[i][1] === uniquePoints[bottom][1] && uniquePoints[i][0] < uniquePoints[bottom][0])) {
                bottom = i;
            }
        }

        // 将最下方的点移到第一个位置
        [uniquePoints[0], uniquePoints[bottom]] = [uniquePoints[bottom], uniquePoints[0]];

        // 按极角排序
        const start = uniquePoints[0];
        uniquePoints.slice(1).sort((a, b) => {
            const angleA = Math.atan2(a[1] - start[1], a[0] - start[0]);
            const angleB = Math.atan2(b[1] - start[1], b[0] - start[0]);
            return angleA - angleB;
        });

        // 构建凸包
        const hull = [uniquePoints[0]];

        for (let i = 1; i < uniquePoints.length; i++) {
            // 移除不在凸包上的点
            while (hull.length > 1 &&
                   this.crossProduct(hull[hull.length-2], hull[hull.length-1], uniquePoints[i]) <= 0) {
                hull.pop();
            }
            hull.push(uniquePoints[i]);
        }

        return hull;
    }

    /**
     * 计算叉积（用于判断点的转向）
     * @param {Array} o - 原点 [x, z]
     * @param {Array} a - 点A [x, z]
     * @param {Array} b - 点B [x, z]
     * @returns {number} 叉积值
     */
    static crossProduct(o, a, b) {
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    }

    /**
     * 移除重复点
     * @param {Array} points - 点数组
     * @returns {Array} 去重后的点数组
     */
    static removeDuplicatePoints(points) {
        const unique = [];
        const seen = new Set();

        for (const point of points) {
            const key = `${point[0]},${point[1]}`;
            if (!seen.has(key)) {
                seen.add(key);
                unique.push(point);
            }
        }

        return unique;
    }

    /**
     * 检查点是否在多边形内（射线法）
     * @param {Array} point - 点坐标 [x, z]
     * @param {Array} polygon - 多边形坐标数组
     * @returns {boolean} 是否在多边形内
     */
    static isPointInPolygon(point, polygon) {
        const x = point[0], z = point[1];
        let inside = false;

        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const xi = polygon[i][0], zi = polygon[i][1];
            const xj = polygon[j][0], zj = polygon[j][1];

            if (((zi > z) !== (zj > z)) && (x < (xj - xi) * (z - zi) / (zj - zi) + xi)) {
                inside = !inside;
            }
        }

        return inside;
    }

    /**
     * 计算两个多边形之间的最小距离
     * @param {Array} polygon1 - 多边形1
     * @param {Array} polygon2 - 多边形2
     * @returns {number} 最小距离
     */
    static calculatePolygonDistance(polygon1, polygon2) {
        let minDistance = Infinity;

        for (const point1 of polygon1) {
            for (const point2 of polygon2) {
                const distance = Math.sqrt(
                    Math.pow(point1[0] - point2[0], 2) +
                    Math.pow(point1[1] - point2[1], 2)
                );
                minDistance = Math.min(minDistance, distance);
            }
        }

        return minDistance;
    }

    /**
     * 检测两个多边形是否相交
     * @param {Array} polygon1 - 多边形1
     * @param {Array} polygon2 - 多边形2
     * @returns {boolean} 是否相交
     */
    static polygonsIntersect(polygon1, polygon2) {
        // 检查边界框是否相交
        const bounds1 = this.calculatePolygonBounds(polygon1);
        const bounds2 = this.calculatePolygonBounds(polygon2);

        if (!bounds1 || !bounds2) return false;

        // 边界框不相交则多边形不相交
        if (bounds1.maxX < bounds2.minX || bounds2.maxX < bounds1.minX ||
            bounds1.maxZ < bounds2.minZ || bounds2.maxZ < bounds1.minZ) {
            return false;
        }

        // 检查是否有顶点在对方多边形内
        for (const point of polygon1) {
            if (this.isPointInPolygon(point, polygon2)) {
                return true;
            }
        }

        for (const point of polygon2) {
            if (this.isPointInPolygon(point, polygon1)) {
                return true;
            }
        }

        // 检查边是否相交
        return this.edgesIntersect(polygon1, polygon2);
    }

    /**
     * 检查两个多边形的边是否相交
     * @param {Array} polygon1 - 多边形1
     * @param {Array} polygon2 - 多边形2
     * @returns {boolean} 边是否相交
     */
    static edgesIntersect(polygon1, polygon2) {
        for (let i = 0; i < polygon1.length; i++) {
            const p1 = polygon1[i];
            const p2 = polygon1[(i + 1) % polygon1.length];

            for (let j = 0; j < polygon2.length; j++) {
                const p3 = polygon2[j];
                const p4 = polygon2[(j + 1) % polygon2.length];

                if (this.lineSegmentsIntersect(p1, p2, p3, p4)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查两条线段是否相交
     * @param {Array} p1 - 线段1起点
     * @param {Array} p2 - 线段1终点
     * @param {Array} p3 - 线段2起点
     * @param {Array} p4 - 线段2终点
     * @returns {boolean} 是否相交
     */
    static lineSegmentsIntersect(p1, p2, p3, p4) {
        const d1 = this.crossProduct(p3, p4, p1);
        const d2 = this.crossProduct(p3, p4, p2);
        const d3 = this.crossProduct(p1, p2, p3);
        const d4 = this.crossProduct(p1, p2, p4);

        if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
            ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) {
            return true;
        }

        // 检查共线情况
        if (d1 === 0 && this.pointOnSegment(p3, p1, p4)) return true;
        if (d2 === 0 && this.pointOnSegment(p3, p2, p4)) return true;
        if (d3 === 0 && this.pointOnSegment(p1, p3, p2)) return true;
        if (d4 === 0 && this.pointOnSegment(p1, p4, p2)) return true;

        return false;
    }

    /**
     * 检查点是否在线段上
     * @param {Array} p - 起点
     * @param {Array} q - 检查点
     * @param {Array} r - 终点
     * @returns {boolean} 是否在线段上
     */
    static pointOnSegment(p, q, r) {
        return q[0] <= Math.max(p[0], r[0]) && q[0] >= Math.min(p[0], r[0]) &&
               q[1] <= Math.max(p[1], r[1]) && q[1] >= Math.min(p[1], r[1]);
    }

    /**
     * 计算两个多边形的交集边界框
     * @param {Array} polygon1 - 多边形1
     * @param {Array} polygon2 - 多边形2
     * @returns {Object|null} 交集边界框
     */
    static calculateIntersectionBounds(polygon1, polygon2) {
        const bounds1 = this.calculatePolygonBounds(polygon1);
        const bounds2 = this.calculatePolygonBounds(polygon2);

        if (!bounds1 || !bounds2) return null;

        const minX = Math.max(bounds1.minX, bounds2.minX);
        const maxX = Math.min(bounds1.maxX, bounds2.maxX);
        const minZ = Math.max(bounds1.minZ, bounds2.minZ);
        const maxZ = Math.min(bounds1.maxZ, bounds2.maxZ);

        if (minX >= maxX || minZ >= maxZ) return null;

        return { minX, maxX, minZ, maxZ };
    }

    /**
     * 计算点到多边形边界的最短距离
     * @param {Array} point - 点坐标 [x, z]
     * @param {Array} polygon - 多边形坐标数组
     * @returns {number} 最短距离
     */
    static pointToPolygonDistance(point, polygon) {
        if (polygon.length === 0) return Infinity;

        let minDistance = Infinity;

        for (let i = 0; i < polygon.length; i++) {
            const p1 = polygon[i];
            const p2 = polygon[(i + 1) % polygon.length];
            const distance = this.pointToLineSegmentDistance(point, p1, p2);
            minDistance = Math.min(minDistance, distance);
        }

        return minDistance;
    }

    /**
     * 计算点到线段的最短距离
     * @param {Array} point - 点坐标 [x, z]
     * @param {Array} lineStart - 线段起点
     * @param {Array} lineEnd - 线段终点
     * @returns {number} 最短距离
     */
    static pointToLineSegmentDistance(point, lineStart, lineEnd) {
        const [px, pz] = point;
        const [x1, z1] = lineStart;
        const [x2, z2] = lineEnd;

        const A = px - x1;
        const B = pz - z1;
        const C = x2 - x1;
        const D = z2 - z1;

        const dot = A * C + B * D;
        const lenSq = C * C + D * D;

        if (lenSq === 0) {
            // 线段退化为点
            return Math.sqrt(A * A + B * B);
        }

        let param = dot / lenSq;

        let xx, zz;
        if (param < 0) {
            xx = x1;
            zz = z1;
        } else if (param > 1) {
            xx = x2;
            zz = z2;
        } else {
            xx = x1 + param * C;
            zz = z1 + param * D;
        }

        const dx = px - xx;
        const dz = pz - zz;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * 执行多边形与多边形的差集运算（使用Turf.js）
     * @param {Array} subjectPolygon - 主多边形（被减数）
     * @param {Array|Object} clippingPolygonOrRect - 裁剪多边形或矩形区域
     * @returns {Object} 差集结果 {success: boolean, polygons: Array, error?: string}
     */
    static subtractPolygonFromPolygon(subjectPolygon, clippingPolygonOrRect) {
        if (!subjectPolygon || subjectPolygon.length < 3) {
            return { success: false, polygons: [], error: '主多边形无效' };
        }
        if (!clippingPolygonOrRect) {
            return { success: true, polygons: [subjectPolygon] };
        }

        console.log(`🔧 使用Turf.js执行精确多边形差集运算`);
        console.log(`   主多边形: ${subjectPolygon.length} 个顶点`);

        // 转换为GeoJSON格式
        const subjectGeoJSON = this.coordinatesToGeoJSON(subjectPolygon);
        const clippingGeoJSON = this.coordinatesToGeoJSON(clippingPolygonOrRect);

        if (!subjectGeoJSON || !clippingGeoJSON) {
            return { success: false, polygons: [], error: 'GeoJSON转换失败' };
        }

        // 使用Turf.js进行差集运算
        const differenceResult = turf.difference(subjectGeoJSON, clippingGeoJSON);

        // 处理差集结果
        if (!differenceResult) {
            console.log(`⚠️ 差集运算结果为空（完全被移除）`);
            return { success: true, polygons: [] };
        }

        // 转换回坐标格式
        const polygons = this.geoJSONToCoordinates(differenceResult);

        console.log(`✅ Turf.js差集运算完成: 生成 ${polygons.length} 个多边形`);
        return { success: true, polygons };
    }

    /**
     * 将坐标数组转换为GeoJSON Polygon格式
     * @param {Array|Object} coordinatesOrRect - 坐标数组或矩形对象
     * @returns {Object|null} GeoJSON Polygon对象
     */
    static coordinatesToGeoJSON(coordinatesOrRect) {
        try {
            let coordinates;

            // 处理矩形对象
            if (coordinatesOrRect.minX !== undefined) {
                const { minX, maxX, minZ, maxZ } = coordinatesOrRect;
                coordinates = [
                    [minX, minZ],
                    [maxX, minZ],
                    [maxX, maxZ],
                    [minX, maxZ],
                    [minX, minZ] // 闭合多边形
                ];
            } else if (Array.isArray(coordinatesOrRect)) {
                coordinates = [...coordinatesOrRect];
                // 确保多边形闭合
                if (coordinates.length > 0) {
                    const first = coordinates[0];
                    const last = coordinates[coordinates.length - 1];
                    if (first[0] !== last[0] || first[1] !== last[1]) {
                        coordinates.push([first[0], first[1]]);
                    }
                }
            } else {
                return null;
            }

            // 转换为GeoJSON格式（注意：GeoJSON使用[lng, lat]格式，这里我们使用[x, z]）
            return turf.polygon([coordinates]);
        } catch (error) {
            console.error('坐标转换为GeoJSON失败:', error);
            return null;
        }
    }

    /**
     * 将GeoJSON结果转换回坐标数组格式
     * @param {Object} geoJSONResult - GeoJSON对象
     * @returns {Array} 多边形坐标数组
     */
    static geoJSONToCoordinates(geoJSONResult) {
        const polygons = [];

        try {
            if (!geoJSONResult || !geoJSONResult.geometry) {
                return polygons;
            }

            const { type, coordinates } = geoJSONResult.geometry;

            if (type === 'Polygon') {
                // 单个多边形，取外环（第一个坐标数组）
                if (coordinates && coordinates.length > 0) {
                    const outerRing = coordinates[0];
                    if (outerRing.length >= 4) { // 至少4个点（包括闭合点）
                        // 移除最后一个闭合点
                        const coords = outerRing.slice(0, -1);
                        polygons.push(coords);
                    }

                    // 处理内环（空洞）- 如果需要的话
                    for (let i = 1; i < coordinates.length; i++) {
                        const innerRing = coordinates[i];
                        if (innerRing.length >= 4) {
                            const coords = innerRing.slice(0, -1);
                            // 这里可以根据需要处理空洞
                            console.log(`检测到多边形空洞: ${coords.length} 个顶点`);
                        }
                    }
                }
            } else if (type === 'MultiPolygon') {
                // 多个多边形
                for (const polygonCoords of coordinates) {
                    if (polygonCoords && polygonCoords.length > 0) {
                        const outerRing = polygonCoords[0];
                        if (outerRing.length >= 4) {
                            const coords = outerRing.slice(0, -1);
                            polygons.push(coords);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('GeoJSON转换为坐标失败:', error);
        }

        return polygons;
    }

    /**
     * 将坐标数组转换为GeoJSON Polygon格式
     * @param {Array|Object} coordinatesOrRect - 坐标数组或矩形对象
     * @returns {Object|null} GeoJSON Polygon对象
     */
    static coordinatesToGeoJSON(coordinatesOrRect) {
        let coordinates;

        // 处理矩形对象
        if (coordinatesOrRect.minX !== undefined) {
            const { minX, maxX, minZ, maxZ } = coordinatesOrRect;
            coordinates = [
                [minX, minZ],
                [maxX, minZ],
                [maxX, maxZ],
                [minX, maxZ],
                [minX, minZ] // 闭合多边形
            ];
        } else if (Array.isArray(coordinatesOrRect)) {
            coordinates = [...coordinatesOrRect];
            // 确保多边形闭合
            if (coordinates.length > 0) {
                const first = coordinates[0];
                const last = coordinates[coordinates.length - 1];
                if (first[0] !== last[0] || first[1] !== last[1]) {
                    coordinates.push([first[0], first[1]]);
                }
            }
        } else {
            return null;
        }

        // 转换为GeoJSON格式
        return turf.polygon([coordinates]);
    }

    /**
     * 将GeoJSON结果转换回坐标数组格式
     * @param {Object} geoJSONResult - GeoJSON对象
     * @returns {Array} 多边形坐标数组
     */
    static geoJSONToCoordinates(geoJSONResult) {
        const polygons = [];

        if (!geoJSONResult || !geoJSONResult.geometry) {
            return polygons;
        }

        const { type, coordinates } = geoJSONResult.geometry;

        if (type === 'Polygon') {
            // 单个多边形，取外环（第一个坐标数组）
            if (coordinates && coordinates.length > 0) {
                const outerRing = coordinates[0];
                if (outerRing.length >= 4) { // 至少4个点（包括闭合点）
                    // 移除最后一个闭合点
                    const coords = outerRing.slice(0, -1);
                    polygons.push(coords);
                }
            }
        } else if (type === 'MultiPolygon') {
            // 多个多边形
            for (const polygonCoords of coordinates) {
                if (polygonCoords && polygonCoords.length > 0) {
                    const outerRing = polygonCoords[0];
                    if (outerRing.length >= 4) {
                        const coords = outerRing.slice(0, -1);
                        polygons.push(coords);
                    }
                }
            }
        }

        return polygons;
    }

    /**
     * 计算两个多边形的真实几何交集（使用Turf.js）
     * @param {Array} polygon1 - 多边形1
     * @param {Array} polygon2 - 多边形2
     * @returns {Object} 交集结果 {success: boolean, intersection: Array|null, bounds: Object|null}
     */
    static calculatePolygonIntersection(polygon1, polygon2) {
        if (!polygon1 || !polygon2 || polygon1.length < 3 || polygon2.length < 3) {
            return { success: false, intersection: null, bounds: null };
        }

        console.log(`🔧 使用Turf.js计算多边形真实交集`);
        console.log(`   多边形1: ${polygon1.length} 个顶点`);
        console.log(`   多边形2: ${polygon2.length} 个顶点`);

        // 转换为GeoJSON格式
        const geoJSON1 = this.coordinatesToGeoJSON(polygon1);
        const geoJSON2 = this.coordinatesToGeoJSON(polygon2);

        if (!geoJSON1 || !geoJSON2) {
            return { success: false, intersection: null, bounds: null, error: 'GeoJSON转换失败' };
        }

        // 使用Turf.js进行交集运算
        const intersectionResult = turf.intersect(geoJSON1, geoJSON2);

        if (!intersectionResult) {
            console.log(`⚠️ 多边形无交集`);
            return { success: true, intersection: null, bounds: null };
        }

        // 转换回坐标格式
        const intersections = this.geoJSONToCoordinates(intersectionResult);

        if (intersections.length === 0) {
            return { success: true, intersection: null, bounds: null };
        }

        // 取第一个交集多边形
        const intersection = intersections[0];
        const bounds = this.calculatePolygonBounds(intersection);

        console.log(`✅ 多边形交集计算完成: ${intersection.length} 个顶点`);
        return { success: true, intersection, bounds };
    }

    /**
     * 执行多边形与矩形的差集运算（向后兼容）
     * @param {Array} polygon - 原始多边形
     * @param {Object} removeRect - 要移除的矩形区域 {minX, maxX, minZ, maxZ}
     * @returns {Array} 差集后的多边形
     */
    static subtractRectangleFromPolygon(polygon, removeRect) {
        const result = this.subtractPolygonFromPolygon(polygon, removeRect);

        if (result.success && result.polygons.length > 0) {
            // 返回第一个多边形（向后兼容）
            return result.polygons[0];
        }

        return [];
    }

    /**
     * 保守的多边形差集运算（备用方案）
     * @param {Array} polygon - 原始多边形
     * @param {Object} removeRect - 要移除的矩形区域
     * @returns {Array} 差集后的多边形
     */
    static conservativeSubtractRectangle(polygon, removeRect) {
        console.log(`🛡️ 执行保守的多边形差集运算`);

        // 简单过滤：移除在矩形内的顶点
        const filteredPolygon = polygon.filter(vertex => {
            const [x, z] = vertex;
            return !(x >= removeRect.minX && x <= removeRect.maxX &&
                    z >= removeRect.minZ && z <= removeRect.maxZ);
        });

        if (filteredPolygon.length < 3) {
            console.log(`⚠️ 保守策略后顶点不足，保持原多边形`);
            return polygon;
        }

        console.log(`✅ 保守差集完成: ${polygon.length} → ${filteredPolygon.length} 个顶点`);
        return filteredPolygon;
    }

    // 注意：createNonOverlappingRectangles 方法已被删除
    // 现在使用 Martinez 库进行精确的多边形布尔运算

    /**
     * 检查点是否在矩形内
     * @param {Array} point - 点坐标 [x, z]
     * @param {Object} rect - 矩形 {minX, maxX, minZ, maxZ}
     * @returns {boolean} 是否在矩形内
     */
    static isPointInRectangle(point, rect) {
        const [x, z] = point;
        return x >= rect.minX && x <= rect.maxX && z >= rect.minZ && z <= rect.maxZ;
    }

    /**
     * 找到线段与矩形的交点
     * @param {Array} lineStart - 线段起点
     * @param {Array} lineEnd - 线段终点
     * @param {Object} rect - 矩形
     * @returns {Array} 交点数组
     */
    static findLineRectangleIntersections(lineStart, lineEnd, rect) {
        const intersections = [];

        // 矩形的四条边
        const rectEdges = [
            [[rect.minX, rect.minZ], [rect.maxX, rect.minZ]], // 下边
            [[rect.maxX, rect.minZ], [rect.maxX, rect.maxZ]], // 右边
            [[rect.maxX, rect.maxZ], [rect.minX, rect.maxZ]], // 上边
            [[rect.minX, rect.maxZ], [rect.minX, rect.minZ]]  // 左边
        ];

        for (const edge of rectEdges) {
            const intersection = this.findLineIntersection(lineStart, lineEnd, edge[0], edge[1]);
            if (intersection) {
                intersections.push(intersection);
            }
        }

        // 按距离起点的距离排序
        intersections.sort((a, b) => {
            const distA = Math.pow(a[0] - lineStart[0], 2) + Math.pow(a[1] - lineStart[1], 2);
            const distB = Math.pow(b[0] - lineStart[0], 2) + Math.pow(b[1] - lineStart[1], 2);
            return distA - distB;
        });

        return intersections;
    }

    /**
     * 找到两条线段的交点
     * @param {Array} line1Start - 线段1起点
     * @param {Array} line1End - 线段1终点
     * @param {Array} line2Start - 线段2起点
     * @param {Array} line2End - 线段2终点
     * @returns {Array|null} 交点坐标或null
     */
    static findLineIntersection(line1Start, line1End, line2Start, line2End) {
        const [x1, y1] = line1Start;
        const [x2, y2] = line1End;
        const [x3, y3] = line2Start;
        const [x4, y4] = line2End;

        const denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
        if (Math.abs(denom) < 1e-10) return null; // 平行线

        const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
        const u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom;

        if (t >= 0 && t <= 1 && u >= 0 && u <= 1) {
            return [x1 + t * (x2 - x1), y1 + t * (y2 - y1)];
        }

        return null;
    }

    /**
     * 合并多个多边形区域（使用Martinez库进行精确并集运算）
     * @param {Array} polygons - 多边形数组
     * @param {number} bufferDistance - 缓冲距离（方块单位）
     * @returns {Array} 合并后的多边形
     */
    static mergePolygonRegions(polygons, bufferDistance = 0) {
        if (polygons.length === 0) return [];
        if (polygons.length === 1) {
            return bufferDistance > 0 ? this.bufferPolygon(polygons[0], bufferDistance) : polygons[0];
        }

        console.log(`🔧 使用Martinez库合并 ${polygons.length} 个多边形区域`);

        try {
            // 检查Martinez库是否可用
            if (typeof window.MartinezGeometryUtils !== 'undefined') {
                // 使用Martinez库进行精确的并集运算
                const result = MartinezGeometryUtils.unionPolygons(polygons);

                if (result.length < 3) {
                    console.log(`⚠️ Martinez并集运算结果无效，使用边界框合并`);
                    return this.fallbackMergePolygonRegions(polygons, bufferDistance);
                }

                // 应用缓冲区
                const bufferedResult = bufferDistance > 0 ?
                    MartinezGeometryUtils.bufferPolygon(result, bufferDistance) : result;

                console.log(`✅ Martinez区域合并完成: 结果 ${bufferedResult.length} 个顶点`);
                return bufferedResult;
            } else {
                console.log(`⚠️ Martinez库未加载，使用边界框合并`);
                return this.fallbackMergePolygonRegions(polygons, bufferDistance);
            }

        } catch (error) {
            console.error(`❌ Martinez区域合并失败，回退到边界框合并:`, error);
            return this.fallbackMergePolygonRegions(polygons, bufferDistance);
        }
    }

    /**
     * 备用的多边形区域合并方法（使用边界框）
     * @param {Array} polygons - 多边形数组
     * @param {number} bufferDistance - 缓冲距离
     * @returns {Array} 合并后的多边形
     */
    static fallbackMergePolygonRegions(polygons, bufferDistance) {
        console.log(`🛡️ 执行边界框区域合并策略`);

        // 计算所有多边形的总边界框
        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        for (const polygon of polygons) {
            const bounds = this.calculatePolygonBounds(polygon);
            if (bounds) {
                minX = Math.min(minX, bounds.minX);
                maxX = Math.max(maxX, bounds.maxX);
                minZ = Math.min(minZ, bounds.minZ);
                maxZ = Math.max(maxZ, bounds.maxZ);
            }
        }

        // 应用缓冲
        const expandedBounds = {
            minX: minX - bufferDistance,
            maxX: maxX + bufferDistance,
            minZ: minZ - bufferDistance,
            maxZ: maxZ + bufferDistance
        };

        // 创建合并矩形
        const result = [
            [expandedBounds.minX, expandedBounds.minZ],
            [expandedBounds.maxX, expandedBounds.minZ],
            [expandedBounds.maxX, expandedBounds.maxZ],
            [expandedBounds.minX, expandedBounds.maxZ]
        ];

        console.log(`✅ 边界框区域合并完成: 边界 (${expandedBounds.minX}, ${expandedBounds.minZ}) 到 (${expandedBounds.maxX}, ${expandedBounds.maxZ})`);
        return result;
    }

    /**
     * 将多边形对齐到区块网格
     * @param {Array} polygon - 多边形坐标数组
     * @returns {Array} 区块对齐的多边形
     */
    static alignPolygonToChunk(polygon) {
        if (polygon.length === 0) return polygon;

        const bounds = this.calculatePolygonBounds(polygon);
        if (!bounds) return polygon;

        const alignedBounds = this.alignBoundsToChunk(bounds);

        // 返回区块对齐的矩形
        return [
            [alignedBounds.minX, alignedBounds.minZ],
            [alignedBounds.maxX, alignedBounds.minZ],
            [alignedBounds.maxX, alignedBounds.maxZ],
            [alignedBounds.minX, alignedBounds.maxZ]
        ];
    }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GeometryUtils;
} else if (typeof window !== 'undefined') {
    window.GeometryUtils = GeometryUtils;
}
