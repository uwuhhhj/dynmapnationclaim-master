/**
 * Martinez多边形几何运算工具类
 * 基于martinez-polygon-clipping库实现精确的多边形布尔运算
 * 替换原有的简化几何运算方法
 */
class MartinezGeometryUtils {
    
    /**
     * 初始化检查Martinez库是否可用
     */
    static checkMartinezAvailability() {
        if (typeof window.MartinezPolygonClipping === 'undefined') {
            throw new Error('Martinez Polygon Clipping库未加载，请确保bundle.js已正确加载');
        }
        return true;
    }

    /**
     * 将坐标点数组转换为Martinez格式的多边形
     * @param {Array} coordinates - 坐标点数组 [[x1, z1], [x2, z2], ...]
     * @returns {Array} Martinez格式的多边形 [[[x1, z1], [x2, z2], ...]]
     */
    static coordinatesToMartinezPolygon(coordinates) {
        if (!coordinates || coordinates.length < 3) {
            throw new Error('多边形至少需要3个顶点');
        }
        
        // 确保多边形是封闭的
        const polygon = [...coordinates];
        const first = polygon[0];
        const last = polygon[polygon.length - 1];
        
        if (first[0] !== last[0] || first[1] !== last[1]) {
            polygon.push([first[0], first[1]]);
        }
        
        return [polygon];
    }

    /**
     * 将矩形边界转换为Martinez格式的多边形
     * @param {Object} bounds - 边界对象 {minX, maxX, minZ, maxZ}
     * @returns {Array} Martinez格式的多边形
     */
    static boundsToMartinezPolygon(bounds) {
        const { minX, maxX, minZ, maxZ } = bounds;
        return [[[minX, minZ], [maxX, minZ], [maxX, maxZ], [minX, maxZ], [minX, minZ]]];
    }

    /**
     * 将Martinez结果转换回坐标点数组
     * @param {Array} martinezResult - Martinez运算结果
     * @returns {Array} 坐标点数组，如果有多个多边形则返回最大的一个
     */
    static martinezResultToCoordinates(martinezResult) {
        if (!martinezResult || martinezResult.length === 0) {
            return [];
        }

        // 如果有多个多边形，选择面积最大的
        let largestPolygon = martinezResult[0][0];
        let largestArea = this.calculatePolygonArea(largestPolygon);

        for (const multiPolygon of martinezResult) {
            for (const polygon of multiPolygon) {
                const area = this.calculatePolygonArea(polygon);
                if (area > largestArea) {
                    largestArea = area;
                    largestPolygon = polygon;
                }
            }
        }

        // 移除最后一个重复的顶点（如果存在）
        const result = [...largestPolygon];
        if (result.length > 3) {
            const first = result[0];
            const last = result[result.length - 1];
            if (first[0] === last[0] && first[1] === last[1]) {
                result.pop();
            }
        }

        return result;
    }

    /**
     * 计算多边形面积
     * @param {Array} polygon - 多边形顶点数组
     * @returns {number} 面积
     */
    static calculatePolygonArea(polygon) {
        if (!polygon || polygon.length < 3) return 0;
        
        let area = 0;
        const n = polygon.length;
        
        for (let i = 0; i < n; i++) {
            const j = (i + 1) % n;
            area += polygon[i][0] * polygon[j][1];
            area -= polygon[j][0] * polygon[i][1];
        }
        
        return Math.abs(area) / 2;
    }

    /**
     * 多边形差集运算 - 从subject中减去clipping
     * @param {Array} subjectCoords - 主多边形坐标
     * @param {Array|Object} clippingCoordsOrBounds - 要减去的多边形坐标或边界对象
     * @returns {Array} 差集结果坐标
     */
    static subtractPolygon(subjectCoords, clippingCoordsOrBounds) {
        this.checkMartinezAvailability();

        try {
            const subject = this.coordinatesToMartinezPolygon(subjectCoords);
            
            let clipping;
            if (clippingCoordsOrBounds.minX !== undefined) {
                // 是边界对象，转换为多边形
                clipping = this.boundsToMartinezPolygon(clippingCoordsOrBounds);
            } else {
                // 是坐标数组
                clipping = this.coordinatesToMartinezPolygon(clippingCoordsOrBounds);
            }

            console.log(`🔧 Martinez差集运算: 主多边形${subjectCoords.length}顶点`);
            
            const result = window.MartinezPolygonClipping.difference(subject, clipping);
            
            if (!result || result.length === 0) {
                console.log(`⚠️ 差集运算结果为空，返回原多边形`);
                return subjectCoords;
            }

            const coordinates = this.martinezResultToCoordinates(result);
            console.log(`✅ Martinez差集运算完成: 结果${coordinates.length}顶点`);
            
            return coordinates.length >= 3 ? coordinates : subjectCoords;
            
        } catch (error) {
            console.error(`❌ Martinez差集运算失败:`, error);
            return subjectCoords; // 失败时返回原多边形
        }
    }

    /**
     * 多边形并集运算
     * @param {Array} polygons - 多边形坐标数组的数组
     * @returns {Array} 并集结果坐标
     */
    static unionPolygons(polygons) {
        this.checkMartinezAvailability();

        if (!polygons || polygons.length === 0) return [];
        if (polygons.length === 1) return polygons[0];

        try {
            console.log(`🔧 Martinez并集运算: 合并${polygons.length}个多边形`);
            
            let result = this.coordinatesToMartinezPolygon(polygons[0]);
            
            for (let i = 1; i < polygons.length; i++) {
                const nextPolygon = this.coordinatesToMartinezPolygon(polygons[i]);
                result = window.MartinezPolygonClipping.union(result, nextPolygon);
                
                if (!result || result.length === 0) {
                    console.warn(`⚠️ 第${i}次并集运算结果为空`);
                    break;
                }
            }

            if (!result || result.length === 0) {
                console.log(`⚠️ 并集运算结果为空，返回最大多边形`);
                return this.getLargestPolygon(polygons);
            }

            const coordinates = this.martinezResultToCoordinates(result);
            console.log(`✅ Martinez并集运算完成: 结果${coordinates.length}顶点`);
            
            return coordinates;
            
        } catch (error) {
            console.error(`❌ Martinez并集运算失败:`, error);
            return this.getLargestPolygon(polygons); // 失败时返回最大的多边形
        }
    }

    /**
     * 多边形交集运算
     * @param {Array} polygon1Coords - 多边形1坐标
     * @param {Array} polygon2Coords - 多边形2坐标
     * @returns {Array} 交集结果坐标
     */
    static intersectPolygons(polygon1Coords, polygon2Coords) {
        this.checkMartinezAvailability();

        try {
            const polygon1 = this.coordinatesToMartinezPolygon(polygon1Coords);
            const polygon2 = this.coordinatesToMartinezPolygon(polygon2Coords);

            console.log(`🔧 Martinez交集运算`);
            
            const result = window.MartinezPolygonClipping.intersection(polygon1, polygon2);
            
            if (!result || result.length === 0) {
                console.log(`⚠️ 交集运算结果为空`);
                return [];
            }

            const coordinates = this.martinezResultToCoordinates(result);
            console.log(`✅ Martinez交集运算完成: 结果${coordinates.length}顶点`);
            
            return coordinates;
            
        } catch (error) {
            console.error(`❌ Martinez交集运算失败:`, error);
            return [];
        }
    }

    /**
     * 多边形异或运算
     * @param {Array} polygon1Coords - 多边形1坐标
     * @param {Array} polygon2Coords - 多边形2坐标
     * @returns {Array} 异或结果坐标
     */
    static xorPolygons(polygon1Coords, polygon2Coords) {
        this.checkMartinezAvailability();

        try {
            const polygon1 = this.coordinatesToMartinezPolygon(polygon1Coords);
            const polygon2 = this.coordinatesToMartinezPolygon(polygon2Coords);

            console.log(`🔧 Martinez异或运算`);
            
            const result = window.MartinezPolygonClipping.xor(polygon1, polygon2);
            
            if (!result || result.length === 0) {
                console.log(`⚠️ 异或运算结果为空`);
                return [];
            }

            const coordinates = this.martinezResultToCoordinates(result);
            console.log(`✅ Martinez异或运算完成: 结果${coordinates.length}顶点`);
            
            return coordinates;
            
        } catch (error) {
            console.error(`❌ Martinez异或运算失败:`, error);
            return [];
        }
    }

    /**
     * 从多边形数组中获取面积最大的多边形
     * @param {Array} polygons - 多边形数组
     * @returns {Array} 最大的多边形
     */
    static getLargestPolygon(polygons) {
        if (!polygons || polygons.length === 0) return [];
        if (polygons.length === 1) return polygons[0];

        let largest = polygons[0];
        let largestArea = this.calculatePolygonArea(largest);

        for (let i = 1; i < polygons.length; i++) {
            const area = this.calculatePolygonArea(polygons[i]);
            if (area > largestArea) {
                largestArea = area;
                largest = polygons[i];
            }
        }

        return largest;
    }

    /**
     * 检查两个多边形是否相交
     * @param {Array} polygon1Coords - 多边形1坐标
     * @param {Array} polygon2Coords - 多边形2坐标
     * @returns {boolean} 是否相交
     */
    static polygonsIntersect(polygon1Coords, polygon2Coords) {
        try {
            const intersection = this.intersectPolygons(polygon1Coords, polygon2Coords);
            return intersection.length > 0;
        } catch (error) {
            console.error(`❌ 多边形相交检测失败:`, error);
            return false;
        }
    }

    /**
     * 应用缓冲区到多边形（简化实现）
     * @param {Array} polygonCoords - 多边形坐标
     * @param {number} bufferDistance - 缓冲距离
     * @returns {Array} 缓冲后的多边形坐标
     */
    static bufferPolygon(polygonCoords, bufferDistance) {
        if (!polygonCoords || polygonCoords.length < 3 || bufferDistance <= 0) {
            return polygonCoords;
        }

        // 简化实现：计算边界框并扩展
        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        for (const [x, z] of polygonCoords) {
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minZ = Math.min(minZ, z);
            maxZ = Math.max(maxZ, z);
        }

        return [
            [minX - bufferDistance, minZ - bufferDistance],
            [maxX + bufferDistance, minZ - bufferDistance],
            [maxX + bufferDistance, maxZ + bufferDistance],
            [minX - bufferDistance, maxZ + bufferDistance]
        ];
    }
}

// 导出到全局作用域
window.MartinezGeometryUtils = MartinezGeometryUtils;
