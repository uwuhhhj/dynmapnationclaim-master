/**
 * Dynmap 领地数据管理器
 * 负责数据的获取、存储、处理和显示
 * 使用 IndexedDB 替代 localStorage 进行数据存储
 */

// 全局变量控制当前显示的数据类型
let currentDataView = 'markers'; // 'markers', 'areas', 'countrySpawn', 'countryAreas'

/**
 * 数据获取和存储模块
 */

// 从服务器获取所有数据并存储到 IndexedDB
async function fetchAndStoreAllData() {
  try {
    console.log('🔄 开始获取所有数据...');

    // 硬编码数据源URL
    const dataUrl = 'https://map.simmc.cc/tiles/_markers_/marker_world.json';

    console.log('📡 使用数据源:', dataUrl);

    // 从指定 URL 获取 JSON 数据
    const response = await fetch(dataUrl);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const jsonData = await response.json();
    console.log('📥 原始数据获取成功:', jsonData);

    let markersCount = 0;
    let areasCount = 0;

    // 检查并处理 markers 数据
    if (jsonData.sets && jsonData.sets["me.angeschossen.lands"] && jsonData.sets["me.angeschossen.lands"].markers) {
      const markers = jsonData.sets["me.angeschossen.lands"].markers;
      await IndexedDBStorage.setItem("landMarkers", JSON.stringify(markers));
      markersCount = Object.keys(markers).length;
      console.log(`✅ Markers 已保存到 IndexedDB (${markersCount} 个)`);
    }

    // 检查并处理 areas 数据
    if (jsonData.sets && jsonData.sets["me.angeschossen.lands"] && jsonData.sets["me.angeschossen.lands"].areas) {
      const areas = jsonData.sets["me.angeschossen.lands"].areas;
      await IndexedDBStorage.setItem("landAreas", JSON.stringify(areas));
      areasCount = Object.keys(areas).length;
      console.log(`✅ Areas 已保存到 IndexedDB (${areasCount} 个)`);
    }

    // 处理国家分组数据
    if (markersCount > 0 || areasCount > 0) {
      await processCountryData();
    }

    // 显示成功信息
    if (markersCount > 0 || areasCount > 0) {
      displayStorageStatus('success', `成功存储 ${markersCount} 个标记和 ${areasCount} 个区域到 IndexedDB`);

      // 更新页面显示
      await updateDataDisplay();
    } else {
      console.warn('⚠️ 数据结构不符合预期，无法提取数据');
      displayStorageStatus('warning', '数据结构不符合预期，无法提取数据');
    }

  } catch (error) {
    console.error('❌ 获取或存储数据时出错:', error);
    displayStorageStatus('error', `获取数据失败: ${error.message}`);
  }
}

// 获取存储的标记数据
async function getStoredMarkers() {
  try {
    const storedMarkers = await IndexedDBStorage.getItem("landMarkers");
    return storedMarkers ? JSON.parse(storedMarkers) : null;
  } catch (error) {
    console.error('❌ 获取标记数据失败:', error);
    return null;
  }
}

// 获取存储的区域数据
async function getStoredAreas() {
  try {
    const storedAreas = await IndexedDBStorage.getItem("landAreas");
    return storedAreas ? JSON.parse(storedAreas) : null;
  } catch (error) {
    console.error('❌ 获取区域数据失败:', error);
    return null;
  }
}

/**
 * 国家数据处理模块
 */

// 处理国家分组数据
async function processCountryData() {
  console.log('🏛️ 开始处理国家分组数据...');

  const markers = await getStoredMarkers();
  const areas = await getStoredAreas();

  if (!markers && !areas) {
    console.warn('⚠️ 没有找到标记或区域数据，跳过国家分组处理');
    return;
  }

  // 存储国家对应的数据
  const countrySpawn = {};
  const countryAreas = {};

  // 处理标记数据
  if (markers) {
    for (const [key, marker] of Object.entries(markers)) {
      const countryName = extractCountryFromDesc(marker.desc);
      if (countryName) {
        if (!countrySpawn[countryName]) {
          countrySpawn[countryName] = {
            spawns: []  // 添加 spawns 数组字段
          };
        }

        // 将标记数据转换为出生点格式并添加到 spawns 数组
        if (marker.x !== undefined && marker.z !== undefined) {
          countrySpawn[countryName].spawns.push({
            x: marker.x,
            z: marker.z,
            y: marker.y || 64, // 默认 Y 坐标
            name: marker.label || key,
            markerId: key,
            markerData: marker
          });
        }

        // 保持原有的标记数据结构以兼容其他功能
        countrySpawn[countryName][key] = marker;
      }
    }
  }

  // 处理区域数据
  if (areas) {
    console.log(`🔍 开始处理区域数据，总数: ${Object.keys(areas).length}`);

    for (const [key, area] of Object.entries(areas)) {
      let countryName = null;

      // 首先尝试从 markup 字段提取
      if (area.markup) {
        countryName = extractCountryFromDesc(area.markup);
      }

      // 如果 markup 没有找到，尝试从 desc 字段提取
      if (!countryName && area.desc) {
        countryName = extractCountryFromDesc(area.desc);
      }

      // 如果 desc 也没有找到，尝试从 label 字段提取
      if (!countryName && area.label) {
        countryName = extractCountryFromDesc(area.label);
      }

      if (countryName) {
        if (!countryAreas[countryName]) {
          countryAreas[countryName] = {};
        }
        countryAreas[countryName][key] = area;
        console.log(`✅ 区域 ${key} 归属国家: ${countryName}`);
      } else {
        console.log(`⚠️ 区域 ${key} 未找到国家信息 - markup: "${area.markup}", desc: "${area.desc}", label: "${area.label}"`);
      }
    }
  }

  // 存储到 IndexedDB
  try {
    await IndexedDBStorage.setItem("countrySpawn", JSON.stringify(countrySpawn));
    await IndexedDBStorage.setItem("countryAreas", JSON.stringify(countryAreas));

    const spawnCountriesCount = Object.keys(countrySpawn).length;
    const areasCountriesCount = Object.keys(countryAreas).length;

    console.log(`✅ 国家分组完成: ${spawnCountriesCount} 个国家的标记数据, ${areasCountriesCount} 个国家的区域数据`);

    // 输出详细信息
    if (spawnCountriesCount > 0) {
      console.log('📍 国家标记分组:', countrySpawn);
    }
    if (areasCountriesCount > 0) {
      console.log('🏘️ 国家区域分组:', countryAreas);
    }
  } catch (error) {
    console.error('❌ 保存国家分组数据失败:', error);
  }
}

// 从描述文本中提取国家名称
function extractCountryFromDesc(desc) {
  if (!desc || typeof desc !== 'string') {
    return null;
  }

  // 清理HTML标签
  const cleanDesc = desc.replace(/<[^>]*>/g, '').trim();

  // 查找"这片领土属于国家XXX:"模式，提取"这片领土属于国家"和":"之间的内容
  const countryMatch = cleanDesc.match(/这片领土属于国家([^：:]+)[:：]/);

  if (countryMatch && countryMatch[1]) {
    const countryName = countryMatch[1].trim();
    console.log(`✅ 成功提取国家名称: "${cleanDesc}" -> "${countryName}"`);
    return countryName;
  }

  // 如果没有匹配到，记录调试信息
  console.log(`❌ 未能提取国家名称: "${cleanDesc}"`);
  return null;
}

// 获取存储的国家标记数据
async function getStoredCountrySpawn() {
  try {
    const storedData = await IndexedDBStorage.getItem("countrySpawn");
    if (!storedData) return null;

    return JSON.parse(storedData);
  } catch (error) {
    console.error('❌ 获取国家标记数据失败:', error);
    return null;
  }
}



// 获取存储的国家区域数据
async function getStoredCountryAreas() {
  try {
    const storedData = await IndexedDBStorage.getItem("countryAreas");
    return storedData ? JSON.parse(storedData) : null;
  } catch (error) {
    console.error('❌ 获取国家区域数据失败:', error);
    return null;
  }
}

// 存储国家宣称区域数据
async function setStoredCountryClaims(countryClaimsData) {
  try {
    await IndexedDBStorage.setItem("countryClaims", JSON.stringify(countryClaimsData));
    console.log('✅ 国家宣称区域数据已保存到 IndexedDB');
  } catch (error) {
    console.error('❌ 保存国家宣称区域数据失败:', error);
    throw error;
  }
}

// 获取存储的国家宣称区域数据
async function getStoredCountryClaims() {
  try {
    const storedData = await IndexedDBStorage.getItem("countryClaims");
    return storedData ? JSON.parse(storedData) : null;
  } catch (error) {
    console.error('❌ 获取国家宣称区域数据失败:', error);
    return null;
  }
}

// 存储宣称生成配置
async function setStoredClaimsConfig(configData) {
  try {
    await IndexedDBStorage.setItem("claimsConfig", JSON.stringify(configData));
    console.log('✅ 宣称生成配置已保存到 IndexedDB');
  } catch (error) {
    console.error('❌ 保存宣称生成配置失败:', error);
    throw error;
  }
}

// 获取存储的宣称生成配置
async function getStoredClaimsConfig() {
  try {
    const storedData = await IndexedDBStorage.getItem("claimsConfig");
    return storedData ? JSON.parse(storedData) : null;
  } catch (error) {
    console.error('❌ 获取宣称生成配置失败:', error);
    return null;
  }
}

// 清除存储的国家宣称区域数据
async function clearStoredCountryClaims() {
  try {
    // 删除主要的宣称数据
    await IndexedDBStorage.removeItem("countryClaims");

    // 验证删除是否成功
    const remainingData = await IndexedDBStorage.getItem("countryClaims");
    if (remainingData === null) {
      console.log('✅ 已成功清除 IndexedDB 中的国家宣称数据');
      return true;
    } else {
      console.error('❌ 删除失败，数据仍然存在');
      return false;
    }
  } catch (error) {
    console.error('❌ 清除国家宣称数据时发生错误:', error);
    return false;
  }
}

// 存储冲突修复后的边界数据
async function setStoredConflictResolvedBoundaries(boundaryData) {
  try {
    await IndexedDBStorage.setItem("conflictResolvedBoundaries", JSON.stringify(boundaryData));
    console.log('✅ 冲突修复后的边界数据已保存到 IndexedDB');
  } catch (error) {
    console.error('❌ 保存冲突修复边界数据失败:', error);
    throw error;
  }
}

// 获取存储的冲突修复后边界数据
async function getStoredConflictResolvedBoundaries() {
  try {
    const storedData = await IndexedDBStorage.getItem("conflictResolvedBoundaries");
    return storedData ? JSON.parse(storedData) : null;
  } catch (error) {
    console.error('❌ 获取冲突修复边界数据失败:', error);
    return null;
  }
}

// 清除存储的冲突修复边界数据
async function clearStoredConflictResolvedBoundaries() {
  try {
    await IndexedDBStorage.removeItem("conflictResolvedBoundaries");

    // 验证删除是否成功
    const remainingData = await IndexedDBStorage.getItem("conflictResolvedBoundaries");
    if (remainingData === null) {
      console.log('✅ 已成功清除 IndexedDB 中的冲突修复边界数据');
      return true;
    } else {
      console.error('❌ 删除失败，数据仍然存在');
      return false;
    }
  } catch (error) {
    console.error('❌ 清除冲突修复边界数据时发生错误:', error);
    return false;
  }
}

// 验证国家宣称数据是否已清除
async function verifyCountryClaimsCleared() {
  try {
    const countryClaims = await IndexedDBStorage.getItem("countryClaims");
    const isCleared = countryClaims === null;

    console.log('🔍 验证国家宣称数据清除状态:', isCleared ? '已清除' : '仍存在');
    if (!isCleared) {
      console.log('📋 剩余数据:', countryClaims);
    }

    return isCleared;
  } catch (error) {
    console.error('❌ 验证清除状态失败:', error);
    return false;
  }
}



/**
 * 数据显示模块
 */

// 更新数据显示
async function updateDataDisplay() {
  if (currentDataView === 'markers') {
    const markers = await getStoredMarkers();
    displayMarkersOnPage(markers);
  } else if (currentDataView === 'areas') {
    const areas = await getStoredAreas();
    displayAreasOnPage(areas);
  } else if (currentDataView === 'countrySpawn') {
    const countrySpawn = await getStoredCountrySpawn();
    displayCountrySpawnOnPage(countrySpawn);
  } else if (currentDataView === 'countryAreas') {
    const countryAreas = await getStoredCountryAreas();
    displayCountryAreasOnPage(countryAreas);
  }
}

// 在页面上显示标记数据的函数
function displayMarkersOnPage(markers) {
  const dataList = document.getElementById('data-list');
  const dataTitle = document.getElementById('data-display-title');
  if (!dataList || !dataTitle) return;

  dataTitle.textContent = '📍 存储的标记数据';

  if (!markers || Object.keys(markers).length === 0) {
    dataList.innerHTML = '<p style="color: #999; font-style: italic;">暂无标记数据</p>';
    return;
  }

  let html = `
    <div style="margin-bottom: 15px; padding: 10px; background-color: #e8f5e8; border-radius: 5px;">
      <strong>📊 总计：${Object.keys(markers).length} 个标记</strong>
    </div>
    <div style="display: grid; gap: 10px;">
  `;

  // 遍历所有标记并创建卡片
  for (const [key, marker] of Object.entries(markers)) {
    const { x, y, z, label, desc, icon, dim } = marker;

    // 清理描述文本（移除HTML标签）
    const cleanDesc = desc ? desc.replace(/<[^>]*>/g, '').trim() : '无描述';

    html += `
      <div style="
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        background-color: #fafafa;
        transition: box-shadow 0.2s;
      " onmouseover="this.style.boxShadow='0 2px 8px rgba(0,0,0,0.1)'" onmouseout="this.style.boxShadow='none'">

        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
          <h4 style="margin: 0; color: #2c3e50; font-size: 16px;">
            🏷️ ${label || '未命名标记'}
          </h4>
          <span style="
            background-color: #3498db;
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            white-space: nowrap;
          ">
            ${icon || 'default'} ${dim || ''}
          </span>
        </div>

        <div style="margin-bottom: 8px;">
          <strong>📍 坐标：</strong>
          <span style="font-family: monospace; background-color: #ecf0f1; padding: 2px 6px; border-radius: 3px;">
            X: ${x}, Y: ${y}, Z: ${z}
          </span>
        </div>

        <div style="margin-bottom: 8px;">
          <strong>🔑 标识：</strong>
          <span style="font-family: monospace; font-size: 12px; color: #7f8c8d;">
            ${key}
          </span>
        </div>

        ${cleanDesc !== '无描述' ? `
          <div style="margin-top: 10px; padding: 8px; background-color: #fff; border-left: 3px solid #3498db; border-radius: 0 4px 4px 0;">
            <strong>📝 描述：</strong><br>
            <span style="color: #555; font-size: 14px;">${cleanDesc}</span>
          </div>
        ` : ''}

      </div>
    `;
  }

  html += '</div>';
  dataList.innerHTML = html;
}

// 在页面上显示区域数据的函数
function displayAreasOnPage(areas) {
  const dataList = document.getElementById('data-list');
  const dataTitle = document.getElementById('data-display-title');
  if (!dataList || !dataTitle) return;

  dataTitle.textContent = '🏘️ 存储的区域数据';

  if (!areas || Object.keys(areas).length === 0) {
    dataList.innerHTML = '<p style="color: #999; font-style: italic;">暂无区域数据</p>';
    return;
  }

  let html = `
    <div style="margin-bottom: 15px; padding: 10px; background-color: #f3e5f5; border-radius: 5px;">
      <strong>📊 总计：${Object.keys(areas).length} 个区域</strong>
    </div>
    <div style="display: grid; gap: 10px;">
  `;

  // 遍历所有区域并创建卡片
  for (const [key, area] of Object.entries(areas)) {
    const { x, z, fillcolor, color, ytop, weight, markup } = area;

    // 计算区域的边界和中心点
    const minX = Math.min(...x);
    const maxX = Math.max(...x);
    const minZ = Math.min(...z);
    const maxZ = Math.max(...z);
    const centerX = Math.round((minX + maxX) / 2);
    const centerZ = Math.round((minZ + maxZ) / 2);
    const pointCount = x.length;

    html += `
      <div style="
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        background-color: #fafafa;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      ">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
          <div>
            <h4 style="margin: 0 0 5px 0; color: #673AB7; font-size: 16px;">
              区域 ${key.split('_')[0]}
            </h4>
            <p style="margin: 0; font-size: 12px; color: #666;">
              ID: ${key}
            </p>
          </div>
          <div style="text-align: right;">
            <div style="
              width: 20px;
              height: 20px;
              background-color: ${fillcolor || '#80AE89'};
              border: 2px solid ${color || '#80AE89'};
              border-radius: 3px;
              display: inline-block;
            "></div>
          </div>
        </div>

        <div style="margin-bottom: 10px;">
          <strong style="color: #333;">中心坐标：</strong>
          <span style="
            font-family: monospace;
            background-color: #f3e5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 13px;
          ">
            X: ${centerX}, Z: ${centerZ}
          </span>
        </div>

        <div style="margin-bottom: 10px;">
          <strong style="color: #333;">边界范围：</strong>
          <span style="
            font-family: monospace;
            background-color: #f3e5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 13px;
          ">
            X: ${minX} ~ ${maxX}, Z: ${minZ} ~ ${maxZ}
          </span>
        </div>

        <div style="margin-bottom: 8px;">
          <strong style="color: #333;">顶点数量：</strong>
          <span style="color: #666; font-size: 14px;">${pointCount} 个</span>
        </div>

        <div style="margin-bottom: 8px;">
          <strong style="color: #333;">Y轴高度：</strong>
          <span style="color: #666; font-size: 14px;">${ytop || 'N/A'}</span>
        </div>

        <div>
          <strong style="color: #333;">边框粗细：</strong>
          <span style="color: #666; font-size: 14px;">${weight || 1}px</span>
        </div>
      </div>
    `;
  }

  html += '</div>';
  dataList.innerHTML = html;
}

// 在页面上显示国家标记数据的函数
function displayCountrySpawnOnPage(countrySpawn) {
  const dataList = document.getElementById('data-list');
  const dataTitle = document.getElementById('data-display-title');
  if (!dataList || !dataTitle) return;

  dataTitle.textContent = '🏛️ 国家标记数据';

  if (!countrySpawn || Object.keys(countrySpawn).length === 0) {
    dataList.innerHTML = '<p style="color: #999; font-style: italic;">暂无国家标记数据</p>';
    return;
  }

  let html = `
    <div style="margin-bottom: 15px; padding: 10px; background-color: #fff3e0; border-radius: 5px;">
      <strong>🏛️ 总计：${Object.keys(countrySpawn).length} 个国家</strong>
    </div>
    <div style="display: grid; gap: 15px;">
  `;

  // 遍历所有国家
  for (const [countryName, countryData] of Object.entries(countrySpawn)) {
    // 计算标记数量（排除 spawns 字段）
    const markerKeys = Object.keys(countryData).filter(key => key !== 'spawns');
    const markersCount = markerKeys.length;
    const spawnsCount = countryData.spawns ? countryData.spawns.length : 0;

    html += `
      <div style="
        border: 2px solid #ff9800;
        border-radius: 12px;
        padding: 20px;
        background-color: #fff8e1;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      ">
        <div style="margin-bottom: 15px; text-align: center;">
          <h3 style="margin: 0; color: #e65100; font-size: 20px;">
            🏛️ ${countryName}
          </h3>
          <p style="margin: 5px 0 0 0; color: #bf360c; font-size: 14px;">
            ${markersCount} 个领地标记 (${spawnsCount} 个出生点)
          </p>
        </div>

        <div style="display: grid; gap: 8px; max-height: 300px; overflow-y: auto;">
    `;

    // 遍历该国家的所有标记（排除 spawns 字段）
    for (const key of markerKeys) {
      const marker = countryData[key];
      const { x, y, z, label, desc } = marker;
      const cleanDesc = desc ? desc.replace(/<[^>]*>/g, '').trim() : '无描述';

      html += `
        <div style="
          border: 1px solid #ffb74d;
          border-radius: 6px;
          padding: 10px;
          background-color: #ffffff;
          font-size: 13px;
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
            <strong style="color: #e65100;">${label || '未命名标记'}</strong>
            <span style="font-family: monospace; color: #666; font-size: 11px;">
              X:${x}, Y:${y}, Z:${z}
            </span>
          </div>
          <div style="font-size: 11px; color: #888; margin-bottom: 3px;">
            ID: ${key}
          </div>
          ${cleanDesc !== '无描述' && cleanDesc.length > 0 ? `
            <div style="font-size: 12px; color: #555; background-color: #fafafa; padding: 5px; border-radius: 3px;">
              ${cleanDesc.length > 100 ? cleanDesc.substring(0, 100) + '...' : cleanDesc}
            </div>
          ` : ''}
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;
  }

  html += '</div>';
  dataList.innerHTML = html;
}

// 在页面上显示国家区域数据的函数
function displayCountryAreasOnPage(countryAreas) {
  const dataList = document.getElementById('data-list');
  const dataTitle = document.getElementById('data-display-title');
  if (!dataList || !dataTitle) return;

  dataTitle.textContent = '🏛️ 国家区域数据';

  if (!countryAreas || Object.keys(countryAreas).length === 0) {
    dataList.innerHTML = '<p style="color: #999; font-style: italic;">暂无国家区域数据</p>';
    return;
  }

  let html = `
    <div style="margin-bottom: 15px; padding: 10px; background-color: #e8f5e8; border-radius: 5px;">
      <strong>🏛️ 总计：${Object.keys(countryAreas).length} 个国家</strong>
    </div>
    <div style="display: grid; gap: 15px;">
  `;

  // 遍历所有国家
  for (const [countryName, areas] of Object.entries(countryAreas)) {
    const areasCount = Object.keys(areas).length;

    html += `
      <div style="
        border: 2px solid #4caf50;
        border-radius: 12px;
        padding: 20px;
        background-color: #f1f8e9;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      ">
        <div style="margin-bottom: 15px; text-align: center;">
          <h3 style="margin: 0; color: #2e7d32; font-size: 20px;">
            🏛️ ${countryName}
          </h3>
          <p style="margin: 5px 0 0 0; color: #1b5e20; font-size: 14px;">
            ${areasCount} 个领地区域
          </p>
        </div>

        <div style="display: grid; gap: 8px; max-height: 300px; overflow-y: auto;">
    `;

    // 遍历该国家的所有区域
    for (const [key, area] of Object.entries(areas)) {
      const { x, z, fillcolor, color } = area;

      // 计算区域的边界和中心点
      const minX = Math.min(...x);
      const maxX = Math.max(...x);
      const minZ = Math.min(...z);
      const maxZ = Math.max(...z);
      const centerX = Math.round((minX + maxX) / 2);
      const centerZ = Math.round((minZ + maxZ) / 2);

      html += `
        <div style="
          border: 1px solid #81c784;
          border-radius: 6px;
          padding: 10px;
          background-color: #ffffff;
          font-size: 13px;
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
            <strong style="color: #2e7d32;">区域 ${key.split('_')[0]}</strong>
            <div style="
              width: 16px;
              height: 16px;
              background-color: ${fillcolor || '#80AE89'};
              border: 1px solid ${color || '#80AE89'};
              border-radius: 2px;
            "></div>
          </div>
          <div style="font-size: 11px; color: #888; margin-bottom: 3px;">
            ID: ${key}
          </div>
          <div style="font-size: 12px; color: #555;">
            中心: X:${centerX}, Z:${centerZ} | 范围: X:${minX}~${maxX}, Z:${minZ}~${maxZ}
          </div>
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;
  }

  html += '</div>';
  dataList.innerHTML = html;
}

/**
 * 工具函数模块
 */

// 显示存储状态的函数
function displayStorageStatus(type, message) {
  // 创建或更新状态显示元素
  let statusElement = document.getElementById('storage-status');
  if (!statusElement) {
    statusElement = document.createElement('div');
    statusElement.id = 'storage-status';
    statusElement.style.cssText = `
      position: fixed;
      top: 10px;
      right: 10px;
      padding: 10px 15px;
      border-radius: 5px;
      color: white;
      font-weight: bold;
      z-index: 1000;
      max-width: 300px;
    `;
    document.body.appendChild(statusElement);
  }

  // 根据类型设置样式
  switch(type) {
    case 'success':
      statusElement.style.backgroundColor = '#4CAF50';
      break;
    case 'warning':
      statusElement.style.backgroundColor = '#FF9800';
      break;
    case 'error':
      statusElement.style.backgroundColor = '#F44336';
      break;
  }

  statusElement.textContent = message;

  // 3秒后自动隐藏
  setTimeout(() => {
    if (statusElement.parentNode) {
      statusElement.parentNode.removeChild(statusElement);
    }
  }, 3000);
}

/**
 * 用户界面控制模块
 */

// 刷新所有数据
async function refreshAllData() {
  console.log('🔄 手动刷新所有数据...');
  await fetchAndStoreAllData();
}

// 切换数据视图
async function toggleDataView() {
  // 循环切换视图: markers -> areas -> countrySpawn -> countryAreas -> markers
  const viewCycle = ['markers', 'areas', 'countrySpawn', 'countryAreas'];
  const currentIndex = viewCycle.indexOf(currentDataView);
  const nextIndex = (currentIndex + 1) % viewCycle.length;
  currentDataView = viewCycle[nextIndex];

  const toggleBtn = document.getElementById('data-view-toggle');

  switch(currentDataView) {
    case 'markers':
      toggleBtn.textContent = '🔄 切换到区域数据';
      toggleBtn.style.backgroundColor = '#9C27B0';
      break;
    case 'areas':
      toggleBtn.textContent = '🔄 切换到国家标记';
      toggleBtn.style.backgroundColor = '#FF9800';
      break;
    case 'countrySpawn':
      toggleBtn.textContent = '🔄 切换到国家区域';
      toggleBtn.style.backgroundColor = '#4CAF50';
      break;
    case 'countryAreas':
      toggleBtn.textContent = '🔄 切换到标记数据';
      toggleBtn.style.backgroundColor = '#2196F3';
      break;
  }

  await updateDataDisplay();
}

// 查看当前存储的数据
async function viewStoredData() {
  await updateDataDisplay();

  const markers = await getStoredMarkers();
  const areas = await getStoredAreas();
  const countrySpawn = await getStoredCountrySpawn();
  const countryAreas = await getStoredCountryAreas();
  const countryClaims = await getStoredCountryClaims();

  const markersCount = markers ? Object.keys(markers).length : 0;
  const areasCount = areas ? Object.keys(areas).length : 0;
  const countrySpawnCount = countrySpawn ? Object.keys(countrySpawn).length : 0;
  const countryAreasCount = countryAreas ? Object.keys(countryAreas).length : 0;
  const countryClaimsCount = countryClaims ? Object.keys(countryClaims).length : 0;

  displayStorageStatus('success', `显示了 ${markersCount} 个标记, ${areasCount} 个区域, ${countrySpawnCount} 个国家标记, ${countryAreasCount} 个国家区域, ${countryClaimsCount} 个国家宣称`);
}

// 查看国家数据
async function viewCountryData() {
  const countrySpawn = await getStoredCountrySpawn();
  const countryAreas = await getStoredCountryAreas();

  if (!countrySpawn && !countryAreas) {
    displayStorageStatus('warning', '暂无国家数据，请先获取数据');
    return;
  }

  // 切换到国家标记视图
  currentDataView = 'countrySpawn';

  // 更新切换按钮状态
  const toggleBtn = document.getElementById('data-view-toggle');
  toggleBtn.textContent = '🔄 切换到国家区域';
  toggleBtn.style.backgroundColor = '#4CAF50';

  await updateDataDisplay();

  const countrySpawnCount = countrySpawn ? Object.keys(countrySpawn).length : 0;
  const countryAreasCount = countryAreas ? Object.keys(countryAreas).length : 0;

  displayStorageStatus('success', `显示国家数据: ${countrySpawnCount} 个国家标记, ${countryAreasCount} 个国家区域`);
}



// 清除存储的数据
async function clearStoredData() {
  try {
    await IndexedDBStorage.removeItem("landMarkers");
    await IndexedDBStorage.removeItem("landAreas");
    await IndexedDBStorage.removeItem("countrySpawn");
    await IndexedDBStorage.removeItem("countryAreas");
    await IndexedDBStorage.removeItem("countryClaims");
    await IndexedDBStorage.removeItem("conflictResolvedBoundaries");
    console.log('🗑️ 已清除 IndexedDB 中的所有数据');
    displayStorageStatus('success', '已清除存储的所有数据');

    // 更新页面显示为空状态
    await updateDataDisplay();
  } catch (error) {
    console.error('❌ 清除数据失败:', error);
    displayStorageStatus('error', `清除数据失败: ${error.message}`);
  }
}

/**
 * 初始化模块
 */

// 页面加载完成后的初始化函数
async function initializeDataManager() {
  console.log('📄 页面加载完成，检查本地存储的数据...');

  try {
    // 检查是否已有存储的数据，如果有就显示
    const existingMarkers = await IndexedDBStorage.getItem("landMarkers");
    const existingAreas = await IndexedDBStorage.getItem("landAreas");
    const existingCountrySpawn = await IndexedDBStorage.getItem("countrySpawn");
    const existingCountryAreas = await IndexedDBStorage.getItem("countryAreas");
    const existingCountryClaims = await IndexedDBStorage.getItem("countryClaims");
    const existingConflictResolved = await IndexedDBStorage.getItem("conflictResolvedBoundaries");

    if (existingMarkers || existingAreas || existingCountrySpawn || existingCountryAreas || existingCountryClaims) {
      try {
        await updateDataDisplay();

        const markersCount = existingMarkers ? Object.keys(JSON.parse(existingMarkers)).length : 0;
        const areasCount = existingAreas ? Object.keys(JSON.parse(existingAreas)).length : 0;
        const countrySpawnCount = existingCountrySpawn ? Object.keys(JSON.parse(existingCountrySpawn)).length : 0;
        const countryAreasCount = existingCountryAreas ? Object.keys(JSON.parse(existingCountryAreas)).length : 0;
        const countryClaimsCount = existingCountryClaims ? Object.keys(JSON.parse(existingCountryClaims)).length : 0;

        console.log('💾 发现已存储的数据，显示现有数据');
        displayStorageStatus('success', `显示了 ${markersCount} 个标记, ${areasCount} 个区域, ${countrySpawnCount} 个国家标记, ${countryAreasCount} 个国家区域, ${countryClaimsCount} 个国家宣称`);
      } catch (e) {
        console.warn('⚠️ 解析已存储数据失败:', e);
        await updateDataDisplay();
      }
    } else {
      console.log('📭 本地暂无存储数据，请点击"刷新所有数据"按钮获取');
      await updateDataDisplay();

      // 显示提示信息
      const dataList = document.getElementById('data-list');
      if (dataList) {
        dataList.innerHTML = `
          <div style="text-align: center; padding: 40px; color: #666;">
            <p style="font-size: 18px; margin-bottom: 15px;">📭 暂无数据</p>
            <p style="margin-bottom: 20px;">点击上方的 "🔄 刷新所有数据" 按钮来获取最新的标记和区域数据</p>
            <button onclick="refreshAllData()" style="
              padding: 12px 24px;
              background-color: #4CAF50;
              color: white;
              border: none;
              border-radius: 6px;
              cursor: pointer;
              font-size: 16px;
            ">
              🔄 立即获取数据
            </button>
          </div>
        `;
      }
    }
  } catch (error) {
    console.error('❌ 初始化数据管理器失败:', error);
    displayStorageStatus('error', '初始化失败，请刷新页面重试');
  }
}

// 页面加载完成后只显示已存储的数据，不自动获取新数据
document.addEventListener('DOMContentLoaded', initializeDataManager);

/**
 * 高级功能模块
 */



// 导出数据功能
async function exportData() {
  try {
    console.log('📤 开始导出数据...');

    const markers = await getStoredMarkers();
    const areas = await getStoredAreas();
    const countrySpawn = await getStoredCountrySpawn();
    const countryAreas = await getStoredCountryAreas();
    const countryClaims = await getStoredCountryClaims();

    const exportData = {
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      data: {
        landMarkers: markers,
        landAreas: areas,
        countrySpawn: countrySpawn,
        countryAreas: countryAreas,
        countryClaims: countryClaims
      },
      metadata: {
        exportedBy: 'Dynmap数据管理系统',
        markersCount: markers ? Object.keys(markers).length : 0,
        areasCount: areas ? Object.keys(areas).length : 0,
        countrySpawnCount: countrySpawn ? Object.keys(countrySpawn).length : 0,
        countryAreasCount: countryAreas ? Object.keys(countryAreas).length : 0,
        countryClaimsCount: countryClaims ? Object.keys(countryClaims).length : 0
      }
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dynmap-data-export-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    displayStorageStatus('success', '数据导出成功');
    console.log('✅ 数据导出完成');
  } catch (error) {
    console.error('❌ 数据导出失败:', error);
    displayStorageStatus('error', `数据导出失败: ${error.message}`);
  }
}

// 显示数据库统计信息
async function showDatabaseStats() {
  try {
    console.log('📊 获取数据库统计信息...');

    const stats = await IndexedDBStorage.getStats();
    const allKeys = await IndexedDBStorage.getAllKeys();

    const markers = await getStoredMarkers();
    const areas = await getStoredAreas();
    const countrySpawn = await getStoredCountrySpawn();
    const countryAreas = await getStoredCountryAreas();
    const countryClaims = await getStoredCountryClaims();

    const detailStats = {
      landMarkers: markers ? Object.keys(markers).length : 0,
      landAreas: areas ? Object.keys(areas).length : 0,
      countrySpawn: countrySpawn ? Object.keys(countrySpawn).length : 0,
      countryAreas: countryAreas ? Object.keys(countryAreas).length : 0,
      countryClaims: countryClaims ? Object.keys(countryClaims).length : 0
    };

    const statsMessage = `📊 数据库统计信息:
• 数据库名称: ${stats.dbName}
• 数据库版本: ${stats.version}
• 总项目数: ${stats.totalItems}
• 所有键: [${allKeys.join(', ')}]

📋 详细统计:
• 领地标记: ${detailStats.landMarkers} 个
• 领地区域: ${detailStats.landAreas} 个
• 国家出生点: ${detailStats.countrySpawn} 个
• 国家区域: ${detailStats.countryAreas} 个
• 国家宣称: ${detailStats.countryClaims} 个`;

    console.log(statsMessage);
    displayStorageStatus('info', '数据库统计信息已输出到控制台');

    // 如果有状态显示区域，也显示在页面上
    const statusContent = document.getElementById('status-content');
    if (statusContent) {
      statusContent.innerHTML = `<pre style="font-size: 12px; white-space: pre-wrap;">${statsMessage}</pre>`;
    }
  } catch (error) {
    console.error('❌ 获取数据库统计失败:', error);
    displayStorageStatus('error', `获取统计信息失败: ${error.message}`);
  }
}



/**
 * 将函数暴露到全局作用域，以便HTML中的onclick事件可以访问
 */
window.refreshAllData = refreshAllData;
window.viewStoredData = viewStoredData;
window.clearStoredData = clearStoredData;
window.toggleDataView = toggleDataView;
window.viewCountryData = viewCountryData;
window.exportData = exportData;
window.showDatabaseStats = showDatabaseStats;
