/**
 * 空间聚类算法模块
 * 提供DBSCAN等聚类算法用于空间数据分析
 */

class ClusteringAlgorithms {
    /**
     * DBSCAN聚类算法实现
     * @param {Array} points - 点数组，每个点包含 {x, z, data} 格式
     * @param {number} epsilon - 邻域半径（最大断裂距离）
     * @param {number} minPoints - 形成核心点的最小邻居数量
     * @returns {Array} 聚类结果数组，每个聚类包含点的索引
     */
    static dbscan(points, epsilon = 1000, minPoints = 1) {
        console.log(`🔍 开始DBSCAN聚类: ${points.length} 个点, epsilon=${epsilon}, minPoints=${minPoints}`);
        
        const clusters = [];
        const visited = new Set();
        const clustered = new Set();
        
        for (let i = 0; i < points.length; i++) {
            if (visited.has(i)) continue;
            
            visited.add(i);
            const neighbors = this.getNeighbors(points, i, epsilon);
            
            if (neighbors.length < minPoints) {
                // 标记为噪声点，但在我们的场景中仍然作为单独的聚类
                if (!clustered.has(i)) {
                    clusters.push([i]);
                    clustered.add(i);
                }
            } else {
                // 创建新聚类
                const cluster = [];
                this.expandCluster(points, i, neighbors, cluster, visited, clustered, epsilon, minPoints);
                if (cluster.length > 0) {
                    clusters.push(cluster);
                }
            }
        }
        
        console.log(`✅ DBSCAN聚类完成: 生成 ${clusters.length} 个聚类`);
        return clusters;
    }
    
    /**
     * 扩展聚类
     * @param {Array} points - 所有点
     * @param {number} pointIndex - 当前点索引
     * @param {Array} neighbors - 邻居点索引数组
     * @param {Array} cluster - 当前聚类
     * @param {Set} visited - 已访问点集合
     * @param {Set} clustered - 已聚类点集合
     * @param {number} epsilon - 邻域半径
     * @param {number} minPoints - 最小点数
     */
    static expandCluster(points, pointIndex, neighbors, cluster, visited, clustered, epsilon, minPoints) {
        cluster.push(pointIndex);
        clustered.add(pointIndex);
        
        for (let i = 0; i < neighbors.length; i++) {
            const neighborIndex = neighbors[i];
            
            if (!visited.has(neighborIndex)) {
                visited.add(neighborIndex);
                const neighborNeighbors = this.getNeighbors(points, neighborIndex, epsilon);
                
                if (neighborNeighbors.length >= minPoints) {
                    neighbors.push(...neighborNeighbors.filter(n => !neighbors.includes(n)));
                }
            }
            
            if (!clustered.has(neighborIndex)) {
                cluster.push(neighborIndex);
                clustered.add(neighborIndex);
            }
        }
    }
    
    /**
     * 获取指定点的邻居
     * @param {Array} points - 所有点
     * @param {number} pointIndex - 点索引
     * @param {number} epsilon - 邻域半径
     * @returns {Array} 邻居点索引数组
     */
    static getNeighbors(points, pointIndex, epsilon) {
        const neighbors = [];
        const point = points[pointIndex];
        
        for (let i = 0; i < points.length; i++) {
            if (i === pointIndex) continue;
            
            const distance = this.calculateDistance(point, points[i]);
            if (distance <= epsilon) {
                neighbors.push(i);
            }
        }
        
        return neighbors;
    }
    
    /**
     * 计算两点之间的欧几里得距离
     * @param {Object} point1 - 点1 {x, z}
     * @param {Object} point2 - 点2 {x, z}
     * @returns {number} 距离
     */
    static calculateDistance(point1, point2) {
        const dx = point1.x - point2.x;
        const dz = point1.z - point2.z;
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    /**
     * 简化的基于距离的聚类（适用于领地数据）
     * @param {Array} points - 点数组
     * @param {number} maxDistance - 最大断裂距离
     * @returns {Array} 聚类结果
     */
    static simpleDistanceClustering(points, maxDistance = 1000) {
        console.log(`🔍 开始简单距离聚类: ${points.length} 个点, maxDistance=${maxDistance}`);
        
        if (points.length === 0) return [];
        if (points.length === 1) return [[0]];
        
        const clusters = [];
        const assigned = new Array(points.length).fill(false);
        
        for (let i = 0; i < points.length; i++) {
            if (assigned[i]) continue;
            
            const cluster = [i];
            assigned[i] = true;
            
            // 查找所有与当前聚类中任意点距离小于阈值的点
            let changed = true;
            while (changed) {
                changed = false;
                
                for (let j = 0; j < points.length; j++) {
                    if (assigned[j]) continue;
                    
                    // 检查点j是否与聚类中任意点的距离小于阈值
                    let shouldAdd = false;
                    for (const clusterPointIndex of cluster) {
                        const distance = this.calculateDistance(points[j], points[clusterPointIndex]);
                        if (distance <= maxDistance) {
                            shouldAdd = true;
                            break;
                        }
                    }
                    
                    if (shouldAdd) {
                        cluster.push(j);
                        assigned[j] = true;
                        changed = true;
                    }
                }
            }
            
            clusters.push(cluster);
        }
        
        console.log(`✅ 简单距离聚类完成: 生成 ${clusters.length} 个聚类`);
        return clusters;
    }
    
    /**
     * 计算聚类的中心点
     * @param {Array} points - 所有点
     * @param {Array} clusterIndices - 聚类中点的索引
     * @returns {Object} 中心点坐标 {x, z}
     */
    static calculateClusterCenter(points, clusterIndices) {
        if (clusterIndices.length === 0) return null;
        
        let sumX = 0, sumZ = 0;
        for (const index of clusterIndices) {
            sumX += points[index].x;
            sumZ += points[index].z;
        }
        
        return {
            x: Math.round(sumX / clusterIndices.length),
            z: Math.round(sumZ / clusterIndices.length)
        };
    }
    
    /**
     * 计算聚类的边界框
     * @param {Array} points - 所有点
     * @param {Array} clusterIndices - 聚类中点的索引
     * @returns {Object} 边界框 {minX, maxX, minZ, maxZ}
     */
    static calculateClusterBounds(points, clusterIndices) {
        if (clusterIndices.length === 0) return null;
        
        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;
        
        for (const index of clusterIndices) {
            const point = points[index];
            minX = Math.min(minX, point.x);
            maxX = Math.max(maxX, point.x);
            minZ = Math.min(minZ, point.z);
            maxZ = Math.max(maxZ, point.z);
        }
        
        return { minX, maxX, minZ, maxZ };
    }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ClusteringAlgorithms;
} else if (typeof window !== 'undefined') {
    window.ClusteringAlgorithms = ClusteringAlgorithms;
}
