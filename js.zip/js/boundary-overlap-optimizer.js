/**
 * 边界重叠优化器
 * 实现国家宣称边界的重叠检测和优化处理
 * 使用64区块栅格化和距离最近原则进行冲突解决
 *
 * @author Dynmap Territory System
 * @version 1.0.0
 */

class BoundaryOverlapOptimizer {
    constructor(options = {}) {
        this.config = {
            // 栅格化配置 (MC区块大小)
            gridSize: options.gridSize || 4, // 4区块为单位
            blockSize: 16, // 每个区块16x16方块
            // 采样密度
            samplingDensity: options.samplingDensity || 1, // 每个栅格点的采样密度
            // 调试选项
            debug: options.debug || false
        };

        // 计算实际栅格大小（方块单位）
        this.actualGridSize = this.config.gridSize * this.config.blockSize;

        console.log('🔧 边界重叠优化器初始化完成:', this.config);
        console.log(`📐 栅格大小: ${this.config.gridSize}区块 = ${this.actualGridSize}方块`);
    }

    /**
     * 优化所有国家的宣称边界，解决重叠问题
     * @param {Map} countryClaimsMap - 国家宣称数据映射 Map<countryName, claims[]>
     * @param {Map} countryAreaDataMap - 国家区域数据映射 Map<countryName, areaData>
     * @returns {Object} 优化结果
     */
    optimizeBoundaries(countryClaimsMap, countryAreaDataMap) {
        console.log('🚀 开始边界重叠优化处理...');

        try {
            // 第一步：检测所有重叠区域
            const conflicts = this.detectAllConflicts(countryClaimsMap);
            console.log(`🔍 检测到 ${conflicts.length} 个冲突区域`);

            if (conflicts.length === 0) {
                return {
                    success: true,
                    message: '没有检测到边界重叠',
                    optimizedClaims: this.cloneClaimsMap(countryClaimsMap),
                    conflicts: [],
                    statistics: {
                        totalConflicts: 0,
                        resolvedConflicts: 0,
                        affectedCountries: 0
                    }
                };
            }

            // 第二步：处理每个冲突区域
            const optimizedClaims = this.cloneClaimsMap(countryClaimsMap);
            const resolvedConflicts = [];
            const affectedCountries = new Set();

            for (let i = 0; i < conflicts.length; i++) {
                const conflict = conflicts[i];
                console.log(`⚔️ 处理冲突区域 ${i + 1}/${conflicts.length}:`, conflict.countries);

                const resolution = this.resolveConflict(conflict, countryAreaDataMap);
                if (resolution.success) {
                    // 应用解决方案到优化后的宣称数据
                    this.applyResolution(optimizedClaims, resolution);
                    resolvedConflicts.push(resolution);

                    // 记录受影响的国家
                    conflict.countries.forEach(country => affectedCountries.add(country));
                }
            }

            console.log(`✅ 边界优化完成，解决了 ${resolvedConflicts.length}/${conflicts.length} 个冲突`);

            return {
                success: true,
                message: `成功解决 ${resolvedConflicts.length} 个边界冲突`,
                optimizedClaims,
                conflicts: resolvedConflicts,
                statistics: {
                    totalConflicts: conflicts.length,
                    resolvedConflicts: resolvedConflicts.length,
                    affectedCountries: affectedCountries.size
                }
            };

        } catch (error) {
            console.error('❌ 边界优化处理失败:', error);
            return {
                success: false,
                error: error.message,
                optimizedClaims: countryClaimsMap,
                conflicts: []
            };
        }
    }

    /**
     * 检测所有国家之间的边界冲突
     * @param {Map} countryClaimsMap - 国家宣称数据映射 Map<countryName, claimsResult>
     * @returns {Array} 冲突列表
     */
    detectAllConflicts(countryClaimsMap) {
        const conflicts = [];
        const countries = Array.from(countryClaimsMap.keys());

        // 两两比较所有国家
        for (let i = 0; i < countries.length; i++) {
            for (let j = i + 1; j < countries.length; j++) {
                const country1 = countries[i];
                const country2 = countries[j];

                // 提取实际的 claims 数组
                const claimsResult1 = countryClaimsMap.get(country1);
                const claimsResult2 = countryClaimsMap.get(country2);

                const claims1 = claimsResult1 && claimsResult1.success ? claimsResult1.claims : [];
                const claims2 = claimsResult2 && claimsResult2.success ? claimsResult2.claims : [];

                const countryConflicts = this.detectCountryConflicts(
                    country1, claims1,
                    country2, claims2
                );

                conflicts.push(...countryConflicts);
            }
        }

        return conflicts;
    }

    /**
     * 检测两个国家之间的边界冲突（使用Turf.js精确计算交集）
     * @param {string} country1 - 国家1名称
     * @param {Array} claims1 - 国家1的宣称列表
     * @param {string} country2 - 国家2名称
     * @param {Array} claims2 - 国家2的宣称列表
     * @returns {Array} 冲突列表
     */
    detectCountryConflicts(country1, claims1, country2, claims2) {
        const conflicts = [];

        if (!claims1 || !claims2) return conflicts;

        for (const claim1 of claims1) {
            for (const claim2 of claims2) {
                // 使用改进的交集计算
                const intersectionResult = GeometryUtils.calculatePolygonIntersection(
                    claim1.boundary, claim2.boundary
                );

                if (intersectionResult.success && intersectionResult.intersection) {
                    // 确保 claim 对象包含国家信息
                    const enrichedClaim1 = { ...claim1, countryName: country1 };
                    const enrichedClaim2 = { ...claim2, countryName: country2 };

                    conflicts.push({
                        id: `conflict_${country1}_${country2}_${claim1.id}_${claim2.id}`,
                        countries: [country1, country2],
                        claims: [enrichedClaim1, enrichedClaim2],
                        intersectionGeometry: intersectionResult.intersection, // 真实的交集几何
                        intersectionBounds: intersectionResult.bounds, // 边界框（向后兼容）
                        area: GeometryUtils.calculatePolygonArea(intersectionResult.intersection)
                    });
                }
            }
        }

        return conflicts;
    }

    /**
     * 解决单个冲突区域
     * @param {Object} conflict - 冲突信息
     * @param {Map} countryAreaDataMap - 国家区域数据映射
     * @returns {Object} 解决方案
     */
    resolveConflict(conflict, countryAreaDataMap) {
        try {
            console.log(`🔧 开始解决冲突: ${conflict.id}`);

            // 第一步：生成重叠区域的栅格单元
            const gridCells = this.generateGridCells(conflict.intersectionBounds);
            console.log(`📐 生成 ${gridCells.length} 个栅格单元`);

            // 第二步：收集参与冲突的国家的实际领地边界
            const countryBoundaries = this.collectCountryBoundaries(conflict.countries, countryAreaDataMap);

            // 检查是否收集到有效的边界数据，如果没有则使用宣称边界
            this.ensureBoundaryData(countryBoundaries, conflict);

            // 第三步：为每个栅格单元分配归属
            const cellAssignments = this.assignCellsToCountries(gridCells, countryBoundaries);

            // 第四步：生成栅格化的多边形修改方案
            const modifiedPolygons = this.reconstructPolygonsFromCells(cellAssignments, conflict);

            // 第五步：生成解决方案
            const resolution = {
                success: true,
                conflictId: conflict.id,
                countries: conflict.countries,
                originalBounds: conflict.intersectionBounds,
                modifiedPolygons,
                processedCells: gridCells.length,
                assignedCells: cellAssignments.size,
                affectedClaims: conflict.claims.map(claim => claim.id),
                method: 'grid-based-cutting'
            };

            console.log(`✅ 冲突解决完成: ${conflict.id}`);
            return resolution;

        } catch (error) {
            console.error(`❌ 解决冲突失败 [${conflict.id}]:`, error);
            return {
                success: false,
                conflictId: conflict.id,
                error: error.message
            };
        }
    }

    /**
     * 生成栅格采样点
     * @param {Object} bounds - 边界框 {minX, maxX, minZ, maxZ}
     * @returns {Array} 栅格点数组 [[x, z], ...]
     */
    generateGridPoints(bounds) {
        const points = [];
        const { minX, maxX, minZ, maxZ } = bounds;

        // 计算栅格起始点（对齐到栅格边界）
        const startX = Math.floor(minX / this.actualGridSize) * this.actualGridSize;
        const startZ = Math.floor(minZ / this.actualGridSize) * this.actualGridSize;

        // 生成栅格点
        for (let x = startX; x <= maxX; x += this.actualGridSize) {
            for (let z = startZ; z <= maxZ; z += this.actualGridSize) {
                // 栅格中心点
                const centerX = x + this.actualGridSize / 2;
                const centerZ = z + this.actualGridSize / 2;

                // 检查点是否在边界框内
                if (centerX >= minX && centerX <= maxX &&
                    centerZ >= minZ && centerZ <= maxZ) {
                    points.push([centerX, centerZ]);
                }
            }
        }

        return points;
    }

    /**
     * 收集参与冲突的国家的实际领地边界
     * @param {Array} countries - 国家名称列表
     * @param {Map} countryAreaDataMap - 国家区域数据映射
     * @returns {Map} 国家边界映射 Map<countryName, boundaries[]>
     */
    collectCountryBoundaries(countries, countryAreaDataMap) {
        const boundaries = new Map();

        if (this.config.debug) {
            console.log(`🔍 收集 ${countries.length} 个国家的边界数据:`, countries);
            console.log('📊 可用的区域数据:', Array.from(countryAreaDataMap.keys()));
        }

        for (const countryName of countries) {
            const areaData = countryAreaDataMap.get(countryName);
            const countryBoundaries = [];

            if (areaData && areaData.areas) {
                for (const area of areaData.areas) {
                    const polygon = GeometryUtils.areaToPolygon(area);
                    if (polygon.length > 0) {
                        countryBoundaries.push(polygon);
                    }
                }

                if (this.config.debug) {
                    console.log(`📐 国家 "${countryName}" 找到 ${countryBoundaries.length} 个边界区域`);
                }
            } else {
                if (this.config.debug) {
                    console.warn(`⚠️ 国家 "${countryName}" 没有找到区域数据`);
                }
            }

            boundaries.set(countryName, countryBoundaries);
        }

        return boundaries;
    }

    /**
     * 确保有有效的边界数据
     * @param {Map} countryBoundaries - 国家边界映射
     * @param {Object} conflict - 冲突信息
     */
    ensureBoundaryData(countryBoundaries, conflict) {
        // 检查是否收集到有效的边界数据
        let totalBoundaries = 0;
        for (const [countryName, boundaries] of countryBoundaries) {
            totalBoundaries += boundaries.length;
            if (this.config.debug) {
                console.log(`🏛️ 国家 "${countryName}" 收集到 ${boundaries.length} 个边界区域`);
            }
        }

        if (totalBoundaries === 0) {
            console.warn('⚠️ 没有收集到任何边界数据，使用宣称边界作为替代');
            // 使用冲突中的宣称边界作为替代
            for (const countryName of conflict.countries) {
                const countryBoundaries_fallback = [];
                for (const claim of conflict.claims) {
                    if (claim.countryName === countryName) {
                        countryBoundaries_fallback.push(claim.boundary);
                        if (this.config.debug) {
                            console.log(`📐 添加国家 "${countryName}" 的宣称边界: ${claim.id}`);
                        }
                    }
                }
                countryBoundaries.set(countryName, countryBoundaries_fallback);
                if (this.config.debug) {
                    console.log(`🔄 国家 "${countryName}" 使用宣称边界: ${countryBoundaries_fallback.length} 个区域`);
                }
            }

            // 重新计算总边界数
            totalBoundaries = 0;
            for (const [countryName, boundaries] of countryBoundaries) {
                totalBoundaries += boundaries.length;
            }
            if (this.config.debug) {
                console.log(`📊 使用宣称边界后，总边界数: ${totalBoundaries}`);
            }
        }
    }

    /**
     * 对采样点执行归属判断
     * @param {Array} gridPoints - 栅格点数组
     * @param {Map} countryBoundaries - 国家边界映射
     * @returns {Map} 点归属映射 Map<pointKey, countryName>
     */
    assignPointsToCountries(gridPoints, countryBoundaries) {
        const assignments = new Map();

        if (this.config.debug) {
            console.log(`🎯 开始为 ${gridPoints.length} 个栅格点分配归属`);
        }

        // 检查是否有有效的边界数据
        const validCountries = [];
        for (const [countryName, boundaries] of countryBoundaries) {
            if (boundaries && boundaries.length > 0) {
                validCountries.push(countryName);
            }
        }

        if (validCountries.length === 0) {
            console.warn('⚠️ 没有找到有效的国家边界数据，无法进行点归属判断');
            return assignments;
        }

        if (this.config.debug) {
            console.log(`📊 有效国家数量: ${validCountries.length}`, validCountries);
        }

        for (const point of gridPoints) {
            let closestCountry = null;
            let minDistance = Infinity;

            // 计算点到每个国家边界的最短距离
            for (const [countryName, boundaries] of countryBoundaries) {
                if (!boundaries || boundaries.length === 0) continue;

                let countryMinDistance = Infinity;

                for (const boundary of boundaries) {
                    if (boundary && boundary.length > 0) {
                        const distance = GeometryUtils.pointToPolygonDistance(point, boundary);
                        countryMinDistance = Math.min(countryMinDistance, distance);
                    }
                }

                if (countryMinDistance < minDistance) {
                    minDistance = countryMinDistance;
                    closestCountry = countryName;
                }
            }

            if (closestCountry) {
                const pointKey = `${point[0]},${point[1]}`;
                assignments.set(pointKey, closestCountry);
            }
        }

        if (this.config.debug) {
            console.log(`✅ 点归属分配完成: ${assignments.size}/${gridPoints.length} 个点已分配`);

            // 统计每个国家分配到的点数
            const countryStats = new Map();
            for (const country of assignments.values()) {
                countryStats.set(country, (countryStats.get(country) || 0) + 1);
            }
            console.log('📊 各国家分配点数:', Object.fromEntries(countryStats));
        }

        return assignments;
    }

    /**
     * 根据点归属重建边界
     * @param {Map} assignments - 点归属映射
     * @param {Object} conflict - 冲突信息
     * @returns {Map} 新边界映射 Map<countryName, boundary>
     */
    reconstructBoundaries(assignments, conflict) {
        if (this.config.debug) {
            console.log(`🏗️ 开始重建边界，输入分配: ${assignments.size} 个点`);
        }

        const countryPoints = new Map();

        // 按国家分组采样点
        for (const [pointKey, countryName] of assignments) {
            if (!countryPoints.has(countryName)) {
                countryPoints.set(countryName, []);
            }
            const [x, z] = pointKey.split(',').map(Number);
            countryPoints.get(countryName).push([x, z]);
        }

        if (this.config.debug) {
            console.log('📊 各国家分配到的点数:');
            for (const [countryName, points] of countryPoints) {
                console.log(`  ${countryName}: ${points.length} 个点`);
            }
        }

        // 为每个国家生成新的边界
        const newBoundaries = new Map();
        for (const [countryName, points] of countryPoints) {
            if (points.length >= 3) {
                // 使用凸包算法生成边界
                const boundary = GeometryUtils.calculateConvexHull(points);
                newBoundaries.set(countryName, boundary);

                if (this.config.debug) {
                    console.log(`✅ 国家 "${countryName}" 新边界生成完成: ${boundary.length} 个顶点`);
                }
            } else {
                if (this.config.debug) {
                    console.warn(`⚠️ 国家 "${countryName}" 点数不足 (${points.length} < 3)，无法生成边界`);
                }
            }
        }

        if (this.config.debug) {
            console.log(`🏗️ 边界重建完成: ${newBoundaries.size} 个国家获得新边界`);
        }

        return newBoundaries;
    }

    /**
     * 生成栅格单元（区块对齐的正方形）
     * @param {Object} bounds - 边界框 {minX, maxX, minZ, maxZ}
     * @returns {Array} 栅格单元数组，每个单元都是完整的区块对齐正方形
     */
    generateGridCells(bounds) {
        const cells = [];
        const { minX, maxX, minZ, maxZ } = bounds;

        // 确保栅格大小是16的倍数（区块对齐）
        const CHUNK_SIZE = 16;
        const alignedGridSize = Math.max(CHUNK_SIZE, Math.ceil(this.actualGridSize / CHUNK_SIZE) * CHUNK_SIZE);

        // 计算区块对齐的边界
        const alignedMinX = Math.floor(minX / CHUNK_SIZE) * CHUNK_SIZE;
        const alignedMaxX = Math.ceil(maxX / CHUNK_SIZE) * CHUNK_SIZE;
        const alignedMinZ = Math.floor(minZ / CHUNK_SIZE) * CHUNK_SIZE;
        const alignedMaxZ = Math.ceil(maxZ / CHUNK_SIZE) * CHUNK_SIZE;

        if (this.config.debug) {
            console.log(`📐 生成区块对齐栅格:`);
            console.log(`   原始边界: X(${minX}-${maxX}) Z(${minZ}-${maxZ})`);
            console.log(`   对齐边界: X(${alignedMinX}-${alignedMaxX}) Z(${alignedMinZ}-${alignedMaxZ})`);
            console.log(`   栅格大小: ${alignedGridSize} 方块 (${alignedGridSize/CHUNK_SIZE} 区块)`);
        }

        // 生成区块对齐的栅格单元
        for (let x = alignedMinX; x < alignedMaxX; x += alignedGridSize) {
            for (let z = alignedMinZ; z < alignedMaxZ; z += alignedGridSize) {
                const cellMinX = x;
                const cellMaxX = x + alignedGridSize;
                const cellMinZ = z;
                const cellMaxZ = z + alignedGridSize;

                // 检查栅格单元是否与原始边界有重叠
                if (cellMaxX > minX && cellMinX < maxX && cellMaxZ > minZ && cellMinZ < maxZ) {
                    const chunkX = x / CHUNK_SIZE;
                    const chunkZ = z / CHUNK_SIZE;

                    cells.push({
                        id: `chunk_${chunkX}_${chunkZ}`,
                        bounds: { minX: cellMinX, maxX: cellMaxX, minZ: cellMinZ, maxZ: cellMaxZ },
                        center: [
                            cellMinX + alignedGridSize / 2,
                            cellMinZ + alignedGridSize / 2
                        ],
                        polygon: [
                            [cellMinX, cellMinZ],
                            [cellMaxX, cellMinZ],
                            [cellMaxX, cellMaxZ],
                            [cellMinX, cellMaxZ]
                        ],
                        chunkCoords: { x: chunkX, z: chunkZ },
                        sizeInChunks: alignedGridSize / CHUNK_SIZE
                    });
                }
            }
        }

        if (this.config.debug) {
            console.log(`✅ 生成了 ${cells.length} 个区块对齐栅格单元`);
            console.log(`   每个单元: ${alignedGridSize}x${alignedGridSize} 方块 (${alignedGridSize/CHUNK_SIZE}x${alignedGridSize/CHUNK_SIZE} 区块)`);
        }

        return cells;
    }

    /**
     * 为栅格单元分配国家归属
     * @param {Array} gridCells - 栅格单元数组
     * @param {Map} countryBoundaries - 国家边界映射
     * @returns {Map} 单元归属映射 Map<cellId, countryName>
     */
    assignCellsToCountries(gridCells, countryBoundaries) {
        const assignments = new Map();

        if (this.config.debug) {
            console.log(`🎯 开始为 ${gridCells.length} 个栅格单元分配归属`);
        }

        for (const cell of gridCells) {
            let closestCountry = null;
            let minDistance = Infinity;

            // 计算单元中心点到每个国家边界的最短距离
            for (const [countryName, boundaries] of countryBoundaries) {
                if (!boundaries || boundaries.length === 0) continue;

                let countryMinDistance = Infinity;

                for (const boundary of boundaries) {
                    if (boundary && boundary.length > 0) {
                        const distance = GeometryUtils.pointToPolygonDistance(cell.center, boundary);
                        countryMinDistance = Math.min(countryMinDistance, distance);
                    }
                }

                if (countryMinDistance < minDistance) {
                    minDistance = countryMinDistance;
                    closestCountry = countryName;
                }
            }

            if (closestCountry) {
                assignments.set(cell.id, closestCountry);
            }
        }

        if (this.config.debug) {
            console.log(`✅ 单元归属分配完成: ${assignments.size}/${gridCells.length} 个单元已分配`);

            // 统计每个国家分配到的单元数
            const countryStats = new Map();
            for (const country of assignments.values()) {
                countryStats.set(country, (countryStats.get(country) || 0) + 1);
            }
            console.log('📊 各国家分配单元数:', Object.fromEntries(countryStats));
        }

        return assignments;
    }

    /**
     * 从栅格单元重建多边形（精确切割方法）
     * @param {Map} cellAssignments - 单元归属映射
     * @param {Object} conflict - 冲突信息
     * @returns {Map} 修改后的多边形映射 Map<countryName, {removedCells, modifiedBoundary}>
     */
    reconstructPolygonsFromCells(cellAssignments, conflict) {
        if (this.config.debug) {
            console.log(`🏗️ 开始从栅格单元重建多边形`);
            console.log(`📊 输入: ${cellAssignments.size} 个栅格分配，${conflict.countries.length} 个国家`);
        }

        const modifiedPolygons = new Map();

        // 按国家分组栅格单元
        const countryCells = new Map();
        for (const [cellId, countryName] of cellAssignments) {
            if (!countryCells.has(countryName)) {
                countryCells.set(countryName, []);
            }
            countryCells.get(countryName).push(cellId);
        }

        if (this.config.debug) {
            console.log(`📊 国家栅格分配统计:`);
            for (const [countryName, cells] of countryCells) {
                console.log(`   ${countryName}: ${cells.length} 个栅格单元`);
            }
        }

        // 为每个参与冲突的国家处理多边形修改
        for (const countryName of conflict.countries) {
            const assignedCells = countryCells.get(countryName) || [];

            // 找到该国家在冲突中的原始宣称
            const originalClaim = conflict.claims.find(claim => claim.countryName === countryName);

            if (originalClaim) {
                if (this.config.debug) {
                    console.log(`🏛️ 处理国家 "${countryName}"`);
                    console.log(`   原始边界: ${originalClaim.boundary.length} 个顶点`);
                    console.log(`   分配栅格: ${assignedCells.length} 个单元`);
                }

                // 实现真正的栅格化多边形切割
                const cuttingResult = this.performAdvancedGridCutting(
                    originalClaim.boundary,
                    assignedCells,
                    conflict.intersectionBounds,
                    countryName
                );

                modifiedPolygons.set(countryName, {
                    originalBoundary: originalClaim.boundary,
                    assignedCells: assignedCells,
                    cellCount: assignedCells.length,
                    modifiedBoundary: cuttingResult.newBoundary,
                    removedArea: cuttingResult.removedArea,
                    cuttingMethod: cuttingResult.method,
                    preservedArea: cuttingResult.preservedArea
                });

                if (this.config.debug) {
                    console.log(`   切割结果:`);
                    console.log(`     方法: ${cuttingResult.method}`);
                    console.log(`     新边界顶点: ${cuttingResult.newBoundary.length}`);
                    console.log(`     移除面积: ${Math.round(cuttingResult.removedArea)} 平方方块`);
                    console.log(`     保留面积: ${Math.round(cuttingResult.preservedArea)} 平方方块`);
                }
            } else {
                if (this.config.debug) {
                    console.warn(`⚠️ 未找到国家 "${countryName}" 的原始宣称`);
                }
            }
        }

        if (this.config.debug) {
            console.log(`✅ 多边形重建完成，处理了 ${modifiedPolygons.size} 个国家`);
        }

        return modifiedPolygons;
    }

    /**
     * 执行高级栅格化多边形切割
     * @param {Array} originalBoundary - 原始边界
     * @param {Array} assignedCells - 分配给该国家的栅格单元ID
     * @param {Object} conflictBounds - 冲突区域边界
     * @param {string} countryName - 国家名称（用于调试）
     * @returns {Object} 切割结果
     */
    performAdvancedGridCutting(originalBoundary, assignedCells, conflictBounds, countryName) {
        if (this.config.debug) {
            console.log(`✂️ 开始高级栅格化切割 [${countryName}]`);
            console.log(`   原始边界: ${originalBoundary.length} 个顶点`);
            console.log(`   分配栅格: ${assignedCells.length} 个单元`);
        }

        const originalArea = GeometryUtils.calculatePolygonArea(originalBoundary);

        if (assignedCells.length === 0) {
            // 如果没有分配到任何栅格单元，完全移除在冲突区域内的部分
            const cutBoundary = this.removeConflictArea(originalBoundary, conflictBounds);
            const newArea = GeometryUtils.calculatePolygonArea(cutBoundary);

            return {
                newBoundary: cutBoundary,
                removedArea: originalArea - newArea,
                preservedArea: newArea,
                method: 'conflict-area-removal'
            };
        }

        // 方法1：基于栅格单元的精确切割
        const gridCuttingResult = this.performGridBasedCutting(originalBoundary, assignedCells, conflictBounds);

        // 方法2：如果栅格切割效果不好，尝试保守切割
        if (gridCuttingResult.newBoundary.length < 3) {
            if (this.config.debug) {
                console.log(`   栅格切割结果不佳，尝试保守切割`);
            }

            const conservativeCutting = this.performConservativeCutting(originalBoundary, assignedCells, conflictBounds);
            return conservativeCutting;
        }

        return gridCuttingResult;
    }

    /**
     * 执行基于栅格的多边形切割（原有方法，改进版）
     * @param {Array} originalBoundary - 原始边界
     * @param {Array} assignedCells - 分配给该国家的栅格单元ID
     * @param {Object} conflictBounds - 冲突区域边界
     * @returns {Object} 切割结果
     */
    performGridBasedCutting(originalBoundary, assignedCells, conflictBounds) {
        // 计算分配的栅格单元的总边界框
        const assignedBounds = this.calculateAssignedCellsBounds(assignedCells, conflictBounds);

        if (!assignedBounds) {
            const originalArea = GeometryUtils.calculatePolygonArea(originalBoundary);
            return {
                newBoundary: originalBoundary,
                removedArea: 0,
                preservedArea: originalArea,
                method: 'no-change'
            };
        }

        // 执行栅格化切割：保留分配区域，移除其他冲突区域
        const cutBoundary = this.cutPolygonWithGrids(originalBoundary, assignedBounds, conflictBounds);

        const originalArea = GeometryUtils.calculatePolygonArea(originalBoundary);
        const newArea = GeometryUtils.calculatePolygonArea(cutBoundary);

        return {
            newBoundary: cutBoundary,
            removedArea: originalArea - newArea,
            preservedArea: newArea,
            method: 'grid-based-cutting'
        };
    }

    /**
     * 执行保守的多边形切割
     * @param {Array} originalBoundary - 原始边界
     * @param {Array} assignedCells - 分配的栅格单元
     * @param {Object} conflictBounds - 冲突区域边界
     * @returns {Object} 切割结果
     */
    performConservativeCutting(originalBoundary, assignedCells, conflictBounds) {
        // 保守策略：只移除明确不属于该国家的冲突区域部分
        // 保留原始边界的大部分，只在边缘进行微调

        const originalArea = GeometryUtils.calculatePolygonArea(originalBoundary);

        // 如果分配的栅格很少，只做最小的调整
        if (assignedCells.length <= 2) {
            // 几乎不做改动，只是标记为已处理
            return {
                newBoundary: originalBoundary,
                removedArea: 0,
                preservedArea: originalArea,
                method: 'minimal-conservative'
            };
        }

        // 计算分配区域的边界
        const assignedBounds = this.calculateAssignedCellsBounds(assignedCells, conflictBounds);
        if (!assignedBounds) {
            return {
                newBoundary: originalBoundary,
                removedArea: 0,
                preservedArea: originalArea,
                method: 'conservative-no-change'
            };
        }

        // 保守切割：只移除明显超出分配区域的部分
        const cutBoundary = this.conservativeCutPolygon(originalBoundary, assignedBounds, conflictBounds);
        const newArea = GeometryUtils.calculatePolygonArea(cutBoundary);

        return {
            newBoundary: cutBoundary,
            removedArea: originalArea - newArea,
            preservedArea: newArea,
            method: 'conservative-cutting'
        };
    }

    /**
     * 计算分配的栅格单元的边界框
     * @param {Array} assignedCells - 分配的栅格单元ID
     * @param {Object} conflictBounds - 冲突区域边界
     * @returns {Object|null} 边界框
     */
    calculateAssignedCellsBounds(assignedCells, conflictBounds) {
        if (assignedCells.length === 0) return null;

        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        // 从单元ID解析坐标
        for (const cellId of assignedCells) {
            const match = cellId.match(/cell_(-?\d+)_(-?\d+)/);
            if (match) {
                const x = parseInt(match[1]);
                const z = parseInt(match[2]);

                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x + this.actualGridSize);
                minZ = Math.min(minZ, z);
                maxZ = Math.max(maxZ, z + this.actualGridSize);
            }
        }

        if (minX === Infinity) return null;

        return { minX, maxX, minZ, maxZ };
    }

    /**
     * 移除冲突区域（使用Martinez库进行精确差集运算）
     * @param {Array} polygon - 原始多边形
     * @param {Object} conflictBounds - 冲突区域边界框
     * @returns {Array} 切割后的多边形
     */
    removeConflictArea(polygon, conflictBounds) {
        if (this.config.debug) {
            console.log(`🔧 使用Martinez库移除冲突区域`);
            console.log(`   原始多边形: ${polygon.length} 个顶点`);
            console.log(`   冲突区域: X(${conflictBounds.minX}-${conflictBounds.maxX}) Z(${conflictBounds.minZ}-${conflictBounds.maxZ})`);
        }

        try {
            // 检查Martinez库是否可用
            if (typeof window.MartinezGeometryUtils !== 'undefined') {
                // 使用Martinez库进行精确的差集运算
                const result = MartinezGeometryUtils.subtractPolygon(polygon, conflictBounds);

                if (result.length < 3) {
                    if (this.config.debug) {
                        console.log(`⚠️ Martinez差集运算结果顶点不足，使用简单过滤`);
                    }
                    return this.simpleRemoveConflictArea(polygon, conflictBounds);
                }

                if (this.config.debug) {
                    console.log(`✅ Martinez冲突区域移除完成: 结果 ${result.length} 个顶点`);
                }
                return result;
            } else {
                if (this.config.debug) {
                    console.log(`⚠️ Martinez库未加载，使用简单过滤`);
                }
                return this.simpleRemoveConflictArea(polygon, conflictBounds);
            }

        } catch (error) {
            console.error(`❌ Martinez冲突区域移除失败，回退到简单过滤:`, error);
            return this.simpleRemoveConflictArea(polygon, conflictBounds);
        }
    }

    /**
     * 简单的冲突区域移除（备用方案）
     * @param {Array} polygon - 原始多边形
     * @param {Object} conflictBounds - 冲突区域边界框
     * @returns {Array} 切割后的多边形
     */
    simpleRemoveConflictArea(polygon, conflictBounds) {
        const cutPolygon = [];

        for (const vertex of polygon) {
            const [x, z] = vertex;

            // 只保留冲突区域外的顶点
            if (x < conflictBounds.minX || x > conflictBounds.maxX ||
                z < conflictBounds.minZ || z > conflictBounds.maxZ) {
                cutPolygon.push(vertex);
            }
        }

        // 如果切割后顶点太少，返回原始多边形
        if (cutPolygon.length < 3) {
            if (this.config.debug) {
                console.log(`⚠️ 简单移除冲突区域后顶点不足，保持原始边界`);
            }
            return polygon;
        }

        if (this.config.debug) {
            console.log(`✅ 简单冲突区域移除完成: ${polygon.length} → ${cutPolygon.length} 个顶点`);
        }
        return cutPolygon;
    }

    /**
     * 使用栅格进行多边形切割
     * @param {Array} polygon - 原始多边形
     * @param {Object} keepBounds - 保留区域的边界框
     * @param {Object} conflictBounds - 冲突区域边界框
     * @returns {Array} 切割后的多边形
     */
    cutPolygonWithGrids(polygon, keepBounds, conflictBounds) {
        if (this.config.debug) {
            console.log(`✂️ 执行栅格化多边形切割`);
            console.log(`   保留区域: X(${keepBounds.minX}-${keepBounds.maxX}) Z(${keepBounds.minZ}-${keepBounds.maxZ})`);
            console.log(`   冲突区域: X(${conflictBounds.minX}-${conflictBounds.maxX}) Z(${conflictBounds.minZ}-${conflictBounds.maxZ})`);
        }

        const cutPolygon = [];

        for (const vertex of polygon) {
            const [x, z] = vertex;

            // 如果顶点在冲突区域外，直接保留
            if (x < conflictBounds.minX || x > conflictBounds.maxX ||
                z < conflictBounds.minZ || z > conflictBounds.maxZ) {
                cutPolygon.push(vertex);
                if (this.config.debug && cutPolygon.length <= 5) {
                    console.log(`   保留顶点 (冲突区域外): (${x}, ${z})`);
                }
            }
            // 如果顶点在冲突区域内，检查是否在保留区域内
            else if (x >= keepBounds.minX && x <= keepBounds.maxX &&
                     z >= keepBounds.minZ && z <= keepBounds.maxZ) {
                cutPolygon.push(vertex);
                if (this.config.debug && cutPolygon.length <= 5) {
                    console.log(`   保留顶点 (保留区域内): (${x}, ${z})`);
                }
            } else {
                // 移除该顶点（在冲突区域内但不在保留区域内）
                if (this.config.debug && cutPolygon.length <= 5) {
                    console.log(`   移除顶点 (冲突但非保留): (${x}, ${z})`);
                }
            }
        }

        // 如果切割后顶点太少，尝试保守策略
        if (cutPolygon.length < 3) {
            if (this.config.debug) {
                console.log(`⚠️ 栅格切割后顶点不足 (${cutPolygon.length})，尝试保守策略`);
            }
            return this.conservativeCutPolygon(polygon, keepBounds, conflictBounds);
        }

        if (this.config.debug) {
            console.log(`✅ 栅格切割完成: ${polygon.length} → ${cutPolygon.length} 个顶点`);
        }

        return cutPolygon;
    }

    /**
     * 保守的多边形切割
     * @param {Array} polygon - 原始多边形
     * @param {Object} keepBounds - 保留区域的边界框
     * @param {Object} conflictBounds - 冲突区域边界框
     * @returns {Array} 切割后的多边形
     */
    conservativeCutPolygon(polygon, keepBounds, conflictBounds) {
        if (this.config.debug) {
            console.log(`🛡️ 执行保守多边形切割`);
        }

        const cutPolygon = [];

        for (const vertex of polygon) {
            const [x, z] = vertex;

            // 保守策略：只移除明显超出保留区域很远的顶点
            const margin = this.actualGridSize; // 给一个栅格大小的容错

            // 如果顶点在冲突区域外，直接保留
            if (x < conflictBounds.minX || x > conflictBounds.maxX ||
                z < conflictBounds.minZ || z > conflictBounds.maxZ) {
                cutPolygon.push(vertex);
            }
            // 如果顶点在保留区域内或附近，保留
            else if (x >= keepBounds.minX - margin && x <= keepBounds.maxX + margin &&
                     z >= keepBounds.minZ - margin && z <= keepBounds.maxZ + margin) {
                cutPolygon.push(vertex);
            }
            // 否则移除
        }

        // 如果还是顶点太少，返回原始多边形
        if (cutPolygon.length < 3) {
            if (this.config.debug) {
                console.log(`⚠️ 保守切割后仍然顶点不足，保持原始边界`);
            }
            return polygon;
        }

        if (this.config.debug) {
            console.log(`✅ 保守切割完成: ${polygon.length} → ${cutPolygon.length} 个顶点`);
        }

        return cutPolygon;
    }

    /**
     * 应用解决方案到优化后的宣称数据（栅格化方法）
     * @param {Map} optimizedClaims - 优化后的宣称数据映射 Map<countryName, claimsResult>
     * @param {Object} resolution - 解决方案
     */
    applyResolution(optimizedClaims, resolution) {
        if (!resolution.success) {
            console.warn('⚠️ 解决方案无效，跳过应用');
            return;
        }

        console.log(`🔄 开始应用栅格化解决方案: ${resolution.conflictId}`);
        console.log(`📊 处理方法: ${resolution.method}`);
        console.log(`🎯 受影响的宣称: ${resolution.affectedClaims.join(', ')}`);

        if (resolution.method === 'grid-based-cutting' && resolution.modifiedPolygons) {
            this.applyGridBasedSolution(optimizedClaims, resolution);
        } else if (resolution.newBoundaries) {
            // 兼容旧的边界替换方法
            this.applyBoundaryReplacementSolution(optimizedClaims, resolution);
        } else {
            console.warn('⚠️ 未知的解决方案格式');
        }

        console.log(`✅ 解决方案应用完成: ${resolution.conflictId}`);
    }

    /**
     * 应用栅格化切割解决方案
     * @param {Map} optimizedClaims - 优化后的宣称数据映射
     * @param {Object} resolution - 解决方案
     */
    applyGridBasedSolution(optimizedClaims, resolution) {
        console.log(`🔧 应用栅格化切割方案`);
        console.log(`📐 处理了 ${resolution.processedCells} 个栅格单元`);
        console.log(`🎯 分配了 ${resolution.assignedCells} 个单元`);

        // 为每个受影响的国家处理多边形修改
        for (const [countryName, polygonData] of resolution.modifiedPolygons) {
            console.log(`🏛️ 处理国家: ${countryName}`);
            console.log(`📊 分配到的栅格单元: ${polygonData.cellCount} 个`);

            const claimsResult = optimizedClaims.get(countryName);
            if (!claimsResult || !claimsResult.success || !claimsResult.claims) {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称数据`);
                continue;
            }

            const countryClaims = claimsResult.claims;

            // 查找需要更新的宣称区域
            let updatedCount = 0;
            for (const claimId of resolution.affectedClaims) {
                const claimIndex = countryClaims.findIndex(claim => claim.id === claimId);
                if (claimIndex !== -1) {
                    const claim = countryClaims[claimIndex];
                    const oldArea = claim.metadata?.area || 0;

                    // 应用栅格化切割后的边界
                    if (polygonData.modifiedBoundary && polygonData.modifiedBoundary.length >= 3) {
                        claim.boundary = [...polygonData.modifiedBoundary]; // 深拷贝新边界
                        const newArea = GeometryUtils.calculatePolygonArea(claim.boundary);

                        claim.metadata = {
                            ...claim.metadata,
                            area: newArea,
                            boundaryType: 'grid-cut',
                            optimizedAt: new Date().toISOString(),
                            conflictId: resolution.conflictId,
                            originalArea: oldArea,
                            removedArea: polygonData.removedArea || 0,
                            assignedGridCells: polygonData.cellCount,
                            gridCellIds: polygonData.assignedCells,
                            cuttingMethod: polygonData.cuttingMethod,
                            optimizationMethod: 'grid-based-cutting'
                        };

                        console.log(`   新边界: ${claim.boundary.length} 个顶点, 面积: ${Math.round(newArea)}`);
                        console.log(`   移除面积: ${Math.round(polygonData.removedArea || 0)} 平方方块`);
                    } else {
                        // 如果切割失败，保持原始边界但标记为已处理
                        claim.metadata = {
                            ...claim.metadata,
                            boundaryType: 'grid-processed',
                            optimizedAt: new Date().toISOString(),
                            conflictId: resolution.conflictId,
                            originalArea: oldArea,
                            assignedGridCells: polygonData.cellCount,
                            gridCellIds: polygonData.assignedCells,
                            optimizationMethod: 'grid-based-cutting',
                            note: 'cutting-failed-boundary-preserved'
                        };

                        console.log(`   ⚠️ 切割失败，保持原始边界`);
                    }

                    console.log(`✅ 已更新国家 "${countryName}" 的宣称区域: ${claimId}`);
                    console.log(`   栅格单元: ${polygonData.cellCount} 个`);
                    console.log(`   原始面积: ${Math.round(oldArea)}`);
                    updatedCount++;
                } else {
                    console.warn(`⚠️ 未找到宣称区域: ${claimId}`);
                }
            }

            console.log(`📊 国家 "${countryName}" 更新了 ${updatedCount} 个宣称区域`);
        }
    }

    /**
     * 应用边界替换解决方案（兼容旧方法）
     * @param {Map} optimizedClaims - 优化后的宣称数据映射
     * @param {Object} resolution - 解决方案
     */
    applyBoundaryReplacementSolution(optimizedClaims, resolution) {
        console.log(`🔧 应用边界替换方案`);
        console.log(`📊 新边界数量: ${resolution.newBoundaries.size}`);

        // 为每个受影响的国家更新边界
        for (const [countryName, newBoundary] of resolution.newBoundaries) {
            console.log(`🏛️ 处理国家: ${countryName}`);
            console.log(`📐 新边界顶点数: ${newBoundary.length}`);

            const claimsResult = optimizedClaims.get(countryName);
            if (!claimsResult || !claimsResult.success || !claimsResult.claims) {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称数据`);
                continue;
            }

            const countryClaims = claimsResult.claims;

            // 查找需要更新的宣称区域
            let updatedCount = 0;
            for (const claimId of resolution.affectedClaims) {
                const claimIndex = countryClaims.findIndex(claim => claim.id === claimId);
                if (claimIndex !== -1) {
                    const oldBoundary = countryClaims[claimIndex].boundary;
                    const oldArea = countryClaims[claimIndex].metadata?.area || 0;

                    // 更新边界
                    countryClaims[claimIndex].boundary = [...newBoundary]; // 深拷贝边界

                    // 更新元数据
                    const newArea = GeometryUtils.calculatePolygonArea(newBoundary);
                    countryClaims[claimIndex].metadata = {
                        ...countryClaims[claimIndex].metadata,
                        area: newArea,
                        boundaryType: 'boundary-replaced',
                        optimizedAt: new Date().toISOString(),
                        conflictId: resolution.conflictId,
                        originalArea: oldArea,
                        originalBoundaryVertices: oldBoundary.length
                    };

                    console.log(`✅ 已更新国家 "${countryName}" 的宣称区域: ${claimId}`);
                    console.log(`   旧边界: ${oldBoundary.length} 个顶点, 面积: ${Math.round(oldArea)}`);
                    console.log(`   新边界: ${newBoundary.length} 个顶点, 面积: ${Math.round(newArea)}`);
                    updatedCount++;
                } else {
                    console.warn(`⚠️ 未找到宣称区域: ${claimId}`);
                }
            }

            console.log(`📊 国家 "${countryName}" 更新了 ${updatedCount} 个宣称区域`);
        }
    }

    /**
     * 计算边界框面积
     * @param {Object} bounds - 边界框
     * @returns {number} 面积
     */
    calculateBoundsArea(bounds) {
        return (bounds.maxX - bounds.minX) * (bounds.maxZ - bounds.minZ);
    }

    /**
     * 克隆宣称数据映射
     * @param {Map} claimsMap - 原始宣称数据映射 Map<countryName, claimsResult>
     * @returns {Map} 克隆的映射
     */
    cloneClaimsMap(claimsMap) {
        const cloned = new Map();

        for (const [countryName, claimsResult] of claimsMap) {
            if (claimsResult && claimsResult.success && claimsResult.claims) {
                const clonedClaims = claimsResult.claims.map(claim => ({
                    ...claim,
                    boundary: [...claim.boundary],
                    metadata: { ...claim.metadata }
                }));

                // 保持原有的 claimsResult 结构
                cloned.set(countryName, {
                    ...claimsResult,
                    claims: clonedClaims
                });
            } else {
                // 如果没有有效的 claims，直接复制原对象
                cloned.set(countryName, { ...claimsResult });
            }
        }

        return cloned;
    }

    /**
     * 生成优化报告
     * @param {Object} optimizationResult - 优化结果
     * @returns {Object} 详细报告
     */
    generateOptimizationReport(optimizationResult) {
        const report = {
            timestamp: new Date().toISOString(),
            success: optimizationResult.success,
            statistics: optimizationResult.statistics,
            details: {
                gridSize: this.config.gridSize,
                actualGridSize: this.actualGridSize,
                conflicts: []
            }
        };

        if (optimizationResult.conflicts) {
            report.details.conflicts = optimizationResult.conflicts.map(conflict => ({
                id: conflict.conflictId,
                countries: conflict.countries,
                assignedPoints: conflict.assignedPoints,
                affectedClaims: conflict.affectedClaims.length,
                originalArea: this.calculateBoundsArea(conflict.originalBounds),
                newBoundariesCount: conflict.newBoundaries ? conflict.newBoundaries.size : 0
            }));
        }

        return report;
    }

    /**
     * 验证优化结果
     * @param {Map} originalClaims - 原始宣称数据
     * @param {Map} optimizedClaims - 优化后宣称数据
     * @returns {Object} 验证结果
     */
    validateOptimization(originalClaims, optimizedClaims) {
        const validation = {
            success: true,
            issues: [],
            statistics: {
                originalConflicts: 0,
                remainingConflicts: 0,
                modifiedClaims: 0
            }
        };

        try {
            // 检查原始冲突数量
            const originalConflicts = this.detectAllConflicts(originalClaims);
            validation.statistics.originalConflicts = originalConflicts.length;

            // 检查优化后的冲突数量
            const remainingConflicts = this.detectAllConflicts(optimizedClaims);
            validation.statistics.remainingConflicts = remainingConflicts.length;

            // 统计修改的宣称数量
            let modifiedCount = 0;
            for (const [countryName, claimsResult] of optimizedClaims) {
                if (!claimsResult || !claimsResult.success || !claimsResult.claims) continue;

                const originalClaimsResult = originalClaims.get(countryName);
                const originalCountryClaims = originalClaimsResult && originalClaimsResult.success ?
                    originalClaimsResult.claims : [];

                const claims = claimsResult.claims;
                for (let i = 0; i < claims.length; i++) {
                    const optimizedClaim = claims[i];
                    const originalClaim = originalCountryClaims[i];

                    if (originalClaim &&
                        optimizedClaim.metadata.boundaryType === 'optimized') {
                        modifiedCount++;
                    }
                }
            }
            validation.statistics.modifiedClaims = modifiedCount;

            // 检查是否还有冲突
            if (remainingConflicts.length > 0) {
                validation.issues.push(`仍存在 ${remainingConflicts.length} 个未解决的冲突`);
            }

            // 检查数据完整性
            if (optimizedClaims.size !== originalClaims.size) {
                validation.issues.push('优化后国家数量发生变化');
                validation.success = false;
            }

            console.log('📊 优化验证完成:', validation.statistics);

        } catch (error) {
            validation.success = false;
            validation.issues.push(`验证过程出错: ${error.message}`);
        }

        return validation;
    }

    /**
     * 导出优化后的宣称数据
     * @param {Map} optimizedClaims - 优化后的宣称数据
     * @param {Object} metadata - 元数据
     * @returns {Object} 可序列化的数据对象
     */
    exportOptimizedClaims(optimizedClaims, metadata = {}) {
        const exportData = {
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            metadata: {
                optimizer: 'BoundaryOverlapOptimizer',
                gridSize: this.config.gridSize,
                actualGridSize: this.actualGridSize,
                ...metadata
            },
            countries: {}
        };

        for (const [countryName, claimsResult] of optimizedClaims) {
            if (claimsResult && claimsResult.success && claimsResult.claims) {
                exportData.countries[countryName] = claimsResult.claims.map(claim => ({
                    id: claim.id,
                    countryName: claim.countryName,
                    clusterIndex: claim.clusterIndex,
                    center: claim.center,
                    boundary: claim.boundary,
                    spawnPoints: claim.spawnPoints,
                    relatedAreas: claim.relatedAreas,
                    metadata: claim.metadata
                }));
            }
        }

        return exportData;
    }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BoundaryOverlapOptimizer;
} else if (typeof window !== 'undefined') {
    window.BoundaryOverlapOptimizer = BoundaryOverlapOptimizer;
}
