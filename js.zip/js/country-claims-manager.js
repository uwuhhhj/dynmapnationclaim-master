/**
 * 国家宣称管理器
 * 使用新的聚类算法和几何处理来生成和管理国家宣称范围
 *
 * @author Dynmap Territory System
 * @version 3.0.0
 */

class CountryClaimsManager {
    constructor(map, coordinateConverter, statusUpdater, options = {}) {
        this.map = map;
        this.coordinateConverter = coordinateConverter;
        this.updateStatus = statusUpdater;

        // 国家数据
        this.countrySpawnData = null;  // 出生点数据
        this.countryAreaData = null;   // 区域边界数据
        this.generatedClaims = new Map(); // 存储生成的宣称数据

        // 图层管理
        this.countryLayers = new Map(); // 存储每个国家的图层

        // 分步骤处理的中间数据存储
        this.stepData = {
            step1_originalTerritories: new Map(),    // 原始领地数据
            step2_bufferedTerritories: new Map(),    // 缓冲后的领地数据
            step3_mergedTerritories: new Map(),      // 合并后的领地数据
            step4_processedRegions: new Map(),       // 处理后的多区域数据
            step5_formattedClaims: new Map(),        // 格式化后的宣称数据
            currentStep: 0,                          // 当前执行到的步骤
            stepStatus: new Map()                    // 每个步骤的执行状态
        };

        // 分步骤渲染的图层管理
        this.stepRenderLayers = new Map(); // 存储每个步骤的渲染图层

        // 初始化宣称范围生成器
        this.claimsGenerator = new CountryClaimsGenerator({
            maxBreakDistance: options.maxBreakDistance || this.getConfiguredMaxBreakDistance(),
            bufferDistance: options.bufferDistance || this.getConfiguredBufferDistance(),
            algorithm: options.clusteringAlgorithm || 'simple',
            enableMerging: options.enableMerging !== false,
            useConvexHull: options.useConvexHull !== false,
            debug: options.debug || false
        });

        // 初始化边界重叠优化器
        this.overlapOptimizer = new BoundaryOverlapOptimizer({
            gridSize: options.gridSize || 4, // 4区块为单位
            samplingDensity: options.samplingDensity || 1,
            debug: options.debug !== false // 默认启用调试模式
        });

        // 初始化渲染器
        this.renderer = new CountryClaimsRenderer(map, coordinateConverter, {
            styles: {
                default: {
                    color: '#ff6b6b',
                    fillColor: '#ff6b6b',
                    fillOpacity: 0.2,
                    weight: 3,
                    opacity: 0.8
                },
                hover: {
                    color: '#ff3333',
                    fillColor: '#ff3333',
                    fillOpacity: 0.3,
                    weight: 4,
                    opacity: 1.0
                },
                selected: {
                    color: '#ff0000',
                    fillColor: '#ff0000',
                    fillOpacity: 0.4,
                    weight: 5,
                    opacity: 1.0
                },
                optimized: {
                    color: '#4CAF50',
                    fillColor: '#4CAF50',
                    fillOpacity: 0.25,
                    weight: 3,
                    opacity: 0.9
                }
            },
            ...options
        });

        // 设置渲染器事件回调
        this.setupRendererCallbacks();

        // UI 元素缓存
        this.uiElements = {
            countrySelect: null,
            statusDisplay: null
        };

        // 初始化 UI 元素
        this.initializeUIElements();
    }

    /**
     * 设置渲染器事件回调
     */
    setupRendererCallbacks() {
        this.renderer.on('claimRendered', (countryName, layers) => {
            console.log(`✅ 国家 "${countryName}" 宣称范围已渲染，图层数: ${layers.length}`);
            this.updateStatus('success', `已显示国家 "${countryName}" 的宣称范围`);
        });

        this.renderer.on('claimClicked', (countryName, layer, event) => {
            console.log(`🖱️ 点击了国家 "${countryName}" 的宣称范围`);
            this.highlightCountry(countryName);
        });

        this.renderer.on('claimHovered', (countryName, layer, event) => {
            console.log(`🖱️ 悬停在国家 "${countryName}" 的宣称范围上`);
        });

        this.renderer.on('error', (error, countryName) => {
            console.error(`❌ 渲染国家 "${countryName}" 失败:`, error);
            this.updateStatus('error', `渲染失败: ${error.message}`);
        });
    }

    /**
     * 初始化 UI 元素
     */
    initializeUIElements() {
        this.uiElements.countrySelect = document.getElementById('country-select');
        this.uiElements.statusDisplay = document.getElementById('status-display');

        if (!this.uiElements.countrySelect) {
            console.warn('⚠️ 未找到国家选择下拉菜单元素 (country-select)');
        }
    }

    /**
     * 加载国家数据（包括出生点和区域数据）
     * @returns {Promise<boolean>} 是否加载成功
     */
    async loadCountryData() {
        this.updateStatus('info', '正在加载国家数据...');

        try {
            // 从IndexedDB获取国家出生点数据
            const countrySpawn = await getStoredCountrySpawn();
            // 从IndexedDB获取国家区域数据
            const countryAreas = await getStoredCountryAreas();

            if (!countrySpawn && !countryAreas) {
                this.updateStatus('error', '未找到国家数据，请先加载领地数据');
                return false;
            }

            this.countrySpawnData = countrySpawn || {};
            this.countryAreaData = countryAreas || {};

            // 清除之前生成的宣称数据
            this.generatedClaims.clear();

            this.updateCountryList();

            const spawnCountryCount = Object.keys(this.countrySpawnData).length;
            const areaCountryCount = Object.keys(this.countryAreaData).length;

            this.updateStatus('success',
                `成功加载 ${spawnCountryCount} 个国家的出生点数据，${areaCountryCount} 个国家的区域数据`);

            console.log('📊 国家数据加载完成:', {
                spawnCountryCount,
                areaCountryCount,
                spawnCountries: Object.keys(this.countrySpawnData),
                areaCountries: Object.keys(this.countryAreaData)
            });

            return true;

        } catch (error) {
            console.error('❌ 加载国家数据失败:', error);
            this.updateStatus('error', `加载失败: ${error.message}`);
            return false;
        }
    }

    /**
     * 更新国家列表下拉菜单
     */
    updateCountryList() {
        if (!this.uiElements.countrySelect) {
            console.warn('⚠️ 国家选择下拉菜单元素不存在，跳过更新');
            return;
        }

        // 合并出生点数据、区域数据和存储的宣称数据中的国家
        const allCountries = new Set();

        if (this.countrySpawnData) {
            Object.keys(this.countrySpawnData).forEach(country => allCountries.add(country));
        }

        if (this.countryAreaData) {
            Object.keys(this.countryAreaData).forEach(country => allCountries.add(country));
        }

        // 也从存储的宣称数据中获取国家列表
        const storedClaims = getStoredCountryClaims();
        if (storedClaims) {
            Object.keys(storedClaims).forEach(country => allCountries.add(country));
        }

        if (allCountries.size === 0) {
            this.uiElements.countrySelect.innerHTML = '<option value="">选择国家...</option>';
            return;
        }

        let html = '<option value="">选择国家...</option>';

        // 按字母顺序排序国家名称
        const sortedCountries = Array.from(allCountries).sort();

        for (const countryName of sortedCountries) {
            const hasSpawn = this.countrySpawnData && this.countrySpawnData[countryName];
            const hasArea = this.countryAreaData && this.countryAreaData[countryName];
            const hasClaims = storedClaims && storedClaims[countryName];
            const dataTypes = [];

            if (hasSpawn) {
                const spawnCount = Object.keys(hasSpawn).length;
                dataTypes.push(`${spawnCount}个出生点`);
            }
            if (hasArea) {
                const areaCount = Object.keys(hasArea).length;
                dataTypes.push(`${areaCount}个区域`);
            }
            if (hasClaims) {
                const claimsCount = hasClaims.length;
                dataTypes.push(`${claimsCount}个宣称区域`);
            }

            const dataInfo = dataTypes.length > 0 ? ` (${dataTypes.join(', ')})` : '';
            html += `<option value="${countryName}">${countryName}${dataInfo}</option>`;
        }

        this.uiElements.countrySelect.innerHTML = html;

        console.log(`📋 国家列表已更新，共 ${sortedCountries.length} 个国家`);
    }

    /**
     * 显示选中国家的宣称范围（从存储数据中读取）
     */
    showSelectedCountryBoundary() {
        if (!this.uiElements.countrySelect) {
            this.updateStatus('error', '未找到国家选择元素');
            return;
        }

        const selectedCountry = this.uiElements.countrySelect.value;

        if (!selectedCountry) {
            this.updateStatus('warning', '请先选择一个国家');
            return;
        }

        this.showStoredCountryBoundary(selectedCountry);
    }

    /**
     * 显示指定国家的宣称范围（从存储数据中读取）
     * @param {string} countryName - 国家名称
     * @param {Object} options - 显示选项
     * @returns {Object} 渲染结果
     */
    async showStoredCountryBoundary(countryName, options = {}) {
        // 从 IndexedDB 获取存储的宣称数据
        const storedClaims = await getStoredCountryClaims();

        if (!storedClaims || !storedClaims[countryName]) {
            this.updateStatus('error', `未找到国家 "${countryName}" 的存储宣称数据，请先生成宣称数据`);
            return { success: false, error: '未找到存储的宣称数据' };
        }

        console.log(`🗺️ 开始显示国家 "${countryName}" 的宣称范围...`);

        try {
            const countryClaimsData = storedClaims[countryName];

            console.log(`🔍 检查国家 "${countryName}" 的存储数据格式:`, {
                dataType: typeof countryClaimsData,
                isArray: Array.isArray(countryClaimsData),
                length: countryClaimsData ? countryClaimsData.length : 0,
                firstItem: countryClaimsData && countryClaimsData[0] ? {
                    hasRings: !!countryClaimsData[0].rings,
                    hasXCoords: !!countryClaimsData[0].xCoords,
                    hasZCoords: !!countryClaimsData[0].zCoords,
                    keys: Object.keys(countryClaimsData[0])
                } : null
            });

            // 将存储的数据转换为渲染所需的格式
            const claims = countryClaimsData.map((claimData, index) => {
                let boundary;

                try {
                    if (claimData.rings && claimData.rings.length > 0) {
                        // 多环结构
                        console.log(`📐 处理数据 (区域 ${index + 1}): ${claimData.rings.length} 个环`);
                        boundary = claimData.rings.map(ring => {
                            if (!ring.xCoords || !ring.zCoords) {
                                console.warn(`⚠️ 环数据不完整:`, ring);
                                return [];
                            }
                            return ring.xCoords.map((x, i) =>
                                this.coordinateConverter.mcToMapCoords(x, ring.zCoords[i])
                            );
                        });
                    } else {
                        console.warn(`⚠️ 区域 ${index + 1} 数据格式不识别:`, claimData);
                        boundary = [];
                    }
                } catch (error) {
                    console.error(`❌ 处理区域 ${index + 1} 坐标数据时出错:`, error);
                    boundary = [];
                }

                return {
                    id: claimData.id || `${countryName}_claim_${claimData.regionIndex || index}`,
                    boundary: boundary,
                    area: claimData.area || 0,
                    center: claimData.center,
                    metadata: claimData.metadata || {}
                };
            });

            // 渲染宣称范围（单个国家显示时允许自动缩放，除非明确禁用）
            const renderResult = this.renderGeneratedClaims(countryName, claims, options);

            if (renderResult.success) {
                console.log(`✅ 国家 "${countryName}" 宣称范围显示完成:`, {
                    claimsCount: claims.length,
                    renderLayers: renderResult.layers.length
                });

                this.updateStatus('success',
                    `已显示国家 "${countryName}" 的宣称范围 (${claims.length} 个区域)`);
            } else {
                console.error(`❌ 国家 "${countryName}" 宣称范围显示失败:`, renderResult);
                this.updateStatus('error', `显示失败: ${renderResult.error}`);
            }

            return renderResult;

        } catch (error) {
            console.error(`❌ 显示国家 "${countryName}" 宣称范围时发生错误:`, error);
            this.updateStatus('error', `显示失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    /**
     * 显示指定国家的宣称范围（使用新的生成算法）- 保留用于生成数据时使用
     * @param {string} countryName - 国家名称
     * @param {Object} options - 显示选项
     * @returns {Object} 渲染结果
     */
    async showCountryBoundary(countryName, options = {}) {
        // 检查是否有该国家的数据
        const hasSpawnData = this.countrySpawnData && this.countrySpawnData[countryName];
        const hasAreaData = this.countryAreaData && this.countryAreaData[countryName];

        if (!hasSpawnData && !hasAreaData) {
            this.updateStatus('error', `未找到国家 "${countryName}" 的数据`);
            return { success: false, error: '国家数据不存在' };
        }

        console.log(`🗺️ 开始生成并渲染国家 "${countryName}" 的宣称范围...`);

        try {
            // 生成宣称范围
            const claimsResult = this.generateCountryClaims(countryName);

            if (!claimsResult.success) {
                this.updateStatus('error', `生成国家 "${countryName}" 宣称范围失败: ${claimsResult.error}`);
                return claimsResult;
            }

            // 存储生成的宣称数据
            this.generatedClaims.set(countryName, claimsResult);

            // 渲染宣称范围
            const renderResult = this.renderGeneratedClaims(countryName, claimsResult.claims, options);

            if (renderResult.success) {
                console.log(`✅ 国家 "${countryName}" 宣称范围生成并渲染完成:`, {
                    claimsCount: claimsResult.claims.length,
                    renderLayers: renderResult.layers.length
                });

                this.updateStatus('success',
                    `已显示国家 "${countryName}" 的宣称范围 (${claimsResult.claims.length} 个区域)`);

                // 保存单个国家的宣称数据到 IndexedDB
                await this.saveClaimsToLocalStorage();
            } else {
                console.error(`❌ 国家 "${countryName}" 宣称范围渲染失败:`, renderResult);
                this.updateStatus('error', `渲染失败: ${renderResult.error}`);
            }

            return renderResult;

        } catch (error) {
            console.error(`❌ 处理国家 "${countryName}" 宣称范围时发生错误:`, error);
            this.updateStatus('error', `处理失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    /**
     * 生成国家的宣称范围
     * @param {string} countryName - 国家名称
     * @returns {Object} 生成结果
     */
    generateCountryClaims(countryName) {
        const spawnData = this.countrySpawnData ? this.countrySpawnData[countryName] : null;
        const areaData = this.countryAreaData ? this.countryAreaData[countryName] : null;

        return this.claimsGenerator.generateCountryClaims(countryName, spawnData, areaData);
    }

    /**
     * 渲染单个宣称边界
     * @param {string} countryName - 国家名称
     * @param {Object} claim - 单个宣称区域对象
     * @param {Object} options - 渲染选项
     * @returns {Array} 图层数组
     */
    renderClaimBoundary(countryName, claim, options = {}) {
        try {
            const layers = [];

            // 处理边界坐标 - 支持多环结构
            let mapBoundary;

            if (claim.boundary && claim.boundary.length > 0) {
                if (Array.isArray(claim.boundary[0]) && Array.isArray(claim.boundary[0][0])) {
                    // 多环结构，每个环已经是地图坐标
                    mapBoundary = claim.boundary;
                } else {
                    console.warn(`⚠️ 国家 "${countryName}" 的宣称区域 ${claim.id} 边界数据格式不支持`);
                    return [];
                }
            } else {
                console.warn(`⚠️ 国家 "${countryName}" 的宣称区域 ${claim.id} 没有有效的边界数据`);
                return [];
            }

            // 创建多边形图层
            const polygon = L.polygon(mapBoundary, {
                color: options.color || '#ff6b6b',
                fillColor: options.fillColor || '#ff6b6b',
                fillOpacity: options.fillOpacity || 0.2,
                weight: options.weight || 3,
                opacity: options.opacity || 0.8
            }).addTo(this.map);

            // 创建弹窗内容
            const popupContent = this.createClaimPopupContent(countryName, claim, 0);
            polygon.bindPopup(popupContent);

            // 添加事件监听
            polygon.on('click', (e) => {
                console.log(`🖱️ 点击了国家 "${countryName}" 的宣称区域 ${claim.id}`);
            });

            layers.push(polygon);

            // 将图层添加到国家图层管理中
            if (!this.countryLayers.has(countryName)) {
                this.countryLayers.set(countryName, []);
            }
            this.countryLayers.get(countryName).push(...layers);

            return layers;

        } catch (error) {
            console.error(`❌ 渲染国家 "${countryName}" 宣称区域 ${claim.id} 失败:`, error);
            return [];
        }
    }

    /**
     * 渲染生成的宣称范围
     * @param {string} countryName - 国家名称
     * @param {Array} claims - 宣称范围数组
     * @param {Object} options - 渲染选项
     * @returns {Object} 渲染结果
     */
    renderGeneratedClaims(countryName, claims, options = {}) {
        try {
            // 先清除该国家之前的图层（但不删除生成的宣称数据）
            this.clearCountryLayers(countryName);

            const layers = [];
            const mcToMapCoords = this.coordinateConverter.mcToMapCoords;

            for (let i = 0; i < claims.length; i++) {
                const claim = claims[i];

                // 处理边界坐标 - 支持多环结构
                let mapBoundary;

                if (claim.boundary && claim.boundary.length > 0) {
                    if (Array.isArray(claim.boundary[0]) && Array.isArray(claim.boundary[0][0])) {
                        // 多环结构，每个环已经是地图坐标
                        mapBoundary = claim.boundary;
                    } else {
                        console.warn(`⚠️ 国家 "${countryName}" 的宣称区域 ${i} 边界数据格式不支持`);
                        continue;
                    }
                } else {
                    console.warn(`⚠️ 国家 "${countryName}" 的宣称区域 ${i} 没有有效的边界数据`);
                    continue;
                }

                // 创建多边形图层
                const polygon = L.polygon(mapBoundary, {
                    color: options.color || '#ff6b6b',
                    fillColor: options.fillColor || '#ff6b6b',
                    fillOpacity: options.fillOpacity || 0.2,
                    weight: options.weight || 3,
                    opacity: options.opacity || 0.8
                }).addTo(this.map);

                // 创建弹窗内容
                const popupContent = this.createClaimPopupContent(countryName, claim, i);
                polygon.bindPopup(popupContent);

                // 添加事件监听
                polygon.on('click', (e) => {
                    console.log(`🖱️ 点击了国家 "${countryName}" 的宣称区域 ${i + 1}`);
                });

                layers.push(polygon);
            }

            // 存储图层到管理器中
            this.countryLayers.set(countryName, layers);

            // 调整视图以显示所有宣称范围（仅在未禁用自动缩放时）
            if (layers.length > 0 && !options.disableAutoFit) {
                const group = new L.featureGroup(layers);
                this.map.fitBounds(group.getBounds().pad(0.1));
            }

            return {
                success: true,
                countryName,
                layers,
                claimsCount: claims.length
            };

        } catch (error) {
            console.error(`❌ 渲染国家 "${countryName}" 宣称范围失败:`, error);
            return {
                success: false,
                error: error.message,
                countryName,
                layers: []
            };
        }
    }

    /**
     * 创建宣称区域的弹窗内容
     * @param {string} countryName - 国家名称
     * @param {Object} claim - 宣称数据
     * @param {number} index - 区域索引
     * @returns {string} HTML内容
     */
    createClaimPopupContent(countryName, claim, index) {
        const metadata = claim.metadata || {};
        const area = claim.area || metadata.area || 0;

        return `
            <div style="min-width: 250px;">
                <h4 style="margin: 0 0 10px 0; color: #2c3e50;">
                    🏛️ ${countryName} - 宣称区域 ${index + 1}
                </h4>
                <div style="margin-bottom: 8px;">
                    <strong>区域ID:</strong> ${claim.id || `${countryName}_claim_${index}`}
                </div>
                <div style="margin-bottom: 8px;">
                    <strong>区域面积:</strong> ${Math.round(area).toLocaleString()} 平方米
                </div>
                <div style="margin-bottom: 8px;">
                    <strong>缓冲距离:</strong> ${metadata.bufferDistance || 80} 方块
                </div>
                <div style="margin-bottom: 8px;">
                    <strong>区域类型:</strong> ${metadata.blockType || 'generated-claim'}
                </div>
                ${metadata.generatedAt ? `
                <div style="margin-bottom: 8px;">
                    <strong>生成时间:</strong> ${new Date(metadata.generatedAt).toLocaleString()}
                </div>
                ` : ''}
                <div style="font-size: 12px; color: #666; margin-top: 10px;">
                    基于领地多边形缓冲扩张生成
                </div>
            </div>
        `;
    }

    /**
     * 加载所有国家的领地多边形数据
     * @returns {Map} 国家名称 -> 多边形数组的映射
     */
    async loadAllCountryTerritories() {
        console.log('🗺️ 开始加载所有国家的领地多边形数据...');

        const allTerritories = new Map();

        if (!this.countryAreaData) {
            console.warn('⚠️ 没有国家区域数据');
            return allTerritories;
        }

        for (const [countryName, countryAreas] of Object.entries(this.countryAreaData)) {
            const territoryPolygons = [];

            // 处理每个国家的所有区域
            for (const [areaId, area] of Object.entries(countryAreas)) {
                if (area.x && area.z && area.x.length > 0) {
                    try {
                        // 验证坐标数据
                        if (area.x.length !== area.z.length) {
                            console.warn(`⚠️ 区域 ${areaId} 的 x 和 z 坐标数量不匹配`);
                            continue;
                        }

                        // 转换为 Turf.js 格式的多边形
                        const coordinates = [];
                        let hasValidCoords = false;

                        for (let i = 0; i < area.x.length; i++) {
                            const x = parseFloat(area.x[i]);
                            const z = parseFloat(area.z[i]);

                            // 验证坐标值
                            if (isFinite(x) && isFinite(z)) {
                                coordinates.push([x, z]);
                                hasValidCoords = true;
                            } else {
                                console.warn(`⚠️ 区域 ${areaId} 包含无效坐标: [${area.x[i]}, ${area.z[i]}]`);
                            }
                        }

                        // 确保有足够的有效坐标点
                        if (hasValidCoords && coordinates.length >= 3) {
                            // 确保多边形闭合
                            const firstPoint = coordinates[0];
                            const lastPoint = coordinates[coordinates.length - 1];
                            if (firstPoint[0] !== lastPoint[0] || firstPoint[1] !== lastPoint[1]) {
                                coordinates.push([firstPoint[0], firstPoint[1]]);
                            }

                            // 创建 Turf.js 多边形
                            const polygon = turf.polygon([coordinates]);

                            // 验证创建的多边形
                            if (this.isValidPolygon(polygon)) {
                                territoryPolygons.push(polygon);
                            } else {
                                console.warn(`⚠️ 区域 ${areaId} 生成的多边形无效`);
                            }
                        } else {
                            console.warn(`⚠️ 区域 ${areaId} 没有足够的有效坐标点 (需要至少3个)`);
                        }

                    } catch (error) {
                        console.warn(`⚠️ 处理区域 ${areaId} 时发生错误:`, error.message);
                    }
                }
            }

            if (territoryPolygons.length > 0) {
                allTerritories.set(countryName, territoryPolygons);
                console.log(`✅ 国家 "${countryName}" 加载了 ${territoryPolygons.length} 个领地多边形`);
            }
        }

        console.log(`📊 总共加载了 ${allTerritories.size} 个国家的领地数据`);
        return allTerritories;
    }

    /**
     * 生成并存储所有国家的宣称范围数据（不显示）
     * @returns {Object} 生成结果
     */
    async generateAndStoreAllCountryClaims() {
        // 检查必要的数据是否已加载
        if (!this.countrySpawnData && !this.countryAreaData) {
            this.updateStatus('error', '请先加载国家数据');
            return { success: false, error: '国家数据未加载' };
        }

        try {
            this.updateStatus('info', '正在生成国家宣称区域...');
            const allTerritories = await this.loadAllCountryTerritories();

            if (allTerritories.size === 0) {
                this.updateStatus('warning', '没有找到任何国家的领地数据');
                return { success: false, error: '没有领地数据' };
            }

            // 清除之前生成的宣称数据
            this.generatedClaims.clear();

            let successCount = 0;
            let failureCount = 0;
            const results = {};

            for (const [countryName, territoryPolygons] of allTerritories) {
                try {
                    const claims = this.generateClaimsForCountry(countryName, territoryPolygons);

                    if (claims && claims.length > 0) {
                        this.generatedClaims.set(countryName, {
                            success: true,
                            claims
                        });
                        successCount++;
                        results[countryName] = { success: true, claimsCount: claims.length };
                        console.log(`✅ ${countryName} 生成 ${claims.length} 个宣称区域`);
                    } else {
                        failureCount++;
                        results[countryName] = { success: false, error: '未生成任何宣称区域' };
                        console.warn(`⚠️ ${countryName} 未生成任何宣称区域`);
                    }
                } catch (error) {
                    failureCount++;
                    results[countryName] = { success: false, error: error.message };
                    console.error(`❌ ${countryName} 生成宣称区域失败:`, error);
                }
            }

            // 保存生成的宣称数据到本地存储
            if (successCount > 0) {
                this.updateStatus('info', '正在保存宣称数据到本地存储...');
                const saveResult = await this.saveClaimsToLocalStorage();

                if (saveResult.success) {
                    this.updateStatus('success',
                        `已成功生成并保存 ${successCount} 个国家的宣称区域数据${failureCount > 0 ? `，${failureCount} 个失败` : ''}`);
                } else {
                    this.updateStatus('warning',
                        `已生成 ${successCount} 个国家的宣称区域，但保存失败: ${saveResult.error}`);
                }
            } else {
                this.updateStatus('error', '所有国家的宣称区域生成都失败了');
            }

            return {
                success: successCount > 0,
                total: allTerritories.size,
                successCount,
                failureCount,
                results
            };

        } catch (err) {
            console.error('❌ 生成宣称区域失败：', err);
            this.updateStatus('error', `生成失败：${err.message}`);
            return { success: false, error: err.message };
        }
    }

    /**
     * 为单个国家生成宣称区域
     * @param {string} countryName - 国家名称
     * @param {Array} territoryPolygons - 领地多边形数组
     * @returns {Array} 宣称区域数组
     */
    generateClaimsForCountry(countryName, territoryPolygons) {
        console.log(`🏛️ 为国家 "${countryName}" 生成宣称区域...`);

        try {
            // 第一步：验证和清理输入多边形
            const validPolygons = [];
            for (let i = 0; i < territoryPolygons.length; i++) {
                const poly = territoryPolygons[i];
                try {
                    // 验证多边形是否有效
                    if (this.isValidPolygon(poly)) {
                        // 清理多边形（移除重复点、确保闭合等）
                        const cleanedPoly = this.cleanPolygon(poly);
                        if (cleanedPoly) {
                            validPolygons.push(cleanedPoly);
                        }
                    }
                } catch (error) {
                    console.warn(`⚠️ 跳过无效多边形 ${i}:`, error.message);
                }
            }

            if (validPolygons.length === 0) {
                console.warn(`⚠️ 国家 "${countryName}" 没有有效的领地多边形`);
                return [];
            }

            console.log(`📐 国家 "${countryName}" 有 ${validPolygons.length} 个有效多边形`);

            // 第二步：对每个领地多边形进行缓冲扩张
            const bufferedPolygons = [];
            for (let i = 0; i < validPolygons.length; i++) {
                try {
                    const buffered = turf.buffer(validPolygons[i], 80, { units: 'meters' });
                    if (buffered && buffered.geometry) {
                        bufferedPolygons.push(buffered);
                    }
                } catch (error) {
                    console.warn(`⚠️ 多边形 ${i} 缓冲失败:`, error.message);
                }
            }

            if (bufferedPolygons.length === 0) {
                console.warn(`⚠️ 国家 "${countryName}" 没有成功缓冲的多边形`);
                return [];
            }

            // 第三步：安全地合并所有缓冲后的多边形
            let merged = bufferedPolygons[0];
            const failedMerges = [];

            for (let i = 1; i < bufferedPolygons.length; i++) {
                try {
                    const unionResult = turf.union(merged, bufferedPolygons[i]);
                    if (unionResult && unionResult.geometry) {
                        merged = unionResult;
                    } else {
                        console.warn(`⚠️ 合并多边形 ${i} 返回空结果`);
                        failedMerges.push(bufferedPolygons[i]);
                    }
                } catch (error) {
                    console.warn(`⚠️ 合并多边形 ${i} 失败:`, error.message);
                    // 保存失败的多边形，稍后单独处理
                    failedMerges.push(bufferedPolygons[i]);
                }
            }

            // 如果有合并失败的多边形，将它们作为独立的宣称区域
            if (failedMerges.length > 0) {
                console.log(`📝 国家 "${countryName}" 有 ${failedMerges.length} 个多边形无法合并，将作为独立区域处理`);
            }

            // 第四步：处理合并结果，支持 MultiPolygon
            const claims = [];
            let claimIndex = 0;

            // 处理成功合并的多边形
            if (merged && merged.geometry) {
                if (merged.geometry.type === 'Polygon') {
                    claims.push(this.createClaimObject(countryName, merged, claimIndex++));
                } else if (merged.geometry.type === 'MultiPolygon') {
                    merged.geometry.coordinates.forEach((coords) => {
                        try {
                            const subPoly = turf.polygon(coords);
                            claims.push(this.createClaimObject(countryName, subPoly, claimIndex++));
                        } catch (error) {
                            console.warn(`⚠️ 创建子多边形 ${claimIndex} 失败:`, error.message);
                        }
                    });
                }
            }

            // 处理无法合并的独立多边形
            failedMerges.forEach((polygon) => {
                try {
                    claims.push(this.createClaimObject(countryName, polygon, claimIndex++));
                } catch (error) {
                    console.warn(`⚠️ 创建独立多边形 ${claimIndex} 失败:`, error.message);
                }
            });

            console.log(`✅ 国家 "${countryName}" 生成了 ${claims.length} 个宣称区域`);
            return claims;

        } catch (error) {
            console.error(`❌ 国家 "${countryName}" 宣称区域生成失败:`, error);
            return [];
        }
    }

    /**
     * 创建宣称区域对象
     * @param {string} countryName - 国家名称
     * @param {Object} turfPolygon - Turf.js 多边形对象
     * @param {number} index - 区域索引
     * @returns {Object} 宣称区域对象
     */
    createClaimObject(countryName, turfPolygon, index) {
        return {
            id: `${countryName}_claim_${index}`,
            boundary: this.convertToLeafletRings(turfPolygon), // Leaflet 格式坐标
            area: turf.area(turfPolygon),
            sourceGeometry: turfPolygon,
            metadata: {
                generatedAt: new Date().toISOString(),
                bufferDistance: 80,
                blockType: 'generated-claim',
                partIndex: index
            }
        };
    }

    /**
     * 将 Turf.js 多边形转换为 Leaflet 格式的坐标环
     * @param {Object} turfPolygon - Turf.js 多边形对象
     * @returns {Array} Leaflet 格式的坐标环数组
     */
    convertToLeafletRings(turfPolygon) {
        const coordinates = turfPolygon.geometry.coordinates;

        return coordinates.map(ring =>
            ring.map(([lng, lat]) => {
                // 转换为地图坐标系
                return this.coordinateConverter.mcToMapCoords(lng, lat);
            })
        );
    }

    /**
     * 显示所有国家的宣称范围（仅从存储的数据中读取）
     * @param {Object} options - 显示选项
     * @returns {Object} 批量渲染结果
     */
    async showAllCountryBoundaries(options = {}) {
        // 从 IndexedDB 获取存储的宣称数据
        const storedClaims = await getStoredCountryClaims();

        if (!storedClaims || Object.keys(storedClaims).length === 0) {
            this.updateStatus('error', '未找到存储的宣称数据，请先生成宣称数据');
            return { success: false, error: '未找到存储的宣称数据' };
        }

        const countries = Object.keys(storedClaims);
        const results = {};
        let successCount = 0;
        let failureCount = 0;

        this.updateStatus('info', `正在显示 ${countries.length} 个国家的宣称范围...`);

        for (const countryName of countries) {
            try {
                const countryClaimsData = storedClaims[countryName];

                // 将存储的数据转换为渲染所需的格式
                const claims = countryClaimsData.map(claimData => {
                    let boundary;

                    if (claimData.rings && claimData.rings.length > 0) {
                        // 多环结构
                        boundary = claimData.rings.map(ring =>
                            ring.xCoords.map((x, i) =>
                                this.coordinateConverter.mcToMapCoords(x, ring.zCoords[i])
                            )
                        );
                    } else {
                        boundary = [];
                    }

                    return {
                        id: claimData.id || `${countryName}_claim_${claimData.regionIndex}`,
                        boundary: boundary,
                        area: claimData.area || 0,
                        metadata: claimData.metadata || {}
                    };
                });

                // 渲染宣称范围（禁用自动缩放）
                const renderOptions = { ...options, disableAutoFit: true };
                const renderResult = this.renderGeneratedClaims(countryName, claims, renderOptions);

                if (renderResult.success) {
                    successCount++;
                    console.log(`✅ 国家 "${countryName}" 宣称范围显示完成 (${claims.length} 个区域)`);
                } else {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 宣称范围显示失败:`, renderResult.error);
                }

                results[countryName] = renderResult;

            } catch (error) {
                failureCount++;
                console.error(`❌ 显示国家 "${countryName}" 宣称范围时发生错误:`, error);
                results[countryName] = { success: false, error: error.message };
            }
        }

        const summary = {
            success: failureCount === 0,
            total: countries.length,
            successCount,
            failureCount,
            results
        };

        if (summary.success) {
            this.updateStatus('success', `成功显示所有 ${successCount} 个国家的宣称范围`);
        } else {
            this.updateStatus('warning', `显示完成: ${successCount} 成功, ${failureCount} 失败`);
        }

        console.log('📊 批量显示结果:', summary);
        return summary;
    }

    /**
     * 清除指定国家的图层（不删除生成的宣称数据）
     * @param {string} countryName - 国家名称
     */
    clearCountryLayers(countryName) {
        let layersCleared = 0;

        // 清除 CountryClaimsManager 直接管理的图层
        const layers = this.countryLayers.get(countryName);
        if (layers) {
            layers.forEach(layer => {
                this.map.removeLayer(layer);
                layersCleared++;
            });
            this.countryLayers.delete(countryName);
        }

        // 清除渲染器管理的图层
        if (this.renderer && this.renderer.clearCountryClaims) {
            this.renderer.clearCountryClaims(countryName);
        }

        console.log(`🗑️ 已清除国家 "${countryName}" 的图层，清除了 ${layersCleared} 个图层`);
        return layersCleared;
    }

    /**
     * 清除指定国家的宣称范围（包括图层和生成的数据）
     * @param {string} countryName - 国家名称
     */
    clearCountryBoundary(countryName) {
        // 先清除图层
        const layersCleared = this.clearCountryLayers(countryName);

        // 清除生成的宣称数据
        this.generatedClaims.delete(countryName);

        this.updateStatus('info', `已清除国家 "${countryName}" 的宣称范围 (${layersCleared} 个图层)`);
        console.log(`🗑️ 已清除国家 "${countryName}" 的宣称范围，清除了 ${layersCleared} 个图层`);
    }

    /**
     * 清除所有国家宣称范围（仅清除显示图层，不删除存储数据）
     */
    clearCountryBoundaries() {
        let totalLayersCleared = 0;

        // 清除通过 CountryClaimsManager 直接管理的图层
        for (const [countryName, layers] of this.countryLayers) {
            layers.forEach(layer => {
                this.map.removeLayer(layer);
                totalLayersCleared++;
            });
        }
        this.countryLayers.clear();

        // 清除渲染器管理的图层
        if (this.renderer && this.renderer.clearAllClaims) {
            const rendererStats = this.renderer.getRenderStats ? this.renderer.getRenderStats() : { totalLayers: 0 };
            this.renderer.clearAllClaims();
            totalLayersCleared += rendererStats.totalLayers;
        }

        // 备用方法：清除地图上的所有多边形图层
        this.clearAllPolygonLayers();

        // 清除所有生成的宣称数据（内存中的）
        this.generatedClaims.clear();

        this.updateStatus('info', `已清除所有国家宣称范围显示 (共 ${totalLayersCleared} 个图层)`);
        console.log('🗑️ 已清除所有国家宣称范围显示，总计:', totalLayersCleared, '个图层');
    }

    /**
     * 清除存储的国家宣称数据
     */
    async clearStoredCountryClaims() {
        try {
            console.log('🗑️ 开始清除所有国家宣称数据...');

            // 1. 先清除显示的图层
            this.clearCountryBoundaries();

            // 2. 清除内存中的生成数据
            this.generatedClaims.clear();
            console.log('🗑️ 已清除内存中的生成数据');

            // 3. 清除 IndexedDB 中的宣称数据
            if (typeof clearStoredCountryClaims === 'function') {
                const deleteSuccess = await clearStoredCountryClaims();
                if (deleteSuccess) {
                    console.log('✅ 已成功删除 IndexedDB 中的国家宣称数据');

                    // 验证删除结果
                    if (typeof verifyCountryClaimsCleared === 'function') {
                        const isCleared = await verifyCountryClaimsCleared();
                        if (!isCleared) {
                            console.error('❌ 验证失败：数据未完全清除');
                            this.updateStatus('error', '删除验证失败：数据未完全清除');
                            return;
                        }
                    }
                } else {
                    console.error('❌ IndexedDB 删除操作失败');
                    this.updateStatus('error', '删除失败：IndexedDB 操作失败');
                    return;
                }
            } else {
                console.error('❌ clearStoredCountryClaims 函数不存在');
                this.updateStatus('error', '删除失败：清除函数不存在');
                return;
            }

            // 4. 重置优化状态（如果存在）
            if (typeof optimizationState !== 'undefined') {
                optimizationState.conflicts = [];
                optimizationState.gridCells.clear();
                optimizationState.cellAssignments.clear();
                optimizationState.cuttingResults.clear();
                optimizationState.claimBlocks.clear();
                optimizationState.conflictAreas.clear();
                optimizationState.cleanedClaimBlocks.clear();
                optimizationState.mergedClaimBlocks.clear();
                optimizationState.finalBoundaries.clear();
                console.log('🗑️ 已重置优化状态');
            }

            // 5. 更新国家列表下拉菜单
            this.updateCountryList();

            // 6. 清除冲突区域可视化图层
            if (typeof window !== 'undefined' && window.conflictAreaLayers) {
                window.conflictAreaLayers.forEach(layer => {
                    if (this.map.hasLayer(layer)) {
                        this.map.removeLayer(layer);
                    }
                });
                window.conflictAreaLayers = [];
                console.log('🗑️ 已清除冲突区域可视化图层');
            }

            this.updateStatus('success', '已删除所有存储的国家宣称数据');
            console.log('✅ 国家宣称数据清除完成');

        } catch (error) {
            console.error('❌ 清除存储的国家宣称数据失败:', error);
            this.updateStatus('error', `删除失败: ${error.message}`);
        }
    }

    /**
     * 清除地图上的所有多边形图层（备用方法）
     */
    clearAllPolygonLayers() {
        this.map.eachLayer((layer) => {
            if (layer instanceof L.Polygon) {
                this.map.removeLayer(layer);
            }
        });
    }

    /**
     * 只清除显示的图层，保留数据
     */
    clearDisplayedLayers() {
        let totalLayersCleared = 0;

        // 清除通过 CountryClaimsManager 直接管理的图层
        for (const [countryName, layers] of this.countryLayers) {
            layers.forEach(layer => {
                this.map.removeLayer(layer);
                totalLayersCleared++;
            });
        }
        this.countryLayers.clear();

        // 清除渲染器管理的图层
        if (this.renderer && this.renderer.clearAllClaims) {
            const rendererStats = this.renderer.getRenderStats ? this.renderer.getRenderStats() : { totalLayers: 0 };
            this.renderer.clearAllClaims();
            totalLayersCleared += rendererStats.totalLayers;
        }

        // 备用方法：清除地图上的所有多边形图层
        this.clearAllPolygonLayers();

        console.log('🗑️ 已清除显示图层，总计:', totalLayersCleared, '个图层（保留数据）');
        return totalLayersCleared;
    }

    /**
     * 显示当前内存中的宣称数据（包括优化后的数据）
     * @param {Object} options - 显示选项
     * @returns {Object} 渲染结果
     */
    showCurrentGeneratedClaims(options = {}) {
        console.log('🗺️ 开始显示当前生成的宣称数据...');

        if (this.generatedClaims.size === 0) {
            this.updateStatus('warning', '没有可显示的宣称数据');
            return { success: false, error: '没有可显示的宣称数据' };
        }

        const results = {};
        let successCount = 0;
        let failureCount = 0;

        this.updateStatus('info', `正在显示 ${this.generatedClaims.size} 个国家的宣称范围...`);

        for (const [countryName, claimsResult] of this.generatedClaims) {
            try {
                if (claimsResult && claimsResult.success && claimsResult.claims) {
                    // 渲染宣称范围（禁用自动缩放）
                    const renderOptions = { ...options, disableAutoFit: true };
                    const renderResult = this.renderGeneratedClaims(countryName, claimsResult.claims, renderOptions);

                    if (renderResult.success) {
                        successCount++;
                        console.log(`✅ 国家 "${countryName}" 宣称范围显示完成 (${claimsResult.claims.length} 个区域)`);
                    } else {
                        failureCount++;
                        console.error(`❌ 国家 "${countryName}" 宣称范围显示失败:`, renderResult.error);
                    }

                    results[countryName] = renderResult;
                } else {
                    failureCount++;
                    console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称数据`);
                    results[countryName] = { success: false, error: '没有有效的宣称数据' };
                }

            } catch (error) {
                failureCount++;
                console.error(`❌ 显示国家 "${countryName}" 宣称范围时发生错误:`, error);
                results[countryName] = { success: false, error: error.message };
            }
        }

        const summary = {
            success: failureCount === 0,
            total: this.generatedClaims.size,
            successCount,
            failureCount,
            results
        };

        if (summary.success) {
            this.updateStatus('success', `成功显示所有 ${successCount} 个国家的宣称范围`);
        } else {
            this.updateStatus('warning', `显示完成: ${successCount} 成功, ${failureCount} 失败`);
        }

        console.log('📊 当前宣称数据显示结果:', summary);
        return summary;
    }

    /**
     * 高亮显示指定国家
     * @param {string} countryName - 国家名称
     */
    highlightCountry(countryName) {
        // 先取消所有高亮
        this.renderer.unhighlightAll();
        // 高亮指定国家
        this.renderer.highlightCountry(countryName);
        console.log(`🔆 高亮显示国家: ${countryName}`);
    }

    /**
     * 取消所有高亮
     */
    unhighlightAll() {
        this.renderer.unhighlightAll();
        console.log('🔅 已取消所有高亮显示');
    }

    /**
     * 调整视图以适应指定国家
     * @param {string} countryName - 国家名称
     */
    fitViewToCountry(countryName) {
        this.renderer.fitViewToCountry(countryName);
        console.log(`🎯 视图已调整到国家: ${countryName}`);
    }

    /**
     * 获取国家数量
     * @returns {number} 国家数量
     */
    getCountryCount() {
        return this.countryData ? Object.keys(this.countryData).length : 0;
    }

    /**
     * 获取已渲染的国家数量
     * @returns {number} 已渲染的国家数量
     */
    getRenderedCountryCount() {
        return this.renderer.getRenderStats().renderedCountries;
    }

    /**
     * 获取渲染统计信息
     * @returns {Object} 统计信息
     */
    getStats() {
        const renderStats = this.renderer.getRenderStats();
        return {
            totalCountries: this.getCountryCount(),
            renderedCountries: renderStats.renderedCountries,
            totalLayers: renderStats.totalLayers,
            countries: renderStats.countries,
            layersByCountry: renderStats.layersByCountry
        };
    }

    /**
     * 检查国家是否已渲染
     * @param {string} countryName - 国家名称
     * @returns {boolean} 是否已渲染
     */
    isCountryRendered(countryName) {
        return this.renderer.isCountryRendered(countryName);
    }

    /**
     * 获取当前生成的宣称数据状态（调试用）
     * @returns {Object} 状态信息
     */
    getGeneratedClaimsStatus() {
        const status = {
            totalCountries: this.generatedClaims.size,
            countries: Array.from(this.generatedClaims.keys()),
            details: {}
        };

        for (const [countryName, claimsResult] of this.generatedClaims) {
            status.details[countryName] = {
                success: claimsResult.success,
                claimsCount: claimsResult.claims ? claimsResult.claims.length : 0,
                hasData: !!(claimsResult.claims && claimsResult.claims.length > 0)
            };
        }

        console.log('🔍 当前生成的宣称数据状态:', status);
        return status;
    }

    /**
     * 手动保存当前显示的所有国家宣称数据到 IndexedDB
     * @returns {Promise<Object>} 保存结果
     */
    async saveAllDisplayedClaimsToLocalStorage() {
        try {
            // 先检查状态
            const status = this.getGeneratedClaimsStatus();

            if (this.generatedClaims.size === 0) {
                this.updateStatus('warning', '当前没有显示的国家宣称数据可保存');
                return { success: false, error: '没有数据可保存' };
            }

            const result = await this.saveClaimsToLocalStorage();

            if (result !== false) {
                const totalCountries = this.generatedClaims.size;
                const totalRegions = Array.from(this.generatedClaims.values())
                    .reduce((sum, claimsResult) => sum + (claimsResult.claims ? claimsResult.claims.length : 0), 0);

                console.log(`💾 手动保存完成: ${totalCountries} 个国家, ${totalRegions} 个宣称区域`);
                this.updateStatus('success', `手动保存完成: ${totalCountries} 个国家, ${totalRegions} 个宣称区域`);

                return {
                    success: true,
                    totalCountries,
                    totalRegions,
                    countries: Array.from(this.generatedClaims.keys())
                };
            } else {
                return { success: false, error: '保存过程中发生错误' };
            }

        } catch (error) {
            console.error('❌ 手动保存国家宣称数据失败:', error);
            this.updateStatus('error', `手动保存失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    /**
     * 将生成的宣称区域数据保存到 IndexedDB
     */
    async saveClaimsToLocalStorage() {
        try {
            const countryClaimsData = {};

            // 遍历所有生成的宣称数据
            for (const [countryName, claimsResult] of this.generatedClaims) {
                if (claimsResult.success && claimsResult.claims && claimsResult.claims.length > 0) {
                    const claimsForStorage = [];

                    // 处理每个宣称区域
                    for (let i = 0; i < claimsResult.claims.length; i++) {
                        const claim = claimsResult.claims[i];

                        // 提取坐标数据 - 新格式支持多环（外环+内环）
                        const rings = [];

                        if (claim.boundary && claim.boundary.length > 0) {
                            // claim.boundary 是 Leaflet 格式的坐标环数组
                            // 每个环是 [lat, lng] 坐标点的数组
                            claim.boundary.forEach(ring => {
                                const ringCoords = {
                                    xCoords: [],
                                    zCoords: []
                                };

                                ring.forEach(point => {
                                    // 从地图坐标转换回 MC 坐标
                                    const mcCoords = this.coordinateConverter.mapToMcCoords(point[0], point[1]);
                                    // mapToMcCoords 返回 {x: ..., z: ...} 格式
                                    ringCoords.xCoords.push(mcCoords.x);
                                    ringCoords.zCoords.push(mcCoords.z);
                                });

                                rings.push(ringCoords);
                            });
                        }

                        // 构建宣称区域数据
                        const claimData = {
                            id: claim.id,
                            regionIndex: i + 1,
                            rings: rings, // 支持多环结构
                            area: claim.area,
                            metadata: {
                                ...claim.metadata,
                                generatedAt: claim.metadata.generatedAt,
                                bufferDistance: claim.metadata.bufferDistance,
                                blockType: claim.metadata.blockType,
                                partIndex: claim.metadata.partIndex
                            }
                        };

                        claimsForStorage.push(claimData);
                    }

                    countryClaimsData[countryName] = claimsForStorage;
                }
            }

            // 保存到 IndexedDB
            console.log('🔍 检查 setStoredCountryClaims 函数可用性:', {
                typeofResult: typeof setStoredCountryClaims,
                isFunction: typeof setStoredCountryClaims === 'function',
                exists: typeof setStoredCountryClaims !== 'undefined'
            });

            if (typeof setStoredCountryClaims === 'function') {
                console.log('💾 开始保存数据到 IndexedDB...');
                await setStoredCountryClaims(countryClaimsData);

                const totalCountries = Object.keys(countryClaimsData).length;
                const totalRegions = Object.values(countryClaimsData).reduce((sum, claims) => sum + claims.length, 0);

                console.log(`💾 已保存 ${totalCountries} 个国家的宣称区域数据到 IndexedDB (共 ${totalRegions} 个区域)`);

                return {
                    success: true,
                    totalCountries,
                    totalRegions,
                    countries: Object.keys(countryClaimsData)
                };
            } else {
                console.error('❌ setStoredCountryClaims 函数不存在或不可用');
                console.error('   函数类型:', typeof setStoredCountryClaims);
                console.error('   全局对象中的函数:', typeof window.setStoredCountryClaims);
                return { success: false, error: '存储函数不存在' };
            }

        } catch (error) {
            console.error('❌ 保存宣称区域数据到 IndexedDB 失败:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * 优化所有国家的宣称边界，解决重叠问题
     * @param {Object} options - 优化选项
     * @returns {Object} 优化结果
     */
    async optimizeBoundaryOverlaps(options = {}) {
        console.log('🚀 开始边界重叠优化...');
        this.updateStatus('info', '正在检测和优化边界重叠...');

        try {
            // 检查是否有生成的宣称数据
            if (this.generatedClaims.size === 0) {
                throw new Error('没有可用的宣称数据，请先生成国家宣称范围');
            }

            // 准备国家区域数据映射
            const countryAreaDataMap = new Map();
            if (this.countryAreaData) {
                for (const [countryName, areaData] of Object.entries(this.countryAreaData)) {
                    countryAreaDataMap.set(countryName, areaData);
                }
            }

            // 执行边界优化
            const optimizationResult = this.overlapOptimizer.optimizeBoundaries(
                this.generatedClaims,
                countryAreaDataMap
            );

            if (optimizationResult.success) {
                // 保存原始数据用于验证
                const originalClaims = new Map(this.generatedClaims);

                // 更新生成的宣称数据
                this.generatedClaims = optimizationResult.optimizedClaims;

                console.log('🔄 已更新 generatedClaims，当前数据:');
                for (const [countryName, claimsResult] of this.generatedClaims) {
                    if (claimsResult && claimsResult.success && claimsResult.claims) {
                        console.log(`  ${countryName}: ${claimsResult.claims.length} 个宣称区域`);
                        claimsResult.claims.forEach((claim, i) => {
                            console.log(`    区域${i+1}: ${claim.metadata?.boundaryType || 'unknown'} (${claim.boundary?.length || 0} 个顶点)`);
                        });
                    }
                }

                // 生成优化报告
                const report = this.overlapOptimizer.generateOptimizationReport(optimizationResult);

                // 验证优化结果（使用正确的参数）
                const validation = this.overlapOptimizer.validateOptimization(
                    originalClaims,
                    this.generatedClaims
                );

                console.log('✅ 边界重叠优化完成:', optimizationResult.statistics);
                console.log('📊 优化报告:', report);
                console.log('🔍 验证结果:', validation);

                // 清除当前显示的图层（但保留数据）
                this.clearDisplayedLayers();

                this.updateStatus('success',
                    `边界优化完成：解决了 ${optimizationResult.statistics.resolvedConflicts} 个冲突，` +
                    `影响 ${optimizationResult.statistics.affectedCountries} 个国家`
                );

                return {
                    success: true,
                    result: optimizationResult,
                    report,
                    validation
                };

            } else {
                throw new Error(optimizationResult.error || '边界优化失败');
            }

        } catch (error) {
            console.error('❌ 边界重叠优化失败:', error);
            this.updateStatus('error', `优化失败: ${error.message}`);

            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * 检测当前宣称数据中的重叠冲突
     * @returns {Object} 冲突检测结果
     */
    detectBoundaryConflicts() {
        console.log('🔍 开始检测边界冲突...');
        this.updateStatus('info', '正在检测边界冲突...');

        try {
            if (this.generatedClaims.size === 0) {
                return {
                    success: true,
                    conflicts: [],
                    message: '没有宣称数据可检测'
                };
            }

            const conflicts = this.overlapOptimizer.detectAllConflicts(this.generatedClaims);

            console.log(`🔍 冲突检测完成，发现 ${conflicts.length} 个冲突`);
            this.updateStatus('info', `检测到 ${conflicts.length} 个边界冲突`);

            return {
                success: true,
                conflicts,
                statistics: {
                    totalConflicts: conflicts.length,
                    affectedCountries: new Set(conflicts.flatMap(c => c.countries)).size
                }
            };

        } catch (error) {
            console.error('❌ 冲突检测失败:', error);
            this.updateStatus('error', `冲突检测失败: ${error.message}`);

            return {
                success: false,
                error: error.message,
                conflicts: []
            };
        }
    }

    /**
     * 保存优化后的宣称数据
     * @param {Object} options - 保存选项
     * @returns {Object} 保存结果
     */
    saveOptimizedClaims(options = {}) {
        console.log('💾 开始保存优化后的宣称数据...');
        this.updateStatus('info', '正在保存优化后的数据...');

        try {
            if (this.generatedClaims.size === 0) {
                throw new Error('没有可保存的宣称数据');
            }

            // 导出优化后的数据
            const exportData = this.overlapOptimizer.exportOptimizedClaims(
                this.generatedClaims,
                {
                    exportedBy: 'CountryClaimsManager',
                    exportOptions: options
                }
            );

            // 保存到localStorage（使用现有的保存逻辑）
            this.saveClaimsToStorage();

            // 如果需要，也可以保存为文件
            if (options.saveAsFile) {
                const blob = new Blob([JSON.stringify(exportData, null, 2)], {
                    type: 'application/json'
                });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `optimized-country-claims-${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }

            console.log('✅ 优化后的宣称数据保存完成');
            this.updateStatus('success', '优化后的宣称数据已保存');

            return {
                success: true,
                exportData,
                message: '数据保存成功'
            };

        } catch (error) {
            console.error('❌ 保存优化后的宣称数据失败:', error);
            this.updateStatus('error', `保存失败: ${error.message}`);

            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * 销毁管理器，清理所有资源
     */
    destroy() {
        if (this.renderer) {
            this.renderer.destroy();
            this.renderer = null;
        }

        this.countryData = null;
        this.uiElements = {};
        this.coordinateConverter = null;
        this.updateStatus = null;
        this.map = null;

        console.log('🗑️ 国家宣称管理器已销毁');
    }

    /**
     * 验证多边形是否有效
     * @param {Object} polygon - Turf.js 多边形对象
     * @returns {boolean} 是否有效
     */
    isValidPolygon(polygon) {
        if (!polygon || !polygon.geometry || !polygon.geometry.coordinates) {
            return false;
        }

        const coords = polygon.geometry.coordinates[0]; // 外环
        if (!Array.isArray(coords) || coords.length < 4) {
            return false;
        }

        // 检查坐标是否有效
        for (const coord of coords) {
            if (!Array.isArray(coord) || coord.length < 2) {
                return false;
            }
            const [lng, lat] = coord;
            if (typeof lng !== 'number' || typeof lat !== 'number') {
                return false;
            }
            if (!isFinite(lng) || !isFinite(lat)) {
                return false;
            }
        }

        return true;
    }

    /**
     * 清理多边形数据
     * @param {Object} polygon - Turf.js 多边形对象
     * @returns {Object|null} 清理后的多边形或null
     */
    cleanPolygon(polygon) {
        try {
            const coords = polygon.geometry.coordinates[0];
            const cleanedCoords = [];

            // 移除重复的连续点
            for (let i = 0; i < coords.length; i++) {
                const current = coords[i];
                const next = coords[i + 1];

                if (!next || current[0] !== next[0] || current[1] !== next[1]) {
                    cleanedCoords.push(current);
                }
            }

            // 确保多边形闭合
            if (cleanedCoords.length >= 3) {
                const first = cleanedCoords[0];
                const last = cleanedCoords[cleanedCoords.length - 1];

                if (first[0] !== last[0] || first[1] !== last[1]) {
                    cleanedCoords.push([first[0], first[1]]);
                }

                // 创建清理后的多边形
                return turf.polygon([cleanedCoords]);
            }

            return null;

        } catch (error) {
            console.warn('多边形清理失败:', error.message);
            return null;
        }
    }

    // ==================== 分步骤处理方法 ====================

    /**
     * 步骤1: 获取原始领地数据
     * @returns {Object} 执行结果
     */
    async step1_loadOriginalTerritories() {
        console.log('🚀 执行步骤1: 获取原始领地数据');

        try {
            this.updateStatus('info', '步骤1: 正在获取原始领地数据...');

            // 检查必要的数据是否已加载
            if (!this.countrySpawnData && !this.countryAreaData) {
                this.updateStatus('error', '请先加载国家数据');
                return { success: false, error: '国家数据未加载' };
            }

            // 加载所有国家的领地数据
            const allTerritories = await this.loadAllCountryTerritories();

            if (allTerritories.size === 0) {
                this.updateStatus('warning', '没有找到任何国家的领地数据');
                return { success: false, error: '没有领地数据' };
            }

            // 存储到步骤数据中
            this.stepData.step1_originalTerritories.clear();
            for (const [countryName, territoryPolygons] of allTerritories) {
                this.stepData.step1_originalTerritories.set(countryName, territoryPolygons);
            }

            this.stepData.currentStep = 1;
            this.stepData.stepStatus.set(1, { success: true, timestamp: new Date().toISOString() });

            const message = `步骤1完成: 已获取 ${allTerritories.size} 个国家的原始领地数据`;
            this.updateStatus('success', message);
            console.log(`✅ ${message}`);

            // 渲染步骤1的结果
            await this.renderStep1Results();

            return {
                success: true,
                countriesCount: allTerritories.size,
                data: allTerritories
            };

        } catch (error) {
            console.error('❌ 步骤1执行失败:', error);
            this.updateStatus('error', `步骤1失败: ${error.message}`);
            this.stepData.stepStatus.set(1, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 计算国家所有领地的总边界框
     * @param {Array} territoryPolygons - 领地多边形数组
     * @returns {Object|null} 边界框 {minX, maxX, minZ, maxZ}
     */
    calculateCountryBounds(territoryPolygons) {
        if (!territoryPolygons || territoryPolygons.length === 0) {
            return null;
        }

        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        for (const poly of territoryPolygons) {
            if (this.isValidPolygon(poly)) {
                const coords = poly.geometry.coordinates[0]; // 外环
                for (const [lng, lat] of coords) {
                    minX = Math.min(minX, lng);
                    maxX = Math.max(maxX, lng);
                    minZ = Math.min(minZ, lat);
                    maxZ = Math.max(maxZ, lat);
                }
            }
        }

        if (minX === Infinity || maxX === -Infinity || minZ === Infinity || maxZ === -Infinity) {
            return null;
        }

        return { minX, maxX, minZ, maxZ };
    }

    /**
     * 计算单个多边形的边界框
     * @param {Object} polygon - Turf.js 多边形对象
     * @returns {Object|null} 边界框 {minX, maxX, minZ, maxZ}
     */
    calculatePolygonBounds(polygon) {
        if (!this.isValidPolygon(polygon)) {
            return null;
        }

        let minX = Infinity, maxX = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;

        const coords = polygon.geometry.coordinates[0]; // 外环
        for (const [lng, lat] of coords) {
            minX = Math.min(minX, lng);
            maxX = Math.max(maxX, lng);
            minZ = Math.min(minZ, lat);
            maxZ = Math.max(maxZ, lat);
        }

        if (minX === Infinity || maxX === -Infinity || minZ === Infinity || maxZ === -Infinity) {
            return null;
        }

        return { minX, maxX, minZ, maxZ };
    }

    /**
     * 创建方形多边形
     * @param {Object} bounds - 边界框 {minX, maxX, minZ, maxZ}
     * @returns {Object|null} Turf.js 多边形对象
     */
    createRectangularPolygon(bounds) {
        if (!bounds) {
            return null;
        }

        try {
            // 创建方形坐标数组（顺时针方向）
            const coordinates = [
                [bounds.minX, bounds.minZ], // 左下角
                [bounds.maxX, bounds.minZ], // 右下角
                [bounds.maxX, bounds.maxZ], // 右上角
                [bounds.minX, bounds.maxZ], // 左上角
                [bounds.minX, bounds.minZ]  // 闭合多边形
            ];

            // 创建 Turf.js 多边形
            const polygon = turf.polygon([coordinates]);

            // 验证多边形
            if (this.isValidPolygon(polygon)) {
                return polygon;
            } else {
                console.warn('⚠️ 创建的方形多边形无效');
                return null;
            }
        } catch (error) {
            console.error('❌ 创建方形多边形失败:', error);
            return null;
        }
    }

    /**
     * 将边界框对齐到区块网格（如果GeometryUtils可用）
     * @param {Object} bounds - 边界框
     * @returns {Object} 对齐后的边界框
     */
    alignBoundsToChunk(bounds) {
        // 检查GeometryUtils是否可用
        if (typeof window.GeometryUtils !== 'undefined' && window.GeometryUtils.alignBoundsToChunk) {
            return window.GeometryUtils.alignBoundsToChunk(bounds);
        }

        // 如果GeometryUtils不可用，返回原始边界框
        return bounds;
    }

    /**
     * 步骤2: 为每个国家的每个领地区域分别创建方形缓冲区
     *
     * 修复说明：
     * - 不是为整个国家创建一个大的方形缓冲区
     * - 而是为每个领地区域分别创建方形缓冲区
     * - 每个领地区域向外扩张80方块形成独立的方形缓冲区
     * - 步骤3再将同一国家的多个缓冲区合并
     *
     * @returns {Object} 执行结果
     */
    async step2_bufferTerritories() {
        console.log('🚀 执行步骤2: 为每个国家的每个领地区域分别创建方形缓冲区');

        try {
            this.updateStatus('info', '步骤2: 正在为每个领地区域创建方形缓冲区...');

            // 检查步骤1是否已完成
            if (this.stepData.currentStep < 1 || this.stepData.step1_originalTerritories.size === 0) {
                this.updateStatus('error', '请先完成步骤1: 获取原始领地数据');
                return { success: false, error: '步骤1未完成' };
            }

            this.stepData.step2_bufferedTerritories.clear();
            let successCount = 0;
            let failureCount = 0;

            for (const [countryName, territoryPolygons] of this.stepData.step1_originalTerritories) {
                try {
                    console.log(`🔧 处理国家 "${countryName}" 的 ${territoryPolygons.length} 个领地多边形`);

                    // 为每个领地区域分别创建方形缓冲区
                    const bufferedPolygons = [];
                    // 从配置中获取缓冲距离，如果没有配置则使用默认值
                    const bufferDistanceEl = document.getElementById('buffer-distance');
                    const bufferDistanceChunks = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
                    const bufferDistance = bufferDistanceChunks * 16; // 转换为方块单位

                    for (let i = 0; i < territoryPolygons.length; i++) {
                        try {
                            const poly = territoryPolygons[i];

                            // 验证和清理多边形
                            if (this.isValidPolygon(poly)) {
                                const cleanedPoly = this.cleanPolygon(poly);
                                if (cleanedPoly) {
                                    // 计算该领地区域的边界框
                                    const territoryBounds = this.calculatePolygonBounds(cleanedPoly);
                                    if (territoryBounds) {
                                        // 向外扩张80方块
                                        const expandedBounds = {
                                            minX: territoryBounds.minX - bufferDistance,
                                            maxX: territoryBounds.maxX + bufferDistance,
                                            minZ: territoryBounds.minZ - bufferDistance,
                                            maxZ: territoryBounds.maxZ + bufferDistance
                                        };

                                        // 对齐到区块边界（可选）
                                        const alignedBounds = this.alignBoundsToChunk(expandedBounds);

                                        // 创建方形多边形
                                        const rectangularPolygon = this.createRectangularPolygon(alignedBounds);
                                        if (rectangularPolygon) {
                                            bufferedPolygons.push(rectangularPolygon);
                                            console.log(`   ✅ 领地 ${i+1}: 边界 (${alignedBounds.minX}, ${alignedBounds.minZ}) 到 (${alignedBounds.maxX}, ${alignedBounds.maxZ})`);
                                        }
                                    }
                                }
                            }
                        } catch (error) {
                            console.warn(`⚠️ 国家 "${countryName}" 领地 ${i} 缓冲失败:`, error.message);
                        }
                    }

                    if (bufferedPolygons.length > 0) {
                        this.stepData.step2_bufferedTerritories.set(countryName, bufferedPolygons);
                        successCount++;
                        console.log(`✅ 国家 "${countryName}" 完成: ${bufferedPolygons.length} 个方形缓冲区`);
                    } else {
                        failureCount++;
                        console.warn(`⚠️ 国家 "${countryName}" 没有成功创建任何缓冲区`);
                    }

                } catch (error) {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 缓冲处理失败:`, error);
                }
            }

            this.stepData.currentStep = 2;
            this.stepData.stepStatus.set(2, {
                success: successCount > 0,
                successCount,
                failureCount,
                timestamp: new Date().toISOString()
            });

            const message = `步骤2完成: ${successCount} 个国家的领地区域缓冲成功${failureCount > 0 ? `，${failureCount} 个失败` : ''}`;
            this.updateStatus(successCount > 0 ? 'success' : 'error', message);
            console.log(`✅ ${message}`);

            // 渲染步骤2的结果
            if (successCount > 0) {
                await this.renderStep2Results();
            }

            return {
                success: successCount > 0,
                successCount,
                failureCount,
                data: this.stepData.step2_bufferedTerritories
            };

        } catch (error) {
            console.error('❌ 步骤2执行失败:', error);
            this.updateStatus('error', `步骤2失败: ${error.message}`);
            this.stepData.stepStatus.set(2, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 步骤3: 每一个国家将他的所有缓冲领地合并
     * @returns {Object} 执行结果
     */
    async step3_mergeCountryTerritories() {
        console.log('🚀 执行步骤3: 每一个国家将他的所有缓冲领地合并');

        try {
            this.updateStatus('info', '步骤3: 正在合并每个国家的缓冲领地...');

            // 检查步骤2是否已完成
            if (this.stepData.currentStep < 2 || this.stepData.step2_bufferedTerritories.size === 0) {
                this.updateStatus('error', '请先完成步骤2: 缓冲处理');
                return { success: false, error: '步骤2未完成' };
            }

            this.stepData.step3_mergedTerritories.clear();
            let successCount = 0;
            let failureCount = 0;

            for (const [countryName, bufferedPolygons] of this.stepData.step2_bufferedTerritories) {
                try {
                    console.log(`🔧 合并国家 "${countryName}" 的 ${bufferedPolygons.length} 个缓冲多边形`);

                    if (bufferedPolygons.length === 0) {
                        failureCount++;
                        continue;
                    }

                    if (bufferedPolygons.length === 1) {
                        // 只有一个多边形，直接使用
                        this.stepData.step3_mergedTerritories.set(countryName, {
                            merged: bufferedPolygons[0],
                            failedMerges: []
                        });
                        successCount++;
                        console.log(`✅ 国家 "${countryName}" 只有一个多边形，无需合并`);
                        continue;
                    }

                    // 安全地合并所有缓冲后的多边形
                    let merged = bufferedPolygons[0];
                    const failedMerges = [];

                    for (let i = 1; i < bufferedPolygons.length; i++) {
                        try {
                            const unionResult = turf.union(merged, bufferedPolygons[i]);
                            if (unionResult && unionResult.geometry) {
                                merged = unionResult;
                            } else {
                                console.warn(`⚠️ 国家 "${countryName}" 合并多边形 ${i} 返回空结果`);
                                failedMerges.push(bufferedPolygons[i]);
                            }
                        } catch (error) {
                            console.warn(`⚠️ 国家 "${countryName}" 合并多边形 ${i} 失败:`, error.message);
                            failedMerges.push(bufferedPolygons[i]);
                        }
                    }

                    this.stepData.step3_mergedTerritories.set(countryName, {
                        merged: merged,
                        failedMerges: failedMerges
                    });

                    successCount++;
                    console.log(`✅ 国家 "${countryName}" 合并完成${failedMerges.length > 0 ? `，${failedMerges.length} 个多边形无法合并` : ''}`);

                } catch (error) {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 合并处理失败:`, error);
                }
            }

            this.stepData.currentStep = 3;
            this.stepData.stepStatus.set(3, {
                success: successCount > 0,
                successCount,
                failureCount,
                timestamp: new Date().toISOString()
            });

            const message = `步骤3完成: ${successCount} 个国家合并成功${failureCount > 0 ? `，${failureCount} 个失败` : ''}`;
            this.updateStatus(successCount > 0 ? 'success' : 'error', message);
            console.log(`✅ ${message}`);

            // 渲染步骤3的结果
            if (successCount > 0) {
                await this.renderStep3Results();
            }

            return {
                success: successCount > 0,
                successCount,
                failureCount,
                data: this.stepData.step3_mergedTerritories
            };

        } catch (error) {
            console.error('❌ 步骤3执行失败:', error);
            this.updateStatus('error', `步骤3失败: ${error.message}`);
            this.stepData.stepStatus.set(3, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 步骤4: 合并结果可能有多个区域
     * @returns {Object} 执行结果
     */
    async step4_handleMultipleRegions() {
        console.log('🚀 执行步骤4: 处理合并结果的多个区域');

        try {
            this.updateStatus('info', '步骤4: 正在处理合并结果的多个区域...');

            // 检查步骤3是否已完成
            if (this.stepData.currentStep < 3 || this.stepData.step3_mergedTerritories.size === 0) {
                this.updateStatus('error', '请先完成步骤3: 合并领地');
                return { success: false, error: '步骤3未完成' };
            }

            this.stepData.step4_processedRegions.clear();
            let successCount = 0;
            let failureCount = 0;
            let totalRegions = 0;

            for (const [countryName, mergeResult] of this.stepData.step3_mergedTerritories) {
                try {
                    console.log(`🔧 处理国家 "${countryName}" 的合并结果`);

                    const regions = [];
                    let regionIndex = 0;

                    // 处理成功合并的多边形
                    if (mergeResult.merged && mergeResult.merged.geometry) {
                        if (mergeResult.merged.geometry.type === 'Polygon') {
                            regions.push({
                                type: 'merged',
                                index: regionIndex++,
                                geometry: mergeResult.merged
                            });
                        } else if (mergeResult.merged.geometry.type === 'MultiPolygon') {
                            mergeResult.merged.geometry.coordinates.forEach((coords) => {
                                try {
                                    const subPoly = turf.polygon(coords);
                                    regions.push({
                                        type: 'merged-part',
                                        index: regionIndex++,
                                        geometry: subPoly
                                    });
                                } catch (error) {
                                    console.warn(`⚠️ 国家 "${countryName}" 创建子多边形 ${regionIndex} 失败:`, error.message);
                                }
                            });
                        }
                    }

                    // 处理无法合并的独立多边形
                    if (mergeResult.failedMerges && mergeResult.failedMerges.length > 0) {
                        mergeResult.failedMerges.forEach((polygon) => {
                            try {
                                regions.push({
                                    type: 'independent',
                                    index: regionIndex++,
                                    geometry: polygon
                                });
                            } catch (error) {
                                console.warn(`⚠️ 国家 "${countryName}" 处理独立多边形 ${regionIndex} 失败:`, error.message);
                            }
                        });
                    }

                    if (regions.length > 0) {
                        this.stepData.step4_processedRegions.set(countryName, regions);
                        successCount++;
                        totalRegions += regions.length;
                        console.log(`✅ 国家 "${countryName}" 处理完成: ${regions.length} 个区域`);
                    } else {
                        failureCount++;
                        console.warn(`⚠️ 国家 "${countryName}" 没有有效的区域`);
                    }

                } catch (error) {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 区域处理失败:`, error);
                }
            }

            this.stepData.currentStep = 4;
            this.stepData.stepStatus.set(4, {
                success: successCount > 0,
                successCount,
                failureCount,
                totalRegions,
                timestamp: new Date().toISOString()
            });

            const message = `步骤4完成: ${successCount} 个国家处理成功，共 ${totalRegions} 个区域${failureCount > 0 ? `，${failureCount} 个失败` : ''}`;
            this.updateStatus(successCount > 0 ? 'success' : 'error', message);
            console.log(`✅ ${message}`);

            // 渲染步骤4的结果
            if (successCount > 0) {
                await this.renderStep4Results();
            }

            return {
                success: successCount > 0,
                successCount,
                failureCount,
                totalRegions,
                data: this.stepData.step4_processedRegions
            };

        } catch (error) {
            console.error('❌ 步骤4执行失败:', error);
            this.updateStatus('error', `步骤4失败: ${error.message}`);
            this.stepData.stepStatus.set(4, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 步骤5: 计算面积、生成ID、转换为Leaflet格式
     * @returns {Object} 执行结果
     */
    async step5_calculateAndFormat() {
        console.log('🚀 执行步骤5: 计算面积、生成ID、转换为Leaflet格式');

        try {
            this.updateStatus('info', '步骤5: 正在计算面积、生成ID、转换格式...');

            // 检查步骤4是否已完成
            if (this.stepData.currentStep < 4 || this.stepData.step4_processedRegions.size === 0) {
                this.updateStatus('error', '请先完成步骤4: 处理多区域');
                return { success: false, error: '步骤4未完成' };
            }

            this.stepData.step5_formattedClaims.clear();
            let successCount = 0;
            let failureCount = 0;
            let totalClaims = 0;

            for (const [countryName, regions] of this.stepData.step4_processedRegions) {
                try {
                    console.log(`🔧 格式化国家 "${countryName}" 的 ${regions.length} 个区域`);

                    const claims = [];

                    for (const region of regions) {
                        try {
                            const claim = this.createClaimObject(countryName, region.geometry, region.index);
                            if (claim) {
                                claims.push(claim);
                            }
                        } catch (error) {
                            console.warn(`⚠️ 国家 "${countryName}" 区域 ${region.index} 格式化失败:`, error.message);
                        }
                    }

                    if (claims.length > 0) {
                        this.stepData.step5_formattedClaims.set(countryName, claims);
                        successCount++;
                        totalClaims += claims.length;
                        console.log(`✅ 国家 "${countryName}" 格式化完成: ${claims.length} 个宣称区域`);
                    } else {
                        failureCount++;
                        console.warn(`⚠️ 国家 "${countryName}" 没有有效的宣称区域`);
                    }

                } catch (error) {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 格式化处理失败:`, error);
                }
            }

            this.stepData.currentStep = 5;
            this.stepData.stepStatus.set(5, {
                success: successCount > 0,
                successCount,
                failureCount,
                totalClaims,
                timestamp: new Date().toISOString()
            });

            const message = `步骤5完成: ${successCount} 个国家格式化成功，共 ${totalClaims} 个宣称区域${failureCount > 0 ? `，${failureCount} 个失败` : ''}`;
            this.updateStatus(successCount > 0 ? 'success' : 'error', message);
            console.log(`✅ ${message}`);

            // 渲染步骤5的结果
            if (successCount > 0) {
                await this.renderStep5Results();
            }

            return {
                success: successCount > 0,
                successCount,
                failureCount,
                totalClaims,
                data: this.stepData.step5_formattedClaims
            };

        } catch (error) {
            console.error('❌ 步骤5执行失败:', error);
            this.updateStatus('error', `步骤5失败: ${error.message}`);
            this.stepData.stepStatus.set(5, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 步骤6: 存入countryClaimsManager.generatedClaims
     * @returns {Object} 执行结果
     */
    async step6_storeResults() {
        console.log('🚀 执行步骤6: 存入generatedClaims');

        try {
            this.updateStatus('info', '步骤6: 正在存储结果到generatedClaims...');

            // 检查步骤5是否已完成
            if (this.stepData.currentStep < 5 || this.stepData.step5_formattedClaims.size === 0) {
                this.updateStatus('error', '请先完成步骤5: 计算和格式化');
                return { success: false, error: '步骤5未完成' };
            }

            // 清除之前的生成数据
            this.generatedClaims.clear();

            let successCount = 0;
            let failureCount = 0;
            let totalClaims = 0;

            for (const [countryName, claims] of this.stepData.step5_formattedClaims) {
                try {
                    this.generatedClaims.set(countryName, {
                        success: true,
                        claims: claims
                    });

                    successCount++;
                    totalClaims += claims.length;
                    console.log(`✅ 国家 "${countryName}" 存储完成: ${claims.length} 个宣称区域`);

                } catch (error) {
                    failureCount++;
                    console.error(`❌ 国家 "${countryName}" 存储失败:`, error);
                }
            }

            // 保存到本地存储
            if (successCount > 0) {
                try {
                    console.log('🔄 步骤6: 开始保存到 IndexedDB...');
                    const saveResult = await this.saveClaimsToLocalStorage();
                    console.log('🔄 步骤6: 保存结果:', saveResult);

                    if (!saveResult.success) {
                        console.warn('⚠️ 保存到本地存储失败:', saveResult.error);
                    } else {
                        console.log('✅ 步骤6: 成功保存到 IndexedDB');
                    }
                } catch (error) {
                    console.warn('⚠️ 保存到本地存储失败:', error.message);
                    console.error('⚠️ 保存错误详情:', error);
                }
            }

            this.stepData.currentStep = 6;
            this.stepData.stepStatus.set(6, {
                success: successCount > 0,
                successCount,
                failureCount,
                totalClaims,
                timestamp: new Date().toISOString()
            });

            const message = `步骤6完成: ${successCount} 个国家存储成功，共 ${totalClaims} 个宣称区域${failureCount > 0 ? `，${failureCount} 个失败` : ''}`;
            this.updateStatus(successCount > 0 ? 'success' : 'error', message);
            console.log(`✅ ${message}`);

            // 渲染步骤6的结果（最终结果）
            if (successCount > 0) {
                await this.renderStep6Results();
            }

            return {
                success: successCount > 0,
                successCount,
                failureCount,
                totalClaims,
                data: this.generatedClaims
            };

        } catch (error) {
            console.error('❌ 步骤6执行失败:', error);
            this.updateStatus('error', `步骤6失败: ${error.message}`);
            this.stepData.stepStatus.set(6, { success: false, error: error.message, timestamp: new Date().toISOString() });
            return { success: false, error: error.message };
        }
    }

    /**
     * 执行所有步骤
     * @returns {Object} 执行结果
     */
    async executeAllSteps() {
        console.log('🚀 开始执行所有步骤');

        try {
            this.updateStatus('info', '开始执行所有步骤...');

            const results = {};

            // 步骤1
            const step1Result = await this.step1_loadOriginalTerritories();
            results.step1 = step1Result;
            if (!step1Result.success) {
                return { success: false, results, failedAt: 1 };
            }

            // 步骤2
            const step2Result = await this.step2_bufferTerritories();
            results.step2 = step2Result;
            if (!step2Result.success) {
                return { success: false, results, failedAt: 2 };
            }

            // 步骤3
            const step3Result = await this.step3_mergeCountryTerritories();
            results.step3 = step3Result;
            if (!step3Result.success) {
                return { success: false, results, failedAt: 3 };
            }

            // 步骤4
            const step4Result = await this.step4_handleMultipleRegions();
            results.step4 = step4Result;
            if (!step4Result.success) {
                return { success: false, results, failedAt: 4 };
            }

            // 步骤5
            const step5Result = await this.step5_calculateAndFormat();
            results.step5 = step5Result;
            if (!step5Result.success) {
                return { success: false, results, failedAt: 5 };
            }

            // 步骤6
            const step6Result = await this.step6_storeResults();
            results.step6 = step6Result;
            if (!step6Result.success) {
                return { success: false, results, failedAt: 6 };
            }

            this.updateStatus('success', `所有步骤执行完成！共生成 ${step6Result.totalClaims} 个宣称区域`);
            console.log('✅ 所有步骤执行完成');

            return {
                success: true,
                results,
                totalClaims: step6Result.totalClaims
            };

        } catch (error) {
            console.error('❌ 执行所有步骤失败:', error);
            this.updateStatus('error', `执行失败: ${error.message}`);
            return { success: false, error: error.message };
        }
    }

    /**
     * 重置步骤数据
     */
    resetStepData() {
        console.log('🔄 重置步骤数据');

        // 清除所有步骤的渲染图层
        this.clearAllStepRenderLayers();

        // 清除步骤数据
        this.stepData.step1_originalTerritories.clear();
        this.stepData.step2_bufferedTerritories.clear();
        this.stepData.step3_mergedTerritories.clear();
        this.stepData.step4_processedRegions.clear();
        this.stepData.step5_formattedClaims.clear();
        this.stepData.currentStep = 0;
        this.stepData.stepStatus.clear();

        this.updateStatus('info', '步骤数据和渲染图层已重置');
        console.log('✅ 步骤数据重置完成');
    }

    /**
     * 获取步骤状态信息
     * @returns {Object} 步骤状态
     */
    getStepStatus() {
        return {
            currentStep: this.stepData.currentStep,
            stepStatus: Object.fromEntries(this.stepData.stepStatus),
            dataStatus: {
                step1: this.stepData.step1_originalTerritories.size,
                step2: this.stepData.step2_bufferedTerritories.size,
                step3: this.stepData.step3_mergedTerritories.size,
                step4: this.stepData.step4_processedRegions.size,
                step5: this.stepData.step5_formattedClaims.size,
                generatedClaims: this.generatedClaims.size
            }
        };
    }

    // ==================== 分步骤渲染方法 ====================

    /**
     * 清除指定步骤的渲染图层
     * @param {number} stepNumber - 步骤编号
     */
    clearStepRenderLayers(stepNumber) {
        const stepKey = `step${stepNumber}`;
        const layers = this.stepRenderLayers.get(stepKey);

        if (layers && layers.length > 0) {
            layers.forEach(layer => {
                if (this.map.hasLayer(layer)) {
                    this.map.removeLayer(layer);
                }
            });
            this.stepRenderLayers.delete(stepKey);
            console.log(`🗑️ 已清除步骤${stepNumber}的 ${layers.length} 个渲染图层`);
        }
    }

    /**
     * 清除所有步骤的渲染图层
     */
    clearAllStepRenderLayers() {
        for (let step = 1; step <= 6; step++) {
            this.clearStepRenderLayers(step);
        }
        console.log('🗑️ 已清除所有步骤的渲染图层');
    }

    /**
     * 渲染步骤1结果: 原始领地数据
     */
    async renderStep1Results() {
        console.log('🎨 渲染步骤1结果: 原始领地数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(1);

            const layers = [];
            let totalPolygons = 0;

            for (const [countryName, territoryPolygons] of this.stepData.step1_originalTerritories) {
                territoryPolygons.forEach((polygon, index) => {
                    try {
                        // 验证多边形结构
                        if (!polygon || !polygon.geometry || !polygon.geometry.coordinates ||
                            !Array.isArray(polygon.geometry.coordinates[0])) {
                            console.warn(`⚠️ 国家 "${countryName}" 原始多边形 ${index} 结构无效`);
                            return;
                        }

                        // 安全转换坐标
                        const mapCoords = [];
                        let validCoordCount = 0;

                        for (const coord of polygon.geometry.coordinates[0]) {
                            const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                            if (mapCoord) {
                                mapCoords.push(mapCoord);
                                validCoordCount++;
                            }
                        }

                        // 检查是否有足够的有效坐标
                        if (validCoordCount < 3) {
                            console.warn(`⚠️ 国家 "${countryName}" 原始多边形 ${index} 有效坐标不足: ${validCoordCount}/3`);
                            return;
                        }

                        // 创建多边形图层
                        const layer = L.polygon(mapCoords, {
                            color: '#3388ff',
                            fillColor: '#3388ff',
                            fillOpacity: 0.1,
                            weight: 2,
                            opacity: 0.6,
                            dashArray: '5, 5' // 虚线样式表示原始数据
                        }).addTo(this.map);

                        // 添加弹窗
                        layer.bindPopup(`
                            <div style="font-size: 12px;">
                                <strong>步骤1: 原始领地</strong><br>
                                国家: ${countryName}<br>
                                多边形: ${index + 1}/${territoryPolygons.length}<br>
                                有效顶点: ${validCoordCount}/${polygon.geometry.coordinates[0].length}
                            </div>
                        `);

                        layers.push(layer);
                        totalPolygons++;
                    } catch (error) {
                        console.warn(`⚠️ 渲染国家 "${countryName}" 多边形 ${index} 失败:`, error.message);
                    }
                });
            }

            // 存储图层
            this.stepRenderLayers.set('step1', layers);

            console.log(`✅ 步骤1渲染完成: ${totalPolygons} 个原始领地多边形`);
            this.updateStatus('info', `步骤1渲染: 显示了 ${totalPolygons} 个原始领地多边形`);

        } catch (error) {
            console.error('❌ 步骤1渲染失败:', error);
            this.updateStatus('error', `步骤1渲染失败: ${error.message}`);
        }
    }

    /**
     * 验证坐标是否有效
     * @param {number} x - X坐标
     * @param {number} z - Z坐标
     * @returns {boolean} 是否有效
     */
    isValidCoordinate(x, z) {
        return typeof x === 'number' && typeof z === 'number' &&
               isFinite(x) && isFinite(z) &&
               !isNaN(x) && !isNaN(z);
    }

    /**
     * 安全的坐标转换
     * @param {number} mcX - MC X坐标
     * @param {number} mcZ - MC Z坐标
     * @returns {Array|null} 地图坐标或null
     */
    safeCoordinateConversion(mcX, mcZ) {
        try {
            if (!this.isValidCoordinate(mcX, mcZ)) {
                console.warn(`⚠️ 无效坐标: [${mcX}, ${mcZ}]`);
                return null;
            }

            const mapCoords = this.coordinateConverter.mcToMapCoords(mcX, mcZ);

            // 验证转换结果
            if (!Array.isArray(mapCoords) || mapCoords.length !== 2 ||
                !this.isValidCoordinate(mapCoords[0], mapCoords[1])) {
                console.warn(`⚠️ 坐标转换结果无效: [${mcX}, ${mcZ}] -> [${mapCoords}]`);
                return null;
            }

            return mapCoords;
        } catch (error) {
            console.warn(`⚠️ 坐标转换失败: [${mcX}, ${mcZ}]:`, error.message);
            return null;
        }
    }

    /**
     * 渲染步骤2结果: 缓冲后的领地数据
     */
    async renderStep2Results() {
        console.log('🎨 渲染步骤2结果: 缓冲后的领地数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(2);

            const layers = [];
            let totalPolygons = 0;

            for (const [countryName, bufferedPolygons] of this.stepData.step2_bufferedTerritories) {
                bufferedPolygons.forEach((turfPolygon, index) => {
                    try {
                        // 验证 Turf 多边形结构
                        if (!turfPolygon || !turfPolygon.geometry || !turfPolygon.geometry.coordinates ||
                            !Array.isArray(turfPolygon.geometry.coordinates[0])) {
                            console.warn(`⚠️ 国家 "${countryName}" 缓冲多边形 ${index} 结构无效`);
                            return;
                        }

                        // 安全转换坐标
                        const mapCoords = [];
                        let validCoordCount = 0;

                        for (const coord of turfPolygon.geometry.coordinates[0]) {
                            const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                            if (mapCoord) {
                                mapCoords.push(mapCoord);
                                validCoordCount++;
                            }
                        }

                        // 检查是否有足够的有效坐标
                        if (validCoordCount < 3) {
                            console.warn(`⚠️ 国家 "${countryName}" 缓冲多边形 ${index} 有效坐标不足: ${validCoordCount}/3`);
                            return;
                        }

                        // 创建多边形图层
                        const layer = L.polygon(mapCoords, {
                            color: '#ff9800',
                            fillColor: '#ff9800',
                            fillOpacity: 0.15,
                            weight: 2,
                            opacity: 0.7
                        }).addTo(this.map);

                        // 添加弹窗
                        layer.bindPopup(`
                            <div style="font-size: 12px;">
                                <strong>步骤2: 领地方形缓冲区</strong><br>
                                国家: ${countryName}<br>
                                领地编号: ${index + 1}/${bufferedPolygons.length}<br>
                                扩张距离: 80方块 (5区块)<br>
                                有效顶点: ${validCoordCount}/${turfPolygon.geometry.coordinates[0].length}
                            </div>
                        `);

                        layers.push(layer);
                        totalPolygons++;
                    } catch (error) {
                        console.warn(`⚠️ 渲染国家 "${countryName}" 缓冲多边形 ${index} 失败:`, error.message);
                    }
                });
            }

            // 存储图层
            this.stepRenderLayers.set('step2', layers);

            console.log(`✅ 步骤2渲染完成: ${totalPolygons} 个领地方形缓冲区`);
            this.updateStatus('info', `步骤2渲染: 显示了 ${totalPolygons} 个领地方形缓冲区`);

        } catch (error) {
            console.error('❌ 步骤2渲染失败:', error);
            this.updateStatus('error', `步骤2渲染失败: ${error.message}`);
        }
    }

    /**
     * 渲染步骤3结果: 合并后的领地数据
     */
    async renderStep3Results() {
        console.log('🎨 渲染步骤3结果: 合并后的领地数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(3);

            const layers = [];
            let totalRegions = 0;

            for (const [countryName, mergeResult] of this.stepData.step3_mergedTerritories) {
                try {
                    // 渲染成功合并的多边形
                    if (mergeResult.merged && mergeResult.merged.geometry) {
                        const merged = mergeResult.merged;

                        if (merged.geometry.type === 'Polygon') {
                            // 安全转换坐标
                            const mapCoords = [];
                            let validCoordCount = 0;

                            for (const coord of merged.geometry.coordinates[0]) {
                                const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                                if (mapCoord) {
                                    mapCoords.push(mapCoord);
                                    validCoordCount++;
                                }
                            }

                            if (validCoordCount >= 3) {
                                const layer = L.polygon(mapCoords, {
                                    color: '#4caf50',
                                    fillColor: '#4caf50',
                                    fillOpacity: 0.2,
                                    weight: 3,
                                    opacity: 0.8
                                }).addTo(this.map);

                                layer.bindPopup(`
                                    <div style="font-size: 12px;">
                                        <strong>步骤3: 合并后领地</strong><br>
                                        国家: ${countryName}<br>
                                        类型: 单一合并区域<br>
                                        有效顶点: ${validCoordCount}/${merged.geometry.coordinates[0].length}<br>
                                        失败合并: ${mergeResult.failedMerges.length} 个
                                    </div>
                                `);

                                layers.push(layer);
                                totalRegions++;
                            }
                        } else if (merged.geometry.type === 'MultiPolygon') {
                            merged.geometry.coordinates.forEach((coords, index) => {
                                // 安全转换坐标
                                const mapCoords = [];
                                let validCoordCount = 0;

                                for (const coord of coords[0]) {
                                    const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                                    if (mapCoord) {
                                        mapCoords.push(mapCoord);
                                        validCoordCount++;
                                    }
                                }

                                if (validCoordCount >= 3) {
                                    const layer = L.polygon(mapCoords, {
                                        color: '#4caf50',
                                        fillColor: '#4caf50',
                                        fillOpacity: 0.2,
                                        weight: 3,
                                        opacity: 0.8
                                    }).addTo(this.map);

                                    layer.bindPopup(`
                                        <div style="font-size: 12px;">
                                            <strong>步骤3: 合并后领地</strong><br>
                                            国家: ${countryName}<br>
                                            类型: 多重合并区域 ${index + 1}<br>
                                            有效顶点: ${validCoordCount}/${coords[0].length}<br>
                                            失败合并: ${mergeResult.failedMerges.length} 个
                                        </div>
                                    `);

                                    layers.push(layer);
                                    totalRegions++;
                                }
                            });
                        }
                    }

                    // 渲染无法合并的独立多边形
                    if (mergeResult.failedMerges && mergeResult.failedMerges.length > 0) {
                        mergeResult.failedMerges.forEach((polygon, index) => {
                            try {
                                // 安全转换坐标
                                const mapCoords = [];
                                let validCoordCount = 0;

                                for (const coord of polygon.geometry.coordinates[0]) {
                                    const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                                    if (mapCoord) {
                                        mapCoords.push(mapCoord);
                                        validCoordCount++;
                                    }
                                }

                                if (validCoordCount >= 3) {
                                    const layer = L.polygon(mapCoords, {
                                        color: '#f44336',
                                        fillColor: '#f44336',
                                        fillOpacity: 0.15,
                                        weight: 2,
                                        opacity: 0.7,
                                        dashArray: '3, 3'
                                    }).addTo(this.map);

                                    layer.bindPopup(`
                                        <div style="font-size: 12px;">
                                            <strong>步骤3: 独立领地</strong><br>
                                            国家: ${countryName}<br>
                                            类型: 无法合并的独立区域<br>
                                            序号: ${index + 1}/${mergeResult.failedMerges.length}<br>
                                            有效顶点: ${validCoordCount}/${polygon.geometry.coordinates[0].length}
                                        </div>
                                    `);

                                    layers.push(layer);
                                    totalRegions++;
                                }
                            } catch (error) {
                                console.warn(`⚠️ 渲染国家 "${countryName}" 独立多边形 ${index} 失败:`, error.message);
                            }
                        });
                    }

                } catch (error) {
                    console.warn(`⚠️ 渲染国家 "${countryName}" 合并结果失败:`, error.message);
                }
            }

            // 存储图层
            this.stepRenderLayers.set('step3', layers);

            console.log(`✅ 步骤3渲染完成: ${totalRegions} 个合并后区域`);
            this.updateStatus('info', `步骤3渲染: 显示了 ${totalRegions} 个合并后区域`);

        } catch (error) {
            console.error('❌ 步骤3渲染失败:', error);
            this.updateStatus('error', `步骤3渲染失败: ${error.message}`);
        }
    }

    /**
     * 渲染步骤4结果: 处理后的多区域数据
     */
    async renderStep4Results() {
        console.log('🎨 渲染步骤4结果: 处理后的多区域数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(4);

            const layers = [];
            let totalRegions = 0;

            for (const [countryName, regions] of this.stepData.step4_processedRegions) {
                regions.forEach((region, index) => {
                    try {
                        // 验证区域结构
                        if (!region || !region.geometry || !region.geometry.geometry ||
                            !region.geometry.geometry.coordinates ||
                            !Array.isArray(region.geometry.geometry.coordinates[0])) {
                            console.warn(`⚠️ 国家 "${countryName}" 区域 ${index} 结构无效`);
                            return;
                        }

                        // 安全转换坐标
                        const mapCoords = [];
                        let validCoordCount = 0;

                        for (const coord of region.geometry.geometry.coordinates[0]) {
                            const mapCoord = this.safeCoordinateConversion(coord[0], coord[1]);
                            if (mapCoord) {
                                mapCoords.push(mapCoord);
                                validCoordCount++;
                            }
                        }

                        // 检查是否有足够的有效坐标
                        if (validCoordCount < 3) {
                            console.warn(`⚠️ 国家 "${countryName}" 区域 ${index} 有效坐标不足: ${validCoordCount}/3`);
                            return;
                        }

                        // 根据区域类型选择不同的样式
                        let style = {};
                        let typeLabel = '';

                        switch (region.type) {
                            case 'merged':
                                style = { color: '#9c27b0', fillColor: '#9c27b0', fillOpacity: 0.25, weight: 3, opacity: 0.9 };
                                typeLabel = '主合并区域';
                                break;
                            case 'merged-part':
                                style = { color: '#673ab7', fillColor: '#673ab7', fillOpacity: 0.2, weight: 2, opacity: 0.8 };
                                typeLabel = '合并子区域';
                                break;
                            case 'independent':
                                style = { color: '#ff5722', fillColor: '#ff5722', fillOpacity: 0.15, weight: 2, opacity: 0.7, dashArray: '2, 2' };
                                typeLabel = '独立区域';
                                break;
                        }

                        const layer = L.polygon(mapCoords, style).addTo(this.map);

                        layer.bindPopup(`
                            <div style="font-size: 12px;">
                                <strong>步骤4: 处理后区域</strong><br>
                                国家: ${countryName}<br>
                                类型: ${typeLabel}<br>
                                区域: ${index + 1}/${regions.length}<br>
                                有效顶点: ${validCoordCount}/${region.geometry.geometry.coordinates[0].length}
                            </div>
                        `);

                        layers.push(layer);
                        totalRegions++;
                    } catch (error) {
                        console.warn(`⚠️ 渲染国家 "${countryName}" 区域 ${index} 失败:`, error.message);
                    }
                });
            }

            // 存储图层
            this.stepRenderLayers.set('step4', layers);

            console.log(`✅ 步骤4渲染完成: ${totalRegions} 个处理后区域`);
            this.updateStatus('info', `步骤4渲染: 显示了 ${totalRegions} 个处理后区域`);

        } catch (error) {
            console.error('❌ 步骤4渲染失败:', error);
            this.updateStatus('error', `步骤4渲染失败: ${error.message}`);
        }
    }

    /**
     * 渲染步骤5结果: 格式化后的宣称数据
     */
    async renderStep5Results() {
        console.log('🎨 渲染步骤5结果: 格式化后的宣称数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(5);

            const layers = [];
            let totalClaims = 0;

            for (const [countryName, claims] of this.stepData.step5_formattedClaims) {
                claims.forEach((claim, index) => {
                    try {
                        // 安全处理边界坐标
                        let mapBoundary = null;
                        let validCoordCount = 0;

                        if (claim.boundary && claim.boundary.length > 0) {
                            if (Array.isArray(claim.boundary[0]) && Array.isArray(claim.boundary[0][0])) {
                                // 多环结构，已经是地图坐标，验证有效性
                                mapBoundary = [];
                                for (const ring of claim.boundary) {
                                    const validRing = [];
                                    for (const coord of ring) {
                                        if (this.isValidCoordinate(coord[0], coord[1])) {
                                            validRing.push(coord);
                                            validCoordCount++;
                                        }
                                    }
                                    if (validRing.length >= 3) {
                                        mapBoundary.push(validRing);
                                    }
                                }
                                if (mapBoundary.length === 0) {
                                    mapBoundary = null;
                                }
                            } else {
                                // 单环结构，需要转换坐标
                                const convertedCoords = [];
                                for (const point of claim.boundary) {
                                    const mapCoord = this.safeCoordinateConversion(point[0], point[1]);
                                    if (mapCoord) {
                                        convertedCoords.push(mapCoord);
                                        validCoordCount++;
                                    }
                                }
                                if (convertedCoords.length >= 3) {
                                    mapBoundary = convertedCoords;
                                }
                            }
                        }

                        if (!mapBoundary || validCoordCount < 3) {
                            console.warn(`⚠️ 国家 "${countryName}" 宣称区域 ${index} 没有足够的有效边界数据: ${validCoordCount}/3`);
                            return;
                        }

                        const layer = L.polygon(mapBoundary, {
                            color: '#00bcd4',
                            fillColor: '#00bcd4',
                            fillOpacity: 0.3,
                            weight: 3,
                            opacity: 0.9
                        }).addTo(this.map);

                        // 计算面积（平方米转换为平方公里）
                        const areaKm2 = (claim.area / 1000000).toFixed(2);

                        layer.bindPopup(`
                            <div style="font-size: 12px;">
                                <strong>步骤5: 格式化宣称</strong><br>
                                国家: ${countryName}<br>
                                ID: ${claim.id}<br>
                                区域: ${index + 1}/${claims.length}<br>
                                面积: ${areaKm2} km²<br>
                                有效顶点: ${validCoordCount}
                            </div>
                        `);

                        layers.push(layer);
                        totalClaims++;
                    } catch (error) {
                        console.warn(`⚠️ 渲染国家 "${countryName}" 宣称区域 ${index} 失败:`, error.message);
                    }
                });
            }

            // 存储图层
            this.stepRenderLayers.set('step5', layers);

            console.log(`✅ 步骤5渲染完成: ${totalClaims} 个格式化宣称区域`);
            this.updateStatus('info', `步骤5渲染: 显示了 ${totalClaims} 个格式化宣称区域`);

        } catch (error) {
            console.error('❌ 步骤5渲染失败:', error);
            this.updateStatus('error', `步骤5渲染失败: ${error.message}`);
        }
    }

    /**
     * 渲染步骤6结果: 最终存储的宣称数据
     */
    async renderStep6Results() {
        console.log('🎨 渲染步骤6结果: 最终存储的宣称数据');

        try {
            // 清除之前的渲染
            this.clearStepRenderLayers(6);

            const layers = [];
            let totalClaims = 0;

            for (const [countryName, claimsResult] of this.generatedClaims) {
                if (claimsResult && claimsResult.success && claimsResult.claims) {
                    claimsResult.claims.forEach((claim, index) => {
                        try {
                            // 安全处理边界坐标
                            let mapBoundary = null;
                            let validCoordCount = 0;

                            if (claim.boundary && claim.boundary.length > 0) {
                                if (Array.isArray(claim.boundary[0]) && Array.isArray(claim.boundary[0][0])) {
                                    // 多环结构，已经是地图坐标，验证有效性
                                    mapBoundary = [];
                                    for (const ring of claim.boundary) {
                                        const validRing = [];
                                        for (const coord of ring) {
                                            if (this.isValidCoordinate(coord[0], coord[1])) {
                                                validRing.push(coord);
                                                validCoordCount++;
                                            }
                                        }
                                        if (validRing.length >= 3) {
                                            mapBoundary.push(validRing);
                                        }
                                    }
                                    if (mapBoundary.length === 0) {
                                        mapBoundary = null;
                                    }
                                } else {
                                    // 单环结构，需要转换坐标
                                    const convertedCoords = [];
                                    for (const point of claim.boundary) {
                                        const mapCoord = this.safeCoordinateConversion(point[0], point[1]);
                                        if (mapCoord) {
                                            convertedCoords.push(mapCoord);
                                            validCoordCount++;
                                        }
                                    }
                                    if (convertedCoords.length >= 3) {
                                        mapBoundary = convertedCoords;
                                    }
                                }
                            }

                            if (!mapBoundary || validCoordCount < 3) {
                                console.warn(`⚠️ 国家 "${countryName}" 最终宣称区域 ${index} 没有足够的有效边界数据: ${validCoordCount}/3`);
                                return;
                            }

                            const layer = L.polygon(mapBoundary, {
                                color: '#ff6b6b',
                                fillColor: '#ff6b6b',
                                fillOpacity: 0.35,
                                weight: 4,
                                opacity: 1.0
                            }).addTo(this.map);

                            // 计算面积（平方米转换为平方公里）
                            const areaKm2 = (claim.area / 1000000).toFixed(2);

                            layer.bindPopup(`
                                <div style="font-size: 12px;">
                                    <strong>步骤6: 最终宣称区域</strong><br>
                                    国家: ${countryName}<br>
                                    ID: ${claim.id}<br>
                                    区域: ${index + 1}/${claimsResult.claims.length}<br>
                                    面积: ${areaKm2} km²<br>
                                    有效顶点: ${validCoordCount}<br>
                                    生成时间: ${claim.metadata?.generatedAt ? new Date(claim.metadata.generatedAt).toLocaleString() : '未知'}<br>
                                    状态: ✅ 已存储
                                </div>
                            `);

                            layers.push(layer);
                            totalClaims++;
                        } catch (error) {
                            console.warn(`⚠️ 渲染国家 "${countryName}" 最终宣称区域 ${index} 失败:`, error.message);
                        }
                    });
                }
            }

            // 存储图层
            this.stepRenderLayers.set('step6', layers);

            console.log(`✅ 步骤6渲染完成: ${totalClaims} 个最终宣称区域`);
            this.updateStatus('success', `步骤6渲染: 显示了 ${totalClaims} 个最终宣称区域`);

            // 调整视图以显示所有宣称范围
            if (layers.length > 0) {
                const group = new L.featureGroup(layers);
                this.map.fitBounds(group.getBounds().pad(0.1));
            }

        } catch (error) {
            console.error('❌ 步骤6渲染失败:', error);
            this.updateStatus('error', `步骤6渲染失败: ${error.message}`);
        }
    }

    /**
     * 获取配置的缓冲距离
     */
    getConfiguredBufferDistance() {
        const bufferDistanceEl = document.getElementById('buffer-distance');
        const bufferDistanceChunks = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
        return bufferDistanceChunks * 16; // 转换为方块单位
    }

    /**
     * 获取配置的最大断裂距离
     */
    getConfiguredMaxBreakDistance() {
        const maxBreakDistanceEl = document.getElementById('max-break-distance');
        const maxBreakDistanceChunks = maxBreakDistanceEl ? parseInt(maxBreakDistanceEl.value) : 100;
        return maxBreakDistanceChunks * 16; // 转换为方块单位
    }
}
