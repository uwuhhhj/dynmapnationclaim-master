/**
 * 国家宣称范围生成器
 * 实现基于出生点聚类和区域边界合并的宣称范围生成算法
 */

class CountryClaimsGenerator {
    constructor(options = {}) {
        // 配置参数
        this.config = {
            // 聚类参数
            clustering: {
                maxBreakDistance: options.maxBreakDistance || 1000, // 最大断裂距离
                minPoints: options.minPoints || 1, // 最小点数
                algorithm: options.algorithm || 'simple' // 'simple' 或 'dbscan'
            },
            // 几何处理参数
            geometry: {
                bufferDistance: options.bufferDistance || this.getConfiguredBufferDistance(), // 缓冲距离
                enableMerging: options.enableMerging !== false, // 是否启用多边形合并
                useConvexHull: options.useConvexHull !== false // 是否使用凸包
            },
            // 调试选项
            debug: options.debug || false
        };

        console.log('🏗️ 国家宣称范围生成器初始化完成:', this.config);
    }

    /**
     * 获取配置的缓冲距离
     */
    getConfiguredBufferDistance() {
        const bufferDistanceEl = document.getElementById('buffer-distance');
        const bufferDistanceChunks = bufferDistanceEl ? parseInt(bufferDistanceEl.value) : 5;
        return bufferDistanceChunks * 16; // 转换为方块单位
    }

    /**
     * 生成国家的宣称范围
     * @param {string} countryName - 国家名称
     * @param {Object} spawnData - 出生点数据
     * @param {Object} areaData - 区域边界数据
     * @returns {Object} 生成结果
     */
    generateCountryClaims(countryName, spawnData, areaData) {
        console.log(`🗺️ 开始生成国家 "${countryName}" 的宣称范围...`);

        try {
            // 第一步：提取出生点集合
            const spawnPoints = this.extractSpawnPoints(spawnData);
            if (spawnPoints.length === 0) {
                return {
                    success: false,
                    error: '没有有效的出生点数据',
                    countryName,
                    claims: []
                };
            }

            console.log(`📍 提取到 ${spawnPoints.length} 个出生点`);

            // 第二步：进行空间聚类
            const clusters = this.performClustering(spawnPoints);
            console.log(`🔍 聚类完成，生成 ${clusters.length} 个聚类组`);

            // 第三步：为每个聚类生成宣称范围
            const claims = [];
            for (let i = 0; i < clusters.length; i++) {
                const cluster = clusters[i];
                const claimResult = this.generateClusterClaim(
                    countryName,
                    spawnPoints,
                    cluster,
                    areaData,
                    i
                );

                if (claimResult.success) {
                    claims.push(claimResult.claim);
                }
            }

            console.log(`✅ 国家 "${countryName}" 宣称范围生成完成: ${claims.length} 个区域`);

            return {
                success: true,
                countryName,
                claims,
                metadata: {
                    totalSpawnPoints: spawnPoints.length,
                    totalClusters: clusters.length,
                    totalClaims: claims.length,
                    config: this.config
                }
            };

        } catch (error) {
            console.error(`❌ 生成国家 "${countryName}" 宣称范围失败:`, error);
            return {
                success: false,
                error: error.message,
                countryName,
                claims: []
            };
        }
    }

    /**
     * 从出生点数据中提取坐标点
     * @param {Object} spawnData - 出生点数据
     * @returns {Array} 出生点数组
     */
    extractSpawnPoints(spawnData) {
        const points = [];

        for (const [markerId, marker] of Object.entries(spawnData)) {
            if (this.isValidCoordinate(marker)) {
                points.push({
                    x: marker.x,
                    z: marker.z,
                    markerId,
                    markerData: marker
                });
            }
        }

        return points;
    }

    /**
     * 验证坐标是否有效
     * @param {Object} marker - 标记数据
     * @returns {boolean} 是否有效
     */
    isValidCoordinate(marker) {
        return marker &&
               typeof marker.x === 'number' &&
               typeof marker.z === 'number' &&
               !isNaN(marker.x) &&
               !isNaN(marker.z);
    }

    /**
     * 执行空间聚类
     * @param {Array} points - 出生点数组
     * @returns {Array} 聚类结果
     */
    performClustering(points) {
        const { algorithm, maxBreakDistance, minPoints } = this.config.clustering;

        if (algorithm === 'dbscan') {
            return ClusteringAlgorithms.dbscan(points, maxBreakDistance, minPoints);
        } else {
            return ClusteringAlgorithms.simpleDistanceClustering(points, maxBreakDistance);
        }
    }

    /**
     * 为单个聚类生成宣称范围
     * @param {string} countryName - 国家名称
     * @param {Array} allPoints - 所有出生点
     * @param {Array} clusterIndices - 聚类中点的索引
     * @param {Object} areaData - 区域数据
     * @param {number} clusterIndex - 聚类索引
     * @returns {Object} 生成结果
     */
    generateClusterClaim(countryName, allPoints, clusterIndices, areaData, clusterIndex) {
        try {
            // 获取聚类中的点
            const clusterPoints = clusterIndices.map(index => allPoints[index]);

            // 计算聚类中心
            const center = ClusteringAlgorithms.calculateClusterCenter(allPoints, clusterIndices);

            // 提取对应的区域边界
            const relatedAreas = this.extractRelatedAreas(clusterPoints, areaData);

            // 生成宣称边界
            const boundary = this.generateClaimBoundary(clusterPoints, relatedAreas);

            const claim = {
                id: `${countryName}_claim_${clusterIndex}`,
                countryName,
                clusterIndex,
                center,
                boundary,
                spawnPoints: clusterPoints,
                relatedAreas: relatedAreas.map(area => area.areaId),
                metadata: {
                    spawnPointCount: clusterPoints.length,
                    relatedAreaCount: relatedAreas.length,
                    boundaryType: this.determineBoundaryType(clusterPoints, boundary),
                    area: boundary.length > 2 ? GeometryUtils.calculatePolygonArea(boundary) : 0
                }
            };

            return { success: true, claim };

        } catch (error) {
            console.error(`❌ 生成聚类 ${clusterIndex} 的宣称范围失败:`, error);
            return { success: false, error: error.message };
        }
    }

    /**
     * 提取与聚类相关的区域边界
     * @param {Array} clusterPoints - 聚类中的出生点
     * @param {Object} areaData - 区域数据
     * @returns {Array} 相关区域数组
     */
    extractRelatedAreas(clusterPoints, areaData) {
        const relatedAreas = [];

        if (!areaData) return relatedAreas;

        // 为每个出生点查找对应的区域
        for (const point of clusterPoints) {
            const markerId = point.markerId;

            // 查找包含此标记ID的区域
            for (const [areaId, area] of Object.entries(areaData)) {
                if (this.isAreaRelatedToMarker(area, markerId, point)) {
                    relatedAreas.push({
                        areaId,
                        area,
                        polygon: GeometryUtils.areaToPolygon(area)
                    });
                }
            }
        }

        return relatedAreas;
    }

    /**
     * 判断区域是否与标记相关
     * @param {Object} area - 区域数据
     * @param {string} markerId - 标记ID
     * @param {Object} point - 出生点
     * @returns {boolean} 是否相关
     */
    isAreaRelatedToMarker(area, markerId, point) {
        // 简单的关联判断：检查出生点是否在区域附近
        if (!area.x || !area.z) return false;

        const polygon = GeometryUtils.areaToPolygon(area);
        if (polygon.length === 0) return false;

        // 检查点是否在多边形内或附近
        const isInside = GeometryUtils.isPointInPolygon([point.x, point.z], polygon);
        if (isInside) return true;

        // 检查点是否在多边形边界附近（距离阈值）
        const bounds = GeometryUtils.calculatePolygonBounds(polygon);
        if (!bounds) return false;

        const threshold = 500; // 500单位的关联阈值
        return point.x >= bounds.minX - threshold &&
               point.x <= bounds.maxX + threshold &&
               point.z >= bounds.minZ - threshold &&
               point.z <= bounds.maxZ + threshold;
    }

    /**
     * 生成宣称边界
     * @param {Array} clusterPoints - 聚类中的出生点
     * @param {Array} relatedAreas - 相关区域
     * @returns {Array} 边界坐标数组
     */
    generateClaimBoundary(clusterPoints, relatedAreas) {
        const { enableMerging, bufferDistance, useConvexHull } = this.config.geometry;

        // 如果有相关区域，使用区域边界
        if (relatedAreas.length > 0) {
            const polygons = relatedAreas.map(area => area.polygon).filter(p => p.length > 0);

            if (polygons.length > 0) {
                if (enableMerging && polygons.length > 1) {
                    // 合并多个多边形
                    return GeometryUtils.mergePolygons(polygons, bufferDistance);
                } else if (polygons.length === 1) {
                    // 单个多边形，应用缓冲
                    return GeometryUtils.bufferPolygon(polygons[0], bufferDistance);
                } else {
                    // 多个多边形但不合并，选择最大的
                    const largestPolygon = polygons.reduce((largest, current) => {
                        const currentArea = GeometryUtils.calculatePolygonArea(current);
                        const largestArea = GeometryUtils.calculatePolygonArea(largest);
                        return currentArea > largestArea ? current : largest;
                    });
                    return GeometryUtils.bufferPolygon(largestPolygon, bufferDistance);
                }
            }
        }

        // 如果没有区域边界，基于出生点生成
        if (clusterPoints.length === 1) {
            // 单点：创建圆形区域（用正方形近似）
            const point = clusterPoints[0];
            const radius = 500;
            return [
                [point.x - radius, point.z - radius],
                [point.x + radius, point.z - radius],
                [point.x + radius, point.z + radius],
                [point.x - radius, point.z + radius]
            ];
        } else if (clusterPoints.length === 2) {
            // 两点：创建连接线的缓冲区
            const p1 = clusterPoints[0], p2 = clusterPoints[1];
            const buffer = 300;
            return [
                [Math.min(p1.x, p2.x) - buffer, Math.min(p1.z, p2.z) - buffer],
                [Math.max(p1.x, p2.x) + buffer, Math.min(p1.z, p2.z) - buffer],
                [Math.max(p1.x, p2.x) + buffer, Math.max(p1.z, p2.z) + buffer],
                [Math.min(p1.x, p2.x) - buffer, Math.max(p1.z, p2.z) + buffer]
            ];
        } else {
            // 多点：使用凸包
            const points = clusterPoints.map(p => [p.x, p.z]);
            if (useConvexHull) {
                const hull = GeometryUtils.calculateConvexHull(points);
                return GeometryUtils.bufferPolygon(hull, bufferDistance);
            } else {
                // 使用边界框
                const bounds = ClusteringAlgorithms.calculateClusterBounds(clusterPoints,
                    clusterPoints.map((_, i) => i));
                return [
                    [bounds.minX - bufferDistance, bounds.minZ - bufferDistance],
                    [bounds.maxX + bufferDistance, bounds.minZ - bufferDistance],
                    [bounds.maxX + bufferDistance, bounds.maxZ + bufferDistance],
                    [bounds.minX - bufferDistance, bounds.maxZ + bufferDistance]
                ];
            }
        }
    }

    /**
     * 确定边界类型
     * @param {Array} clusterPoints - 聚类点
     * @param {Array} boundary - 边界
     * @returns {string} 边界类型
     */
    determineBoundaryType(clusterPoints, boundary) {
        if (clusterPoints.length === 1) return 'single-point';
        if (clusterPoints.length === 2) return 'line';
        if (boundary.length > 4) return 'complex-polygon';
        return 'simple-polygon';
    }
}

// 导出类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CountryClaimsGenerator;
} else if (typeof window !== 'undefined') {
    window.CountryClaimsGenerator = CountryClaimsGenerator;
}
